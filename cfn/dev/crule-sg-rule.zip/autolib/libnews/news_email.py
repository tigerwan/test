
"""
Module: aws_labmda
Create Date: 2018-07-31
Function: Implement aws lambda module.
"""
from copy import deepcopy
from autolib.libaws.aws_email import AwsEmailI
from autolib.libcomm.commfunc import CommFunc

###############################################################################
# NewsEmailConf
###############################################################################
class NewsEmailConf:
    """
    format:
    { "from":"newstechnologycloudandautomation@news.com.au",
      "to":"john.niu@news.com.au",
      "subject":"Automation IAM clean report",
      "content_prefix":"Note: Report only, No real action of disabling.<br>------------------------",
      "content_postfix":"<br>From automation."
    }
    """
    def __init__(self, config=None, config_file=None):
        self.__config = CommFunc.get_config(config, config_file)

    def get_config(self):
        return deepcopy(self.__config)

    def get_to(self):
        return self.__config.get('to')

    def get_from(self):
        return self.__config.get('from')

    def get_subject(self):
        session_email_subject = CommFunc.get_session_env('G_AUTOLIB_EMAIL_SUBJECT')
        if session_email_subject:
                return session_email_subject
        else:
            return self.__config.get('subject')

    def set_session_subject(self, pi_value):
        """
        Set session variable: G_AUTOLIB_EMAIL_SUBJECT
        use it to override the value defined in config file.
        """
        CommFunc.set_session_env('G_AUTOLIB_EMAIL_SUBJECT', pi_value)

    def get_content_prefix(self):
        return self.__config.get('content_prefix')

    def get_content_postfix(self):
        return self.__config.get('content_postfix')

class NewsEmail(NewsEmailConf):
    """
    News Email Class.
    """
    def __init__(self, config=None, config_file=None):
        """ Initalization.
        """
        super().__init__(config, config_file)
        
    def ses_send(self, pi_session, message_text=None, message_html=None, subject_plus=None):
        """
        Send email by AWS SimpleEmailService
        """

        content_prefix = self.get_content_prefix()
        content_postfix = self.get_content_postfix()

        if message_text:
            content_text = content_prefix + message_text + content_postfix
        else:
            content_text = None

        if message_html:
            content_html = content_prefix + message_html + content_postfix
        else:
            content_html = None

        ci_from = self.get_from()
        ci_to = self.get_to()

        subject = self.get_subject() 
        if subject_plus:
            subject = subject + "__{}".format(str(subject_plus))

        AwsEmailI.c_ses_send(pi_session, subject, ci_from, ci_to, message_text=content_text, message_html=content_html)