"""
Module of News Report

For save dat to storage, read data from storage based on config
"""

from copy import deepcopy
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_s3 import AwsS3I

###############################################################################
# NewsReportStyleConf
###############################################################################
class NewsReportStyleConf:
    """
            {
                "type": "default",
                "style_1": {
                    "header_bgcolor_account": "#b4b6ba",
                    "header_bgwidth_account": "660px",
                    "warning_bgcolor": "yellow",
                    "warning_fgcolor": "",
                    "disable_fgcolor": "red",
                    "disable_bgcolor": "",
                    "table_column_names": ["Key", "CreateDate", "LastUsed", "NotUseDays", "Action"],
                    "table_column_widths": [180,175,175,70,50],
                    "table_width": "660px",
                    "table_header_font_weight": "normal",
                    "report_only_user_info_postfix": "",
                    "report_only_account_info_postfix": " -- Protected"
                },
                "style_n": {}
                ...
            },
    """
    def __init__(self, config=None, config_file=None):
        self.__config = CommFunc.get_config(config, config_file)

    def get_style_type(self):
        """
        Get report style type.

        Note: 
        If session variable G_AUTOLIB_REPORT_STYLE_TYPE is defined, then use it first
        otherwise use value in config file.
        """
        session_style_type = CommFunc.get_session_env('G_AUTOLIB_REPORT_STYLE_TYPE')
        if session_style_type:
            return session_style_type
        else:
            if self.__config:
                return deepcopy(self.__config.get('type'))
            else:
                return None

    def get_current_style(self):
        """
        Get current report style info

        "style": {
                    "type": "latest",      <-- from 'latest', then next to 
                                           <-- find latest key value 
                    "latest": { 
                        "header_bgcolor_account": "#b4b6ba",                 
                        "header_bgwidth_account": "570px",
                        "warning_bgcolor": "yellow",
                        "warning_fgcolor": "",
                        "disable_fgcolor": "red",
                        "disable_bgcolor": "",
                        "table_width": "550px",
                        "table_header_font_weight": "normal",
                        "report_only_user_info_postfix": "",
                        "report_only_account_info_postfix": " -- Protected"
                        "action_disabled_info":"Disabled",
                        "action_prevent_disable_info":"Prevent disable",
                        "action_warning_info":"warning",
                        "content_prefix":"",
                        "content_postfix":"",
                    }
                }
        in above example, will return "latest" key value, type dict
        """
        if self.__config:
            style_type = self.get_style_type()
            if style_type:
                return self.__config.get(style_type)
        return None

    def is_style_default(self):
        """
        If style type not defined correctly, then use default
        """
        current_style = self.get_current_style()
        if current_style:
            return False
        else:
            return True

    def style_get(self, pi_key):
        """
        Get value for current defined style type
        """
        current_style = self.get_current_style()
        if current_style:
            return current_style.get(pi_key)
        else:
            return None

    def get_header_bgcolor_account(self):
        """
        Get report header background colour, this only for account header
        """
        return self.style_get('header_bgcolor_account')


    def get_header_bgwidth_account(self):
        """
        Get header background width, this only for account header
        """
        return self.style_get('header_bgwidth_account')

    def get_warning_fgcolor(self):
        """
        Get text warning frontground color
        """
        return self.style_get('warning_fgcolor')

    def get_warning_bgcolor(self):
        """
        Get text warning background color
        """
        return self.style_get('warning_bgcolor')

    def get_disable_fgcolor(self):
        """
        Get text disable frontground color
        """
        return self.style_get('disable_fgcolor')

    def get_disable_bgcolor(self):
        """
        Get text disable background color
        """
        return self.style_get('disable_bgcolor')

    def get_table_width(self):
        """
        Get table width
        """
        return self.style_get('table_width')

    def get_table_border(self):
        """
        Get table border collapse, valid value: collapse | separate
        """
        return self.style_get('table_border')

    def get_table_column_widths(self):
        """
        Get table column widths list
        """
        return self.style_get('table_column_widths')

    def get_table_column_names(self):
        """
        Get table column names list
        """
        return self.style_get('table_column_names')

    def get_table_header_font_weight(self):
        """
        Get table header font weight
        """
        return self.style_get('table_header_font_weight')

    def get_reportonly_user_info_postfix(self):
        """
        Get report only user post fix information
        """
        return self.style_get('report_only_user_info_postfix') or ""

    def get_reportonly_account_info_postfix(self):
        """
        Get report only user post fix information
        """
        return self.style_get('report_only_account_info_postfix') or ""

    def get_action_disabled_desc(self):
        """
        Get action disabled describe
        """
        return self.style_get('action_disabled_desc') or "disabled"

    def get_action_prevent_disable_desc(self):
        """
        Get action prevent disable describe
        """
        return self.style_get('action_prevent_disable_desc') or "Prevent disable"

    def get_action_warning_desc(self):
        """
        Get action warning describe
        """
        return self.style_get('action_warning_desc') or "Warning"

    def get_content_prefix(self):
        """
        Get content_prefix
        """
        return self.style_get('content_prefix') or ""

    def get_content_postfix(self):
        """
        Get content_postfix
        """
        return self.style_get('content_postfix') or ""
    
    @classmethod
    def c_set_session_style_type(cls, pi_value):
        """
        Set session variable: G_AUTOLIB_REPORT_STYLE_TYPE
        use it to override the value defined in config file.
        """
        CommFunc.set_session_env('G_AUTOLIB_REPORT_STYLE_TYPE', pi_value)


###############################################################################
# NewsReportConf
###############################################################################
class NewsReportConf(NewsReportStyleConf):
    """
    format:
        {  "to": "s3", 
            "account_id":"877800914193",
            "bucket":"ops-automation-tool-report", 
            "path_file":"iam-clean-report/iam_clean_{%ORG_TIMESTAMP}/{%ACCOUNT_ID}.result", 
            "report_folder_prefix":"iam-clean-report/iam_clean_{%ORG_DAYSTAMP}",
            "style": {
                "type": "default",
                "style_1": {
                },
                ...
                "style_n": {
                }
            }
        }
    """
    def __init__(self, config=None, config_file=None):
        self.__config = CommFunc.get_config(config, config_file)
        super().__init__(config=self.__config.get('style'), config_file=None)

    def get_config(self):
        return deepcopy(self.__config)

    def get_account_id(self):
        return deepcopy(self.__config.get('account_id'))

    def get_to(self):
        return deepcopy(self.__config.get('to'))

    def get_region_name(self):
        return deepcopy(self.__config.get('region'))

    def get_role_table(self):
        return deepcopy(self.__config.get('role_table'))

    def get_bucket(self):
        return deepcopy(self.__config.get('bucket'))

    def get_path_file(self):
        return deepcopy(self.__config.get('path_file'))

    def get_email_conf(self):
        return deepcopy(self.__config.get('email'))

    def is_write_to_s3(self):
        if self.get_to().lower() == "s3":
            return True
        else:
            return False

    def _get_report_folder_prefix(self):
        return deepcopy(self.__config.get('report_folder_prefix'))

    def compute_report_folder_prefix(self):
        return CommFunc.replace_vars(self._get_report_folder_prefix(),
                                     key_prefix="{%ORG_",
                                     key_postfix="}",
                                     DAYSTAMP=CommFunc.current_daystamp())
    def get_style_conf(self):
        """
        Get report style type
        """
        return deepcopy(self.__config.get('style'))






###############################################################################
# NewsReport
###############################################################################
class NewsReport(NewsReportConf):
    """
    Class of NewsReport
    """
    def __init__(self, config=None, config_file=None):
        super().__init__(config=config, config_file=config_file)

    def write_to(self, pi_content, **kwargs):
        """
        Input:

        pi_conf  format
        {
            ...
            'report': {'to': 's3', 
                       'bucket':'iam-clean-report', 
                       'path_file':'hello/world/iam_clean_{%ORG_TIMESTAMP}/{%ACCOUNT_ID}.result' 
                       'report_folder_prefix':'hello/world/iam_clean_{%ORG_DAYSTAMP}' 
                      }
        }
        pi_content: content to write

        if write to S3, must include session_ro and session_rw
        session_ro: session for readonly
        session_rw: session for readwrite

        """
        if self.is_write_to_s3():
            pi_session_ro = kwargs['session_ro']
            pi_session_rw = kwargs['session_rw']

            ci_bucket = self.get_bucket()
            ci_path_file = self.get_path_file()

            Log2.debug_l(5, "ci_path_File:{}".format(ci_path_file))

            path_file = CommFunc.replace_vars(ci_path_file, ACCOUNT_ID=kwargs.get('ACCOUNT_ID'))
            s3i = AwsS3I(pi_session_ro, pi_session_rw)

            Log2.debug_l(5, "Write report to bucket:{}, path_File:{}".format(ci_bucket, path_file))
            s3i.write_new_file(ci_bucket, path_file, CommFunc.dumps(pi_content))
        else:
            raise ValueError("write to {} is not support.".format(self.get_to()))


class NewsReportMaker():
    """
    class of Report Maker

    Step by step to make a report content:

                             |<-------------------------|
        start_compose(title) -> add header -> add text ->-> add footer -> done.

        >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        <style>                  <--|
        <title>                     |
                                    |
        <header>    <--|            |
        text           |            |
        text           |            |
        text           |            | 
                       | Body       | Content
        <header>       |            |
        text           |            |
        text           |            |
        ...            |            |
        text           |            |
        ...         <--|            |
                                    |
        <footer>                 <--|
        <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    """

    def __init__(self):
        """ Initalization.


        """
        self.__style = None
        self.__title = None
        self.__body = None
        self.__footer = None

    def _body_add(self, pi_line):
        if pi_line:
            if self.__body:
                self.__body += pi_line
            else:
                self.__body = pi_line

    def add_header(self, pi_header,  pi_level=3, bgcolor=None, bgwidth=None):
        """
        pi_level: (1 - 6) default 2. 
                  The level of heading desired 
                  (HTML offers six levels of headings).
                  Since the title default is 2, 
                  so the better header is less than 2
        """
        if bgcolor is None:
            self._body_add("<h"+str(pi_level)+">" +str(pi_header)+ "</h"+str(pi_level)+">")
        else:
            #code="<h{0}><span style=\"background-color: {1}\">{2}</span></h{0}>".format(pi_level, bgcolor, pi_header)
            if bgwidth:
                code="<h{0}><span style=\"background-color: {1}; display: block; width: {3}\">{2}</span></h{0}>".format(pi_level, bgcolor, pi_header, bgwidth)
            else:
                code="<h{0}><span style=\"background-color: {1}\">{2}</span></h{0}>".format(pi_level, bgcolor, pi_header)
            self._body_add(code)

    def start_compose(self, pi_title):
        """
        """
        self.__body = ""
        self.__style = """<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />"""
        self.__title = pi_title

    def add_table_begin(self, column_names=None, column_widths=None, table_width=None, header_font_weight=None, table_border=None):
        """
        Add table begin code, including set table width, columns width, 
        header column names and font weight
        -----------------------------
        <table style="width:60%">
        <tr>
            <th>Firstname</th>
            <th>Lastname</th> 
        </tr>
        <tr>
            <td>Jill</td>
            <td>Smith</td> 
        </tr>
        <tr>
            <td>Eve</td>
            <td>Jackson</td> 
        </tr>
        -----------------------------
        </table>
        """
        table_border_code = deepcopy(table_border)
        if table_border_code is None:
            table_border_code = "collapse"
        
        if table_width:
            self._body_add("<table border=\"1px\" style=\"width: {}; border-collapse: {}\">".format(table_width, table_border_code))
        else:
            self._body_add("<table border=\"1px\" style=\"border-collapse: {}\">".format(table_border_code))
        #
        # Set table column width
        #
        if column_widths:
            for c_width in column_widths:
                self._body_add("<col width=\"{}\">".format(c_width))
        #
        # Add table header column names
        #
        self._body_add("<tr>")
        for name in column_names:
            if header_font_weight:
                self._body_add("<th style=\"font-weight: "+header_font_weight+"\">"+name+"</th>")
            else:
                self._body_add("<th>"+name+"</th>")
        self._body_add("</tr>")

    def add_table_row(self, *pi_row_values, **kwargs):
        """
        **kwargs:
        bgcolor: ['red', 'yellow', 'green', 'blue', 'gray']
        fgcolor: ['red', 'yellow', 'green', 'blue', 'gray']
        """
        background_color=""
        foreground_color=""
        if kwargs.get('bgcolor'):
            background_color=" bgcolor='" + kwargs.get('bgcolor') + "'"
        if kwargs.get('fgcolor'):
            foreground_color="<font color='" + kwargs.get('fgcolor') + "'>"
        self._body_add("<tr>")
        for value in pi_row_values:
            self._body_add("<td"+background_color+">"+foreground_color+str(value)+"</td>")
        self._body_add("</tr>")

    def add_table_end(self):
        self._body_add("</table>")

    def add_text_n(self, pi_text):
        """
        add text without new line
        """
        self._body_add("{}".format(pi_text))

    def add_text(self, pi_text):
        """
        add text with new line
        """
        self.add_text_n(pi_text)
        self._body_add("<br>")

    def add_color_text_n(self, pi_text, bgcolor=None, fgcolor=None):
        """
        add color text without new line
        """
        if fgcolor or bgcolor:
            text_template = "<font {fgcolor}{bgcolor}>{text}</font>"
            if fgcolor:
                fg_code = "color=\"{}\"".format(fgcolor)
            else:
                fg_code = ""

            if bgcolor:
                bg_code = "style=\"background-color: {}\"".format(bgcolor)
            else:
                bg_code = ""
            text = text_template.format(fgcolor=fg_code, bgcolor=bg_code, text=pi_text)
        else:
            text = pi_text
        self.add_text_n(text)
        
    def add_color_text(self, pi_text, bgcolor=None, fgcolor=None):
        self.add_color_text_n(pi_text, bgcolor, fgcolor)
        self._body_add("<br>")

    def get_body(self):
        return deepcopy(self.__body)

    def get_content(self):
        content = self.__style
        content += "<h2>" + self.__title + "</h2>"
        content += self.__body
        if self.__footer:
            content += self.__footer
        return deepcopy(content)
