"""
Module: news_org
Create Date: 2018-07-31
Function: Implement news organization module.
"""

from copy import deepcopy
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI
from autolib.libaws.aws_dynamodb import AwsDynamodbI
from autolib.libnews.news_account import NewsAccount

class NewsOrg:
    """
    NewsOrg Class.

    Including functions in organization management level.
    """

    def __init__(self, session_ro=None, session_rw=None, session=None, **kwargs):
        """
        Initalization.
        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, session_rw=session_rw, session=session, **kwargs)
        self.__session = self.__session_rw
        self.__accounts = None

    @classmethod
    def new(self, session, **kwargs):
        """
        For create a new instance of NewsOrg in a simple way.
        """
        return NewsOrg(session=session, **kwargs)

    def get_session(self):
        return (self.__session_ro, self.__session_rw)

    def set_session_rw(self, session_rw):
        """
        Set session readwrite
        """
        self.__session_rw = session_rw

    def set_session_ro(self, session_ro):
        """
        Set session readonly
        """
        self.__session_ro = session_ro

    def set_session(self, session):
        """
        Set both _session_ro and _session_rw session
        """
        self.__session_ro = self.__session_rw = session

    def get_accounts(self, pi_table_name):
        """
        Get all accounts rows from dynamodb table 
        Input:
            pi_table_name: the table name to scan
        Return:
            rows_info, dict type
            format as following:
            {
                'Items': 
                    [
                        {'accountId': {'S': '261912113761'},
                        'accountName': {'S': 'News DNA'},
                        'environment': {'S': 'PROD'}
                        },
                        {'accountId': {'S': '851914194101'},
                        'accountName': {'S': 'News DNA'},
                        'environment': {'S': 'UAT'}
                        },
                    ],
                'Count': 20,
                'ScannedCount': 20
            }
        """
        dbi = AwsDynamodbI(self.__session)
        table = dbi.scan_table(TableName=pi_table_name)
        accounts = {'Items': table['Items'],
                    'Count': table['Count'],
                    'ScannedCount': table['ScannedCount']}
        return accounts

    def lazy_get_accounts(self, pi_table_name, pi_expire_seconds=0):
        """
        Lazy get all accounts rows from dynamodb table. support cache mode.
        """
        if self.__accounts is None:
            self.__accounts = self.get_accounts(pi_table_name)
        return deepcopy(self.__accounts)


    def show_accounts(self, pi_table_name, pi_expire_seconds=0):
        """
        Show all accounts that exists in dynamodb table,
        sorted by accountName + '_' + environment
        format as following:

            accountId    accountName                    environment
            ------------ ------------------------------ ---------------
            761312330731 Data Bunker                    PROD
            876055854555 Data Platforms Ireland         PROD
            736111434131 Data Platforms US              PROD
            403646126292 Data Platforms                 DEV
            403846302456 Data Platforms                 PROD
            186426336459 Data Platforms                 UAT

            Total accounts: 37
        """
        table_info = self.lazy_get_accounts(pi_table_name, 5)
        if table_info and table_info['Count'] > 0:
            # print title
            print()
            print("{0:<12s} {1:<30s} {2:<15s}".format(
                "accountId", "accountName", "environment"))
            print("{0:<12s} {1:<30s} {2:<15s}".format(
                "------------",
                "------------------------------",
                "---------------"))

            rows = table_info['Items']
            # order by accountName+"_"+environment
            rows.sort(key=lambda x: x['accountName']
                      ['S']+'_'+x['environment']['S'])
            for item in rows:
                # print every account data
                print("{0:<12s} {1:<30s} {2:<15s}".format(
                    item['accountId']['S'],
                    item['accountName']['S'],
                    item['environment']['S']))
            print()
            print("Total accounts: {}".format(table_info['Count']))
            print()
        else:
            print("No data found in table: {}".format(pi_table_name))

    def get_account_byid(self, pi_table_name, pi_account_id):
        """
        Get one single account rows from dynamodb table based on the given account id
        Input:
            pi_table_name: the table name to query
            pi_account_id: the account id to query
        Return:
            rows_info, dict type
            format as following:
            {
                'Items':
                    [
                        {'accountId': {'S': '261912113761'},
                        'accountName': {'S': 'News DNA'},
                        'environment': {'S': 'PROD'}
                        }
                    ],
                'Count': 1,
                'ScannedCount': 1
            }
        """
        dbi = AwsDynamodbI(self.__session_ro)
        table = dbi.query_by_key(
            pi_table_name=pi_table_name,
            pi_key_name='accountId',
            pi_dict_val={'S': pi_account_id}
            )
        accounts = {'Items': table['Items'],
                    'Count': table['Count'],
                    'ScannedCount': table['ScannedCount']}
        return accounts

    def lazy_get_account_byid(self, pi_table_name, pi_account_id, pi_expire_seconds=0):
        """
        Lazy get account of the given id from dynamodb table.
        """
        if self.__accounts is None:
            self.__accounts = self.get_account_byid(
                pi_table_name=pi_table_name,
                pi_account_id=pi_account_id
            )
        return deepcopy(self.__accounts)

    def get_account_property(self, pi_account_id, pi_property_name, pi_table_name=None):
        """
        Get a account property from dynamodb, e.g. environment, email, etc
        """
        if not pi_account_id or not pi_property_name:
            return None

        if self.__accounts is None:
            if pi_table_name is None:
                return None
            else:
                self.lazy_get_account_byid(pi_table_name=pi_table_name, pi_account_id=pi_account_id)

        if self.__accounts and 'Items' in self.__accounts:
            # remove data type ,e.g. convert {'accountId':{'S':'1234}} to {'accountId':'1234'}
            account_details = AwsDynamodbI.extract_rows_without_type(self.__accounts)
            for item in account_details:
                if item['accountId'] == pi_account_id:
                    return item.get(pi_property_name)
        else:
            return None

    @classmethod
    def c_get_users_bypool(cls, pi_key_profiles, pi_proc_pool):
        """
        pi_key_profile: format as following
          {
            "AccountId": "xxxxxxxxxx"
            "Role": "yyyyyyyyy"
            "AccessKeyId": "BCIA4YYIC7UIVWJJ3CMH",
            "SecretAccessKey": "ovsYC4z1RqFHujlUiZVYLGBN9zqWSsQK2ypS+wxD",
            "SessionToken": "FQoGZXIvYXdzEKH//////////wEaDFI+aoQZ4r1kC1b0MiKuAipdK09f8NCnpRHLffdxKC8sx7AV1ZyODqkOMkgqqAS8rordmejaEIk8KjqN8O2uoUhAxBRy4M2sgc88b9nmrCEtYI8py10TRZ2oLXzAcyco7x/0A8NTLSY9HRU0iGzuedvtH7pU/Dou7D7SAWQrjWCFIdZPffwL7trIuArejPV9cBZDJA3+VVnT+yuRIPquAYaPOYyTqt6ZIwpfolrFd9C1yWU+qsV/+UtcfXEtcZjIto/LMgdC8EvML2wSJXBYqR9Rw0jg8DvHF9EDV65Xlv5EG95rnheftbIyt1FARHG0WhJwMZpzsme0V9JoLfPFEdgHoZGMFylhj5qH0fixiUJfRV96lTO0oFw1GZNl+qHmrjtNHta5+0oHRcmhGqivOPDVoOkdOad7pXfanXuoKKHpk9wF",
            "Expiration": "2018-08-28T08:07:13.000Z"
        }


        results format:
        {'process_name': 'Process-5', 
         'task_uid': '940478797813',     --- account ID
         'task_result': [{'Path': '/', 'UserName': 'awsinfo', 'UserId': 'AIDAI6S5RGFDXG5W2X4FA', 'Arn': 'arn:aws:iam::940478797813:user/awsinfo', 'CreateDate': datetime.datetime(2016, 7, 6, 4, 19, 21, tzinfo=tzutc())}, 
                         {'Path': '/', 'UserName': 'bamboo-agent', 'UserId': 'AIDAJ3FBJICMDZYTB67XC', 'Arn': 'arn:aws:iam::940478797813:user/bamboo-agent', 'CreateDate': datetime.datetime(2016, 3, 16, 7, 58, 57, tzinfo=tzutc())}, 
                        ]
        }

        return users format:
        {
            "AccountId": ""
            "Users": [{'Path': '/', 'UserName': 'awsinfo', 'UserId': 'AIDAI6S5RGFDXG5W2X4FA', 'Arn': 'arn:aws:iam::940478797813:user/awsinfo', 'CreateDate': datetime.datetime(2016, 7, 6, 4, 19, 21, tzinfo=tzutc())}, 
                         {'Path': '/', 'UserName': 'bamboo-agent', 'UserId': 'AIDAJ3FBJICMDZYTB67XC', 'Arn': 'arn:aws:iam::940478797813:user/bamboo-agent', 'CreateDate': datetime.datetime(2016, 3, 16, 7, 58, 57, tzinfo=tzutc())}, 
                        ]
        }

        """
        tasks = []
        for profile in pi_key_profiles:
            tasks.append(
            (
                NewsAccount.c_get_users, 
                ( 
                    profile['AccessKeyId'],
                    profile['SecretAccessKey'], 
                    profile['SessionToken']
                ),
                profile['AccountId']
            )
        )
        #print(tasks)
        pi_proc_pool.put_tasks(tasks)
        results=pi_proc_pool.get_results_info()

        users = [{"AccountId": x["task_uid"], "Users": x["task_result"]} for x in results]
        return users
        



    @classmethod
    def c_get_roles_bypool(cls, pi_key_profiles, pi_proc_pool):
        """
        pi_key_profile: format as following
          {
            "AccountId": "xxxxxxxxxx"
            "Role": "yyyyyyyyy"
            "AccessKeyId": "BCIA4YYIC7UIVWJJ3CMH",
            "SecretAccessKey": "ovsYC4z1RqFHujlUiZVYLGBN9zqWSsQK2ypS+wxD",
            "SessionToken": "FQoGZXIvYXdzEKH//////////wEaDFI+aoQZ4r1kC1b0MiKuAipdK09f8NCnpRHLffdxKC8sx7AV1ZyODqkOMkgqqAS8rordmejaEIk8KjqN8O2uoUhAxBRy4M2sgc88b9nmrCEtYI8py10TRZ2oLXzAcyco7x/0A8NTLSY9HRU0iGzuedvtH7pU/Dou7D7SAWQrjWCFIdZPffwL7trIuArejPV9cBZDJA3+VVnT+yuRIPquAYaPOYyTqt6ZIwpfolrFd9C1yWU+qsV/+UtcfXEtcZjIto/LMgdC8EvML2wSJXBYqR9Rw0jg8DvHF9EDV65Xlv5EG95rnheftbIyt1FARHG0WhJwMZpzsme0V9JoLfPFEdgHoZGMFylhj5qH0fixiUJfRV96lTO0oFw1GZNl+qHmrjtNHta5+0oHRcmhGqivOPDVoOkdOad7pXfanXuoKKHpk9wF",
            "Expiration": "2018-08-28T08:07:13.000Z"
        }
        results format:
        {'process_name': 'Process-5', 
         'task_uid': '940478797813',     --- account ID
         'task_result': [
                            {'Path': '/', 
                             'RoleName': 'workspaces_DefaultRole', 
                             'RoleId': 'AROAI5QZEAIEO654L2RKE', 
                             'Arn': 'arn:aws:ia    m::877800914193:role/workspaces_DefaultRole', 
                             'CreateDate': datetime.datetime(2014, 10, 22, 4, 13, 20, tzinfo=tzutc()), 
                             'AssumeRolePolicyDocument': {'Version': '2008-10-17', 
                                                          'Statement': [{'Sid': '', 
                                                                         'Effect': 'Allow', 
                                                                         'Principal': {'Service': 'workspaces.amazonaws.    com'}, 
                                                                         'Action': 'sts:AssumeRole'
                                                                         }]
                                                          }, 
                             'MaxSessionDuration': 3600
                             },
                        ]
        }

        return users format:
        {
            "AccountId": ""
            "Roles": [
                            {'Path': '/', 
                             'RoleName': 'workspaces_DefaultRole', 
                             'RoleId': 'AROAI5QZEAIEO654L2RKE', 
                             'Arn': 'arn:aws:ia    m::877800914193:role/workspaces_DefaultRole', 
                             'CreateDate': datetime.datetime(2014, 10, 22, 4, 13, 20, tzinfo=tzutc()), 
                             'AssumeRolePolicyDocument': {'Version': '2008-10-17', 
                                                          'Statement': [{'Sid': '', 
                                                                         'Effect': 'Allow', 
                                                                         'Principal': {'Service': 'workspaces.amazonaws.    com'}, 
                                                                         'Action': 'sts:AssumeRole'
                                                                         }]
                                                          }, 
                             'MaxSessionDuration': 3600
                            },
                            ...
                        ]
        }
        """
        tasks = []
        for profile in pi_key_profiles:
            tasks.append(
            (
                NewsAccount.c_get_roles, 
                ( 
                    profile['AccessKeyId'],
                    profile['SecretAccessKey'], 
                    profile['SessionToken']
                ),
                profile['AccountId']
            )
        )
        #print(tasks)
        pi_proc_pool.put_tasks(tasks)
        results=pi_proc_pool.get_results_info()

        users = [{"AccountId": x["task_uid"], "Roles": x["task_result"]} for x in results]
        return users





    @classmethod
    def c_get_access_keys_bypool(cls, pi_key_profiles, pi_proc_pool):
        """
        pi_key_profile: format as following
          {
            "AccountId": "xxxxxxxxxx"
            "Role": "yyyyyyyyy"
            "AccessKeyId": "BCIA4YYIC7UIVWJJ3CMH",
            "SecretAccessKey": "ovsYC4z1RqFHujlUiZVYLGBN9zqWSsQK2ypS+wxD",
            "SessionToken": "FQoGZXIvYXdzEKH//////////wEaDFI+aoQZ4r1kC1b0MiKuAipdK09f8NCnpRHLffdxKC8sx7AV1ZyODqkOMkgqqAS8rordmejaEIk8KjqN8O2uoUhAxBRy4M2sgc88b9nmrCEtYI8py10TRZ2oLXzAcyco7x/0A8NTLSY9HRU0iGzuedvtH7pU/Dou7D7SAWQrjWCFIdZPffwL7trIuArejPV9cBZDJA3+VVnT+yuRIPquAYaPOYyTqt6ZIwpfolrFd9C1yWU+qsV/+UtcfXEtcZjIto/LMgdC8EvML2wSJXBYqR9Rw0jg8DvHF9EDV65Xlv5EG95rnheftbIyt1FARHG0WhJwMZpzsme0V9JoLfPFEdgHoZGMFylhj5qH0fixiUJfRV96lTO0oFw1GZNl+qHmrjtNHta5+0oHRcmhGqivOPDVoOkdOad7pXfanXuoKKHpk9wF",
            "Expiration": "2018-08-28T08:07:13.000Z"
        }
        results format:
        {'process_name': 'Process-5', 
         'task_uid': '940478797813',     --- account ID
         'task_result': [
                        ]
        }

        return users format:
        {
            "AccountId": ""
            "AccessKeys": [
                        ]
        }
        """
        tasks = []
        for profile in pi_key_profiles:
            tasks.append(
            (
                NewsAccount.c_get_access_keys, 
                ( 
                    profile['AccessKeyId'],
                    profile['SecretAccessKey'], 
                    profile['SessionToken']
                ),
                profile['AccountId']
            )
        )
        #print(tasks)
        pi_proc_pool.put_tasks(tasks)
        results=pi_proc_pool.get_results_info()

        access_keys = [{"AccountId": x["task_uid"], "AccessKeys": x["task_result"]} for x in results]
        return access_keys



    @classmethod
    def c_get_buckets_bypool(cls, pi_key_profiles, pi_proc_pool):
        """
        pi_key_profile: format as following
          {
            "AccountId": "xxxxxxxxxx"
            "Role": "yyyyyyyyy"
            "AccessKeyId": "BCIA4YYIC7UIVWJJ3CMH",
            "SecretAccessKey": "ovsYC4z1RqFHujlUiZVYLGBN9zqWSsQK2ypS+wxD",
            "SessionToken": "FQoGZXIvYXdzEKH//////////wEaDFI+aoQZ4r1kC1b0MiKuAipdK09f8NCnpRHLffdxKC8sx7AV1ZyODqkOMkgqqAS8rordmejaEIk8KjqN8O2uoUhAxBRy4M2sgc88b9nmrCEtYI8py10TRZ2oLXzAcyco7x/0A8NTLSY9HRU0iGzuedvtH7pU/Dou7D7SAWQrjWCFIdZPffwL7trIuArejPV9cBZDJA3+VVnT+yuRIPquAYaPOYyTqt6ZIwpfolrFd9C1yWU+qsV/+UtcfXEtcZjIto/LMgdC8EvML2wSJXBYqR9Rw0jg8DvHF9EDV65Xlv5EG95rnheftbIyt1FARHG0WhJwMZpzsme0V9JoLfPFEdgHoZGMFylhj5qH0fixiUJfRV96lTO0oFw1GZNl+qHmrjtNHta5+0oHRcmhGqivOPDVoOkdOad7pXfanXuoKKHpk9wF",
            "Expiration": "2018-08-28T08:07:13.000Z"
        }
        results format:
        {'process_name': 'Process-5', 
         'task_uid': '940478797813',     --- account ID
         'task_result': [
                        ]
        }

        return users format:
        {
            "AccountId": ""
            "Buckets": [
                        ]
        }
        """
        tasks = []
        for profile in pi_key_profiles:
            tasks.append(
            (
                NewsAccount.c_get_buckets, 
                ( 
                    profile['AccessKeyId'],
                    profile['SecretAccessKey'], 
                    profile['SessionToken']
                ),
                profile['AccountId']
            )
        )
        #print(tasks)
        pi_proc_pool.put_tasks(tasks)
        results=pi_proc_pool.get_results_info()

        access_keys = [{"AccountId": x["task_uid"], "Buckets": x["task_result"]} for x in results]
        return access_keys






###############################################################################
# NewsAccountsFilter
###############################################################################
class NewsAccountsFilter():
    """
    class of News Accounts Filter

    format:
    {
        "filter_pattern":"Include_Exclude_Updateable",
        "accounts_table": "ops-prod-awsaccounts",
        "exclude_accounts": [],
        "exclude_env_tags": ["prod"],
        "include_accounts": [],
        "include_env_tags": ["dev","uat"],
        "updateable_env_tags": ["dev"],
        "updateable_accounts": ["431525257644"],
        "account_plus": {
                    "431525257644": {
                                        "iam": {
                                            "filter_pattern":"Exclude",
                                            "exclude": {
                                                "users": [],
                                                "user_key_ids": [],
                                                "console_login": []
                                            }
                                        }
                                    },
                    "431525257644x": {
                                        "iam": {
                                            "filter_pattern":"Exclude",
                                            "exclude": {
                                                "users": [],
                                                "user_key_ids": [],
                                                "console_login": []
                                            }
                                        }
                                    }
        }
    }

    filter_pattern: Include_Exclude_Updateable
        Include_Exclude_Updateable: (The recommend way to define updateable)
                from full list, 
                1. define include list. 
                2. then define exclude list from include list.
                3. then define updateable list
                result_list = include_list - exclude list.
                all the accounts finally included defaut is read only. only if it defined in updateable, then can do readwrite

    """
    def __init__(self, config=None, config_file=None):
        """
        Init
        """
        self.__config = CommFunc.get_config(config, config_file)

    def get_config(self):
        """
        Get config 
        """
        return deepcopy(self.__config)

    def is_pattern_include_exclude_updateable(self):
        """
        Check if the filter pattern is "Include_Exclude_Updateable" type
        """
        filter_pattern = self.__config.get("filter_pattern") 
        return CommFunc.is_filter_pattern_include_exclude_updateable(filter_pattern)

    def _get_updateable_accounts(self):
        """
        Get "updateable_accounts"
        """
        if self.is_pattern_include_exclude_updateable():
            return deepcopy(self.__config.get('updateable_accounts'))
        else:
            raise ValueError("Invalid accounts filter pattern")

    def _get_include_accounts(self):
        """
        Get "include_accounts"
        """
        if self.is_pattern_include_exclude_updateable():
            return deepcopy(self.__config.get('include_accounts'))
        else:
            raise ValueError("Invalid accounts filter pattern")

    def _get_exclude_accounts(self):
        """
        Get "exclude_accounts"
        """
        if self.is_pattern_include_exclude_updateable():
            return deepcopy(self.__config.get('exclude_accounts'))
        else:
            raise ValueError("Invalid accounts filter pattern")

    def _get_include_env_tags(self, case_to=None):
        """
        Work out include env tags.
        transfer all character to lowercase.
        """
        if self.is_pattern_include_exclude_updateable():
            ci_include_env_tags = deepcopy(self.__config.get('include_env_tags'))
            if case_to and case_to == "lower":
                include_env_tags_lower = [x.lower() for x in ci_include_env_tags]
                return set(include_env_tags_lower)
            else:
                return set(ci_include_env_tags)
        else:
            raise ValueError("Invalid accounts filter pattern")
        

    def _get_accounts_table(self):
        if self.is_pattern_include_exclude_updateable():
            return deepcopy(self.__config.get('accounts_table'))
        else:
            raise ValueError("Invalid accounts filter pattern")

    def _get_updateable_env_tags(self):
        if self.is_pattern_include_exclude_updateable():
            ci_updateable_env_tags = self.__config.get('updateable_env_tags')
            # Exclude prod tag 
            updateable_env_tags = [x for x in ci_updateable_env_tags if x.lower() != 'prod']
            return updateable_env_tags
        else:
            raise ValueError("Invalid accounts filter pattern")
        

    def _get_exclude_env_tags(self):
        """
        Work out exclude env tags.
        transfer all character to lowercase. plus ["prod", "prd", "production", "product"]
        """
        if self.is_pattern_include_exclude_updateable():
            ci_exclude_env_tags = self.__config.get('exclude_env_tags')
            exclude_env_tags_lower = [x.lower() for x in ci_exclude_env_tags]
            exclude_env_tags = exclude_env_tags_lower + ["prod", "prd", "production", "product"]
            return set(exclude_env_tags)
        else:
            raise ValueError("Invalid accounts filter pattern")
        

    def _get_account_plus(self):
        """
        Get account_plus configuration.
        """
        if self.is_pattern_include_exclude_updateable():
            return deepcopy(self.__config.get('account_plus'))
        else:
            raise ValueError("Invalid accounts filter pattern")

    #
    # Compute filter result
    #
    def _compute_all_account_ids_exclude(self, pi_accounts_in_db):
        """
        Get accounts ID excluded

        accounts = clean + dry_run + excluded

        excluded: excluded accounts, should not do anything on it.
        clean: accounts to run and clean unused iam 
        dryrun: accounts to run but do not do any action
        """
        if self.is_pattern_include_exclude_updateable():
            ci_exclude_account_ids = self._get_exclude_accounts()
            exclude_env_tags = self._get_exclude_env_tags()
            exclude_account_ids = [x['accountId']['S'] for x in pi_accounts_in_db
                                if x['environment']['S'].lower() in exclude_env_tags 
                                or x['accountId']['S'] in ci_exclude_account_ids]
            return deepcopy(exclude_account_ids)
        else:
            raise ValueError("Invalid accounts filter pattern")


    def _compute_all_account_ids_include(self, pi_accounts_in_db):
        """
        Get accounts ID inluded
        Note: this is only for account id configed, 
              Not means all will be included to run clean task
              Only accounts in this list might have chance to be run task

        accounts = clean + dry_run + excluded

        excluded: excluded accounts, should not do anything on it.
        clean: accounts to run and clean unused iam 
        dryrun: accounts to run but do not do any action
        """
        if self.is_pattern_include_exclude_updateable():
            ci_include_account_ids = self._get_include_accounts()
            include_env_tags = self._get_include_env_tags(case_to="lower")
            include_account_ids = [x['accountId']['S'] for x in pi_accounts_in_db
                                if x['environment']['S'].lower() in include_env_tags 
                                or x['accountId']['S'] in ci_include_account_ids]
            return deepcopy(include_account_ids)
        else:
            raise ValueError("Invalid accounts filter pattern")

    def compute_accounts_included(self, pi_accounts_in_db):
        """
        Analysis and work out accounts those will be 
        included in the task to work on
        """
        if self.is_pattern_include_exclude_updateable():
            exclude_account_ids = self._compute_all_account_ids_exclude(pi_accounts_in_db)
            include_account_ids = self._compute_all_account_ids_include(pi_accounts_in_db)
            task_included_accounts = [x for x in pi_accounts_in_db
                                    if x['accountId']['S'] in include_account_ids
                                    if x['accountId']['S'] not in exclude_account_ids]
            return deepcopy(task_included_accounts)
        else:
            raise ValueError("Invalid accounts filter pattern")

    def compute_account_ids_included(self, pi_accounts_in_db):
        """
        Analysis and work out account ids those will be 
        included in the task to work on
        """
        if self.is_pattern_include_exclude_updateable():
            task_included_accounts = self.compute_accounts_included(pi_accounts_in_db)
            task_included_account_ids = [x['accountId']['S'] for x in task_included_accounts]
            return task_included_account_ids
        else:
            raise ValueError("Invalid accounts filter pattern")


    def compute_updateable_accounts(self, pi_accounts_in_db):
        """
        Compute accounts that can be updated in the task

        accounts_included_in_task = (include - excluded)
        task_updateable_accounts = 
                        (updateable_accounts + updateable_env_tags) 
                    AND id in accounts_included_in_task
        """
        if self.is_pattern_include_exclude_updateable():
            if pi_accounts_in_db:
                ci_updateable_account_ids = self._get_updateable_accounts()
                ci_updateable_env_tags = self._get_updateable_env_tags()
                account_ids_included_in_task = self.compute_account_ids_included(pi_accounts_in_db)
                clean_accounts = [x for x in pi_accounts_in_db
                                if x['accountId']['S'] in account_ids_included_in_task
                                if x['accountId']['S'] in ci_updateable_account_ids
                                or x['environment']['S'].lower() in ci_updateable_env_tags ]
                return deepcopy(clean_accounts)
            else:
                return None
        else:
            raise ValueError("Invalid accounts filter pattern")

    def compute_reportonly_accounts(self, pi_accounts_in_db):
        """
        Compute accounts that report only in the task

        accounts_included_in_task = (include - excluded)
        task_reportonly_accounts = 
                    accounts_included_in_task - task_updateable_accounts
        """
        if self.is_pattern_include_exclude_updateable():
            if pi_accounts_in_db:
                task_updateable_accounts = self.compute_updateable_accounts(pi_accounts_in_db)
                task_updateable_account_ids = [x['accountId']['S'] for x in task_updateable_accounts]

                account_ids_included_in_task = self.compute_account_ids_included(pi_accounts_in_db)

                reportonly_accounts = [x for x in pi_accounts_in_db
                                    if x['accountId']['S'] in account_ids_included_in_task
                                    if x['accountId']['S'] not in task_updateable_account_ids]

                return deepcopy(reportonly_accounts)
            else:
                return None
        else:
            raise ValueError("Invalid accounts filter pattern")

    def extract_account_iam_filter(self, pi_account_id):
        """
        Extract related account_id's iam policy
         "431525257644": {
                            "iam": {
                               "filter_pattern":"Exclude",
                                   "exclude": {
                                       "users": [],
                                       "user_key_ids": [],
                                       "console_login": []
                                   }
                                }
                          },
            ...
        """
        if self.is_pattern_include_exclude_updateable():
            account_plus = self._get_account_plus()
            if account_plus:
                return account_plus.get(pi_account_id)
            else:
                return None
        else:
            raise ValueError("Invalid accounts filter pattern")

