
"""
Module: news_account
Create Date: 2018-08-06
Function: Implement news account module.
"""

from copy import deepcopy
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI
from autolib.libaws.iam.aws_role import AwsRoleI
from autolib.libaws.aws_dynamodb import AwsDynamodbI


class NewsRole():
    """
    NewsOrg Class.

    ----------------------------
    |       NewsAccount         | News account class
    ----------------------------
    |       AWS Account         | AWS account
    ----------------------------

    Including functions in account management level.
    """

    def __init__(self, **kwargs):
        """
        Parameters
        Session: if input session, will not use aws_access_key_id,
                aws_secret_access_key,aws_session_token to create new session 
                again.

        aws_access_key_id (string) -- AWS access key ID
        aws_secret_access_key (string) -- AWS secret access key
        aws_session_token (string) -- AWS temporary session token
        region_name (string) -- Default region when creating new connections
        botocore_session (botocore.session.Session) -- Use this Botocore
                session instead of creating a new default one.
        profile_name (string) -- The name of a profile to use. If not given,
                then the default profile is used.


        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(**kwargs)
        self.__session = self.__session_rw
        self._roles = None

    @classmethod
    def get_roles_from_db(cls, pi_session, pi_table_name, pi_task_name):
        """
        Load all roles rows from dynamodb table into self._roles. 
        Input:
            pi_table_name: the table name to scan

        table columns:  type(ro|rw), tool,  role
        Return:
            rows_info, dict type
            format as following:
            {
                'default' :{
                             'ro':'default_readonly_role',
                             'rw':'default_readwrite_role'
                },
                 'toolx' :{
                             'ro':'toolx_readonly_role',
                             'rw':'toolx_readwrite_role'
                 }
            }
        """
        dbi = AwsDynamodbI(pi_session)
        #result = dbi.query_by_key_in(pi_table_name, 'tool', "'L': [{'S':{}},{'S':{}}]".format('default',pi_task_name))
        result = dbi.scan_query_str_in(pi_table_name, 'tool', [
                                       'default', pi_task_name])
        if result:
            roles = {'Items': result['Items'],
                     'Count': result['Count'],
                     'ScannedCount': result['ScannedCount']}
            return roles
        else:
            return None

    def load_roles(self, pi_table_name, pi_task_name):
        self._roles = self.get_roles_from_db(
            self.__session_ro, pi_table_name, pi_task_name)

    def lazy_load_roles(self, pi_table_name, pi_task_name):
        if self._roles is None:
            self.load_roles(pi_table_name, pi_task_name)

    def get_role(self, pi_rw='ro'):
        """
        Get role credential by account id

        pi_rw: ro | rw
               ro: read only
               rw: read write

        dynamodb table columns:
        type(ro,rw), tool, role
        """
        rows = [x for x in self._roles['Items']]
        roles = [x['role']['S'] for x in rows
                 if x['tool']['S'] != 'default'
                 if x['type']['S'] == pi_rw]
        if roles:
            return roles[0]
        else:
            roles = [x['role']['S'] for x in rows
                     if x['tool']['S'] == 'default'
                     if x['type']['S'] == pi_rw]
            if roles:
                return roles[0]
            else:
                return None

    def assume_role_byaccid(self,
                            pi_table_name,
                            pi_task_name,
                            pi_account_id,
                            pi_region,
                            pi_rw='ro'):
        """
        Assume to new role, return session

        Get role credential by account id
        Returns a set of temporary security credentials 
        (consisting of an access key ID, a secret access key, 
        and a security token) that you can use to access AWS 
        resources that you might not normally have access to.

        return: session (new role)
        """
        self.lazy_load_roles(pi_table_name, pi_task_name)
        Log2.debug("roles information: {}".format(self._roles))
        role = self.get_role(pi_rw)
        #
        # get credential by arn
        #
        arn = 'arn:aws:iam::{0}:role/{1}'.format(pi_account_id, role)
        session_name = "{}-{}-{}".format(pi_task_name, pi_account_id, role)

        #
        # assume role to get new role session
        #
        try:
            Log2.debug("assume to arn: {}".format(arn))
            aws_role = AwsRoleI(session_rw=self.__session_rw,
                                session_ro=self.__session_ro)
            session = aws_role.assume_role(arn, session_name)
        except Exception as e:
            Log2.error("assume role {} failed: {}".format(arn, str(e)))
            raise
        return session

    def assume_role_byaccid_rw(self,
                               pi_table_name,
                               pi_task_name,
                               pi_account_id,
                               pi_region):
        """
        Assume to new role, return both read only and read-write session.
        return (session_ro, session_rw)
        """
        session_ro = self.assume_role_byaccid(
            pi_table_name, pi_task_name, pi_account_id, pi_region, "ro")
        session_rw = self.assume_role_byaccid(
            pi_table_name, pi_task_name, pi_account_id, pi_region, "rw")
        return (session_ro, session_rw)
