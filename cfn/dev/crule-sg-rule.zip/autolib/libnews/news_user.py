"""
Module: news_account
Create Date: 2018-09-13
Function: Implement news account module.
"""

from copy import deepcopy
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc, CommConstV
from autolib.libaws.aws_session import AwsSessionI
from autolib.libaws.iam.aws_user import AwsUserI

class NewsUser(AwsUserI):
    """
    NewsUser Class.

    Including functions in user level.
    """

    def __init__(self, pi_username, session_ro=None, session_rw=None, session=None, lazy_load=True):
        AwsSessionI.c_init(session_ro=session_ro, session_rw=session_rw, session=session)
        super().__init__(pi_username, session_ro=session_ro, session_rw=session_rw, session=session, lazy_load=lazy_load)


    def disable_console_if(self, pi_utc_tl_to_warning, pi_utc_tl_to_disable, pi_iam_filter=None, p_acl=CommConstV.ACL_DEFAULT):
        """
        time line: -------------------------------------------------------->
                                |              |                    |
                   <- disalbe ->|<-  warning ->|                   now

        Disable console login if console:
        if last_login_time not None:
            Warning: pi_utc_tl_to_disable <= last login time < pi_utc_tl_to_warning
            Disable: last login time < pi_utc_disable_tl
        else:
            Warning: pi_utc_tl_to_disable <= create time < pi_utc_tl_to_warning
            Disable: create time < pi_utc_disable_tl

        return format:
           {
               "CreateDate":
               "PasswordLastUsed":
               "Action": 'disabled' | 'warning'
           }
        """
        if pi_iam_filter:
            real_acl = pi_iam_filter.compute_console_login_acl(self.get_name(), p_acl)
        else:
            real_acl = p_acl
        if CommFunc.is_aws_exclude(real_acl):
            return None

        result = None
        password_last_used = self.get_password_last_used_time()
        login_create_dt = self.get_create_dt()
        if password_last_used is None:
            if login_create_dt < pi_utc_tl_to_disable:
                self.risky_disable_console_login(p_acl=real_acl)
                result = { 'Action': 'disabled' }
            elif login_create_dt < pi_utc_tl_to_warning:
                result = { 'Action': 'warning' }
        elif password_last_used < pi_utc_tl_to_disable:
                self.risky_disable_console_login(p_acl=real_acl)
                result = { 'Action': 'disabled' }
        elif password_last_used < pi_utc_tl_to_warning:
                result = { 'Action': 'warning' }
        if result:
            result['CreateDate'] = login_create_dt
            result['PasswordLastUsed'] = password_last_used
            result['real_acl'] = real_acl
        return result

    def disable_keys_if(self, pi_utc_tl_to_warning, pi_utc_tl_to_disable, pi_iam_filter, p_acl=CommConstV.ACL_DEFAULT):
        """
        Check user access keys if need to be disabled or warning

        time line: --------------------------------------------------------
                                |              |                    |
                   <- disalbe ->|<-  warning ->|                   now

       if last_used_dt not None:
            Warning: pi_utc_diable_tl  =< last used date < pi_utc_warning_tl
            Disable: last used date < pi_utc_disable_tl
        else:
            Warning: pi_utc_diable_tl  =< create time < pi_utc_warning_tl
            Disable: create time < pi_utc_disable_tl

        if key has warning or disable action, then return as following:
            {
                "Disabled": [
                                {
                                    "Key":""
                                    "LastUsed":
                                    "CreateDate":
                                    "real_acl":
                                },
                              },
                            ]
                "Warning": [
                                {
                                    "Key":""
                                    "LastUsed":
                                    "CreateDate":
                                    "real_acl":
                                },
                            ]
            }
        if no any warning and disable action, then:
            return None
        """
        keys_list = self.get_access_keys_active(None, pi_utc_tl_to_warning)
        result = {}
        if keys_list:
            # those keys' create_time is before warning time line,
            # and it in 'Active' status
            for key in keys_list:
                if pi_iam_filter:
                    real_acl = pi_iam_filter.compute_user_key_id_acl(self.get_name(), key, p_acl)
                else:
                    real_acl = p_acl
                if CommFunc.is_aws_exclude(real_acl):
                    continue

                last_used_dt = self.get_access_key_last_used_time(key)
                create_dt = self.get_access_key_create_date(key)
                to_disable = False
                to_warning = False
                if last_used_dt is None:
                    if create_dt < pi_utc_tl_to_disable:
                        to_disable = True
                    elif create_dt < pi_utc_tl_to_warning:
                        to_warning = True
                elif last_used_dt < pi_utc_tl_to_disable:
                        to_disable = True
                elif last_used_dt < pi_utc_tl_to_warning:
                        to_warning = True

                item_key = None
                if to_disable:
                    self.risky_set_access_key_inactivate(key, p_acl=real_acl)
                    item_key = "Disabled"
                elif to_warning:
                    item_key = "Warning"

                if to_disable or to_warning:
                    if result.get(item_key) is None:
                        result[item_key] = [{"Key": key,
                                            "LastUsed": last_used_dt,
                                            "CreateDate": create_dt,
                                            "real_acl": real_acl,
                                            }]
                    else:
                        result[item_key] += [{"Key": key,
                                            "LastUsed": last_used_dt,
                                            "CreateDate": create_dt,
                                            "real_acl": real_acl}]
        return result

    def disable_if(self, pi_utc_tl_to_warning, pi_utc_tl_to_disable, pi_iam_filter, p_acl=CommConstV.ACL_DEFAULT, **kwargs):
        """
        Disalbe user console login and access keys based on
        pi_utc_tl_to_warning and pi_utc_tl_to_disable
        time line: --------------------------------------------------------
                                |              |                    |
                   <- disalbe ->|<-  warning ->|                   now


        :pi_iam_filter: Insance of AwsIamFilter



        if user has action for disable or warning, then
        return format as following:
        {
            "User": "hello"
            "p_acl": "acl_rdonly"
            "ConsoleLogin": {                       <---
                    "CreateDate":                       | Including only when
                    "PasswordLastUsed":                 | console have action
                    "Action": 'disabled' | 'warning'    | to disable or warning
                    }                               <---
            "AccessKeys":                           <---
                {"Disabled":                            |
                    [                                   |
                        {                               |
                            "Key":"xxxxxxxx"            |
                            "LastUsed":                 |
                            "CreateDate":               |
                        },                              | Including only when
                    ]                                   | user have keys
                }                                       | to be disabled or
                {"Warning":                             | warning
                    [                                   |
                        {                               |
                            "Key":"yyyyy"               |
                            "LastUsed":                 |
                            "CreateDate":               |
                        },                              |
                    ]                                   |
                }                                   <---
        }
        """
        if self.is_inactive():
            return None
        Log2.debug_l(4, "disable_if user:{} warning:{}, disable:{}, input_p_acl:{} ...".format(self.get_name(), 
                    pi_utc_tl_to_warning, pi_utc_tl_to_disable, p_acl))

        result = {}
       
        #
        # Check console login if need to be disabled
        #
        if self.is_console_login_enabled():
            console_result = self.disable_console_if(pi_utc_tl_to_warning,
                                                 pi_utc_tl_to_disable,
                                                 pi_iam_filter,
                                                 p_acl=p_acl)
            if console_result:
                result['ConsoleLogin'] = console_result

        #
        # Check keys if need to be disabled or warning
        #
        keys_result = self.disable_keys_if(pi_utc_tl_to_warning,
                                           pi_utc_tl_to_disable,
                                           pi_iam_filter,
                                           p_acl=p_acl)
        if keys_result:
            result['AccessKeys'] = keys_result

        if result:
            result['User'] = deepcopy(self.get_name())
            result['p_acl'] = deepcopy(p_acl)
            Log2.debug_l(4, "         ... done."), 
        else:
            Log2.debug_l(4, "         ... excepted."), 
        return result




###############################################################################
# NewsIamFilter
###############################################################################
class NewsIamFilter():
    """
    class of News IAM Filter

    format:
    {
        "filter_pattern":"EXCLUDE_RDONLY",
        "exclude": {
            "users": ["john", "daniel"],
            "user_key_ids": ["xxxyyyxxxx", "xxxxyyyxxxxyxx"],
            "console_logins": ["john"]
        }
        "readonly": {
            "users": ["john", "daniel"],
            "user_key_ids": ["xxxyyyxxxx", "xxxxyyyxxxxyxx"],
            "console_logins": ["john"]
        }
    }
    filter_pattern: Include_Exclude | Exclude
        Exclude_readonly: from full list, define exclude list and readonly list.
                result_list = include_list - exclude list.
                IAM defined in readonly list, IAM resource will be protected, not be updated
        Exclude: from full list, define exclude list.
                result_list = full_list - exclude list.
        
    Note: Currently only support EXCLUDE_RDONLY

    """
    def __init__(self, config=None, config_file=None):
        """
        Init
        """
        self.__config = CommFunc.get_config(config, config_file)

    def get_config(self):
        return deepcopy(self.__config)

    def is_filter_pattern_exclude_readonly(self):
        return CommFunc.is_filter_pattern_exclude_readonly(self.__config.get('filter_pattern'))

    def _get_exclude_conf(self):
        return self.__config.get("exclude") or {}

    def _get_exclude_users_conf(self):
        """
        Get exclude users list
        """
        if self.is_filter_pattern_exclude_readonly():
            return (self._get_exclude_conf().get("users") or [])
        else:
            raise ValueError("Invalid Filter Pattern")

    def _get_exclude_console_logins_conf(self):
        """
        Get exclude Console Login list
        """
        if self.is_filter_pattern_exclude_readonly():
            return (self._get_exclude_conf().get("console_logins") or [])
        else:
            raise ValueError("Invalid Filter Pattern")

    def _get_exclude_user_key_ids_conf(self):
        """
        Get exclude user keys' ID list
        """
        if self.is_filter_pattern_exclude_readonly():
            return (self._get_exclude_conf().get("user_key_ids") or [])
        else:
            raise ValueError("Invalid Filter Pattern")


    def is_user_exclude(self, pi_user_name, case_sensitive=False):
        """
        Check if user in exlude list

        case_sensitive: True|False, define if user name is case_sensitive
        """
        if self.is_filter_pattern_exclude_readonly():
            return CommFunc.is_str_in_list(pi_user_name, 
                                           self._get_exclude_users_conf(), 
                                           case_sensitive)
        else:
            raise ValueError("Invalid Filter Pattern")

    def is_console_login_exclude(self, pi_user_name, case_sensitive=False):
        """
        Check if user console login in exlude list
        """
        if self.is_user_exclude(pi_user_name, case_sensitive):
            return True
        else:
            if self.is_filter_pattern_exclude_readonly():
                return CommFunc.is_str_in_list(pi_user_name,
                                               self._get_exclude_console_logins_conf(),
                                               case_sensitive
                                               )
            else:
                raise ValueError("Invalid Filter Pattern")
                            

    def is_user_key_id_exclude(self, pi_user_name, pi_key_id, case_sensitive=False):
        """
        Check if user key id in exlude list
        
        default case insensitive
        """
        if self.is_user_exclude(pi_user_name, case_sensitive):
            return True
        else:
            if self.is_filter_pattern_exclude_readonly():
                if pi_key_id in (self._get_exclude_user_key_ids_conf() or []):
                    return True
                else:
                    return False
            else:
                raise ValueError("Invalid Filter Pattern")


    #
    # Readonly configuration
    #
    def _get_readonly_conf(self):
        """
        Get readonly config, dict
        """
        return self.__config.get("readonly") or {}


    def _get_readonly_users_conf(self):
        """
        Get readonly users config
        """
        if self.is_filter_pattern_exclude_readonly():
            return (self._get_readonly_conf().get("users") or [])
        else:
            raise ValueError("Invalid Filter Pattern")

    def _get_readonly_console_logins_conf(self):
        """
        Get readonly console login config
        """
        if self.is_filter_pattern_exclude_readonly():
            return (self._get_readonly_conf().get("console_logins") or [])
        else:
            raise ValueError("Invalid Filter Pattern")

    def _get_readonly_user_key_ids_conf(self):
        """
        Get readonly user access key ids config
        """
        if self.is_filter_pattern_exclude_readonly():
            return (self._get_readonly_conf().get("user_key_ids") or [])
        else:
            raise ValueError("Invalid Filter Pattern")


    def is_user_in_readonly_conf(self, pi_user_name, case_sensitive=False):
        """
        Check if user in readonly config

        Important Note: 
            In readonly config, not means that user must included, so should check if user include as well

        case_sensitive: True|False, define if user name is case_sensitive
        """
        if self.is_filter_pattern_exclude_readonly():
            return CommFunc.is_str_in_list(pi_user_name, 
                                           self._get_readonly_users_conf(), 
                                           case_sensitive)
        else:
            raise ValueError("Invalid Filter Pattern")


    def is_console_login_in_readonly_conf(self, pi_user_name, case_sensitive=False):
        """
        Check if user console login in readonly config
        """
        if self.is_filter_pattern_exclude_readonly():
            return CommFunc.is_str_in_list(pi_user_name,
                                           self._get_readonly_console_logins_conf(),
                                           case_sensitive
                                          )
        else:
            raise ValueError("Invalid Filter Pattern")
                            
    def is_user_key_id_in_readonly_conf(self, pi_key_id, case_sensitive=False):
        """
        Check if user access_key id in readonly config
        """
        if self.is_filter_pattern_exclude_readonly():
            print("----- debug:  key:{} conf:{}".format(pi_key_id, self._get_readonly_user_key_ids_conf()))
            return CommFunc.is_str_in_list(pi_key_id,
                                           self._get_readonly_user_key_ids_conf(),
                                           case_sensitive
                                          )
        else:
            raise ValueError("Invalid Filter Pattern")
                            

    def compute_console_login_acl(self, pi_user_name, parent_p_acl, case_sensitive=False):
        """
        Work out a user's console login ACL

        Important:
        The compute logic is based on safe principle:
        1. Whichever iam config or parent level(org or account) defined readonly, then will set acl as readonly.
        2. Only both parent p_acl is readwrite and iam config is readwrite, the acl will be readwrite.
        """
        if self.is_filter_pattern_exclude_readonly():
            if (self.is_console_login_exclude(pi_user_name, case_sensitive)):
                return CommConstV.ACL_EXCLUDE
            elif (self.is_user_in_readonly_conf(pi_user_name, case_sensitive)):
                return CommConstV.ACL_RDONLY
            elif (self.is_console_login_in_readonly_conf(pi_user_name, case_sensitive)):
                return CommConstV.ACL_RDONLY
            else:
                if CommFunc.is_aws_readwrite(parent_p_acl): # parent_p_acl must allowed to be readwrite as well
                    return CommConstV.ACL_RDWR_RISKY
                else:
                    return CommConstV.ACL_RDONLY
        else:
            raise ValueError("Invalid Filter Pattern")


    def compute_user_key_id_acl(self, pi_user_name, pi_key_id, parent_p_acl, case_sensitive=False):
        """
        Work out a user's key id ACL

        Important:
        The compute logic is based on safe principle:
        1. Whichever iam config or parent level(org or account) defined readonly, then will set acl as readonly.
        2. Only both parent p_acl is readwrite and iam config is readwrite, the acl will be readwrite.
        """
        if self.is_filter_pattern_exclude_readonly():
            if (self.is_user_key_id_exclude(pi_user_name, pi_key_id, case_sensitive)):
                return CommConstV.ACL_EXCLUDE
            elif self.is_user_in_readonly_conf(pi_user_name, case_sensitive):
                return CommConstV.ACL_RDONLY
            elif self.is_user_key_id_in_readonly_conf(pi_key_id, case_sensitive):
                return CommConstV.ACL_RDONLY
            else:
                if CommFunc.is_aws_readwrite(parent_p_acl): # parent_p_acl must allowed to be readwrite as well
                    return CommConstV.ACL_RDWR_RISKY
                else:
                    return CommConstV.ACL_RDONLY
        else:
            raise ValueError("Invalid Filter Pattern")





