"""
Module: news_sg
Create Date: 2018-07-31
Function: Implement
"""

# from autolib.libcomm.log2 import Log2
from copy import deepcopy
from autolib.libaws.aws_sg import AwsSecurityGroupI
from autolib.libaws.aws_eni import AwsNetworkInterfaceI
from autolib.libaws.aws_lambda import AwsLambdaI
from autolib.libaws.aws_session import AwsSessionI


class NewsSecurityGroup:
    """
    NewsSecurityGroup Class.

    Including functions in organization management level.
    """

    def __init__(self, pi_session_ro=None, pi_session_rw=None, pi_session=None, **kwargs):
        """Initalization."""
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)
        self.__security_groups = None
        self.__ingress_rules = None
        self.__egress_rules = None
        self.__block_rules = None

    def describe_security_groups(self, pi_sg_id=None):
        """Describe security groups."""

        sg = AwsSecurityGroupI(session_ro=self.__session_ro)

        params = {}
        if pi_sg_id:
            if isinstance(pi_sg_id, (set, list, tuple)):
                params['GroupIds'] = list(pi_sg_id)
            else:
                params['GroupIds'] = [pi_sg_id]

        result = sg.describe_security_groups(**params)

        return result.get('SecurityGroups')

    def lazy_describe_security_groups(self, pi_sg_id=None):
        """Lazy load security groups."""

        if self.__security_groups is None:
            self.__security_groups = self.describe_security_groups(pi_sg_id=pi_sg_id)

        return deepcopy(self.__security_groups)

    def revoke_security_group_ingress(self, **kwargs):
        """Remove SG ingress rule"""
        sg = AwsSecurityGroupI(session_rw=self.__session_rw)
        response = sg.revoke_security_group_ingress(**kwargs)
        return response

    def delete_security_group(self, **kwargs):
        """Remove SG"""
        sg = AwsSecurityGroupI(session_rw=self.__session_rw)
        response = sg.delete_security_group(**kwargs)
        return response

    def retrieve_sg_attached_to_eni(self, pi_eni_id=None, pi_sg_id=None):
        """
        Retrieve SGs which are attached to any ENI
        Input:
            pi_eni_id: one single network interface or a collection of network interface id
            pi_sg_id: one single SG id or a collection of SG id
        """
        response = None
        sg_list = []
        params = {}

        eni = AwsNetworkInterfaceI(session_ro=self.__session_ro)

        if pi_eni_id:
            if isinstance(pi_eni_id, (set, list, tuple)):
                params['NetworkInterfaceIds'] = list(pi_eni_id)
            else:
                params['NetworkInterfaceIds'] = [pi_eni_id]

        if pi_sg_id:
            if isinstance(pi_sg_id, (set, list, tuple)):
                params['Filters'] = [{
                    'Name': 'group-id',
                    'Values': list(pi_sg_id)
                }]
            else:
                params['Filters'] = [{
                    'Name': 'group-id',
                    'Values': [pi_sg_id]
                }]

        result = eni.describe_network_interfaces(**params)

        # add all SG id into a array
        for eni_item in result.get('NetworkInterfaces'):
            if eni_item.get('Groups'):
                for sg_item in eni_item.get('Groups'):
                    if sg_item.get('GroupId'):
                        sg_list.append(sg_item.get('GroupId'))

        # deduplicate SG ids
        if sg_list:
            response = list(set(sg_list))

        return response

    def retrieve_sg_attached_to_lambda(self):
        """
        Retrieve SGs which are attached to the Lambda function
        """
        response = None
        lambda_list = []
        sg_list = []

        # retrieve the all lambda or given lambda
        lambda_function = AwsLambdaI(session_ro=self.__session_ro)
        result = lambda_function.list_functions()
        if result.get('Functions'):
            for item in result.get('Functions'):
                if item.get('FunctionName'):
                    lambda_list.append(item.get('FunctionName'))

        # add all SG id into a array
        if lambda_list:
            for item in lambda_list:
                result = lambda_function.get_function_configuration(FunctionName=item)
                if 'VpcConfig' in result and 'SecurityGroupIds' in result['VpcConfig'] and result['VpcConfig']['SecurityGroupIds']:
                    sg_list.extend(result['VpcConfig']['SecurityGroupIds'])

        # deduplicate SG ids
        if sg_list:
            response = list(set(sg_list))

        return response
