"""
Wrapper of  AWS CloudTrail API
"""
from autolib.libaws.aws_session import AwsSessionI

class AwsCloudtrailI:
    def __init__(self,  session_ro=None, session_rw=None, session=None, pi_auto_cache=None):
        """Initalization."""
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, 
                                                                    session_rw=session_rw, 
                                                                    session=session)
        self.__session = self.__session_ro
        self.__client = self.__session.client('cloudtrail')
        self.__auto_cache = pi_auto_cache

    def describe_trails(self, **kwargs):
        """Desribe the given CloudTrails."""
        response = self.__client.describe_trails(**kwargs)
        return response

    def create_trail(self, **kwargs):
        """Create a trail."""

        response = self.__client.create_trail(**kwargs)
        return response

    def update_trail(self, **kwargs):
        """Update a trail."""

        response = self.__client.update_trail(**kwargs)
        return response

    def start_logging(self, **kwargs):
        """Start logging."""

        response = self.__client.start_logging(**kwargs)
        return response

    def get_trail_status(self, **kwargs):
        """Get logging status."""

        response = self.__client.get_trail_status(**kwargs)
        return response
