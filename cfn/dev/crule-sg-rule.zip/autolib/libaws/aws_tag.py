"""
Implement Tag module, orgnize all the tag related functions.
Role
IAM
Usser
"""

from autolib.libaws.aws_session import AwsSessionI
from autolib.libcomm.commfunc import CommFunc

class AwsTagI:
    def __init__(self, session_ro=None, session_rw=None, session=None, pi_auto_cache=None):
        """ Initalization. """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro,
                                                                    session_rw=session_rw,
                                                                    session=session)
        self.__session = self.__session_ro
        self.__auto_cache = pi_auto_cache

    @classmethod
    def c_get_tag_value(cls, pi_tag_key, pi_tags, pi_key_case_sensitive=False):
        """Return the tag value."""
        if pi_tag_key and pi_tags:
            # if tags is in the format of [{'Key': 'key-name', 'Value':'value1'}, ....]
            if isinstance(pi_tags, list):
                for tag in pi_tags:
                    if pi_key_case_sensitive:
                        if tag['Key'] == pi_tag_key:
                            return tag['Value']
                    else:
                        if tag['Key'].lower() == pi_tag_key.lower():
                            return tag['Value']
            # if tags is in the format of {'key1':'value1','key2':'value2'}
            elif isinstance(pi_tags, dict):
                if pi_key_case_sensitive:
                    return pi_tags.get(pi_tag_key)
                else:
                    for tag_key, tag_value in pi_tags.items():
                        if tag_key.lower() == pi_tag_key.lower():
                            return tag_value
        return None

    @classmethod
    def c_get_bu_value(cls, pi_tags):
        return cls.c_get_tag_value(
            pi_tag_key='Bu',
            pi_tags=pi_tags
        )

    @classmethod
    def c_get_product_value(cls, pi_tags):
        return cls.c_get_tag_value(
            pi_tag_key='Product',
            pi_tags=pi_tags
        )

    @classmethod
    def c_is_preserved(cls, pi_tags):
        preserve_tag_value = cls.c_get_tag_value(
            pi_tag_key='Preserve',
            pi_tags=pi_tags
        )

        if preserve_tag_value and CommFunc.is_str_true_or_bool_true(preserve_tag_value):
            return True
        else:
            return False
