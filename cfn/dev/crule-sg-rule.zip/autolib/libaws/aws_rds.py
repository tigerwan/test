"""
This module implements AWS RDS db instance interface.
"""
from copy import deepcopy
from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI


class AwsRdsI:
    """ RDS db instance operation """
    def __init__(self, session_ro=None, session_rw=None, session=None, **kwargs):
        """
        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, session_rw=session_rw, session=session, **kwargs)
        self.__session = self.__session_ro
        self.__client = self.__session.client('rds')
        self.__db_instances = None

    def describe_db_instances(self, **kwargs):

        params = deepcopy(kwargs)

        db_instances = self.__client.describe_db_instances(**params)
        all_db_instances = db_instances
        marker = db_instances.get('Marker')
        while marker:
            params['Marker'] = marker
            db_instances = self.__client.describe_db_instances(**params)
            if len(db_instances['DBInstances']) > 0:
                all_db_instances['DBInstances'] += db_instances['DBInstances']
            else:
                break
            marker = db_instances.get('Marker')
        self.__db_instances = all_db_instances
        return self.__db_instances

    def load_db_instances(self):
        """
        Get all RDS db instances describe information.

        Input:
        Output:

        Return:
            all_db_instances
        """

        return self.describe_db_instances()

    def lazy_load_db_instances(self):
        """
        Get all RDS db instances describe information.

        Input:
        Output:

        Return:
            all_db_instances
        """
        if not self.__db_instances:
            self.describe_db_instances()

        return self.__db_instances

    def get_db_instances(self):
        """Get all RDS db instances."""
        if not self.__db_instances:
            self.lazy_load_db_instances()
        return self.__db_instances

    def describe_db_instances_by_id(self, pi_db_id):
        """Retrive one single db instance."""
        params = {
            'DBInstanceIdentifier': pi_db_id
        }

        return self.describe_db_instances(**params)

    def list_tags_for_resource(self, **kwargs):
        return self.__client.list_tags_for_resource(**kwargs)

    def list_tags(self, pi_db_arn):
        return self.__client.list_tags_for_resource(ResourceName=pi_db_arn)
