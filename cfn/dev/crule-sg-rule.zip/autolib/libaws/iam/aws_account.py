"""
Module: aws_account
Create Date: 2018-07-30
Function: Implement aws account module.
"""

from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI
from autolib.libaws.iam.aws_user import AwsUserI
from autolib.libaws.aws_s3 import AwsS3I
from copy import deepcopy


class AwsAccountI:
    """
    Account class.
    ----------------------------
    |       Account            | AWS account level class
    ----------------------------
    |       User ...           | AWS User class
    ----------------------------

    private use and public use
    --------------------------
    For class internal use: call _get_access_keys_info(), for faster
    For public use: call get_access_keys_info(), for safe
    """

    def __init__(self, **kwargs):
        """
        Parameters
        Session: if input session, will not use aws_access_key_id,
                aws_secret_access_key,aws_session_token to create new session 
                again.

        aws_access_key_id (string) -- AWS access key ID
        aws_secret_access_key (string) -- AWS secret access key
        aws_session_token (string) -- AWS temporary session token
        region_name (string) -- Default region when creating new connections
        botocore_session (botocore.session.Session) -- Use this Botocore
                session instead of creating a new default one.
        profile_name (string) -- The name of a profile to use. If not given,
                then the default profile is used.

        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(**kwargs)

        self.__iam_ro = self.__session_ro.client('iam')

        self.__current_account_info = None
        self.__account_id = self.get_current_account()
        self.__lazy_load = CommFunc.if_none_or_empty(kwargs.get('LazyLoad'), True)
        self.__users = None
        self.__roles = None

        self._account_summary = None
        if not self.__lazy_load:
            self.lazy_get_summary()

    def get_session_ro(self):
            return self.__session_ro

    def get_session_rw(self):
            return self.__session_rw

    @classmethod
    def get_caller_info(cls, pi_session):
        """
        Get caller account ID information
        {
            'UserId': 'string',
            'Account': 'string',
            'Arn': 'string'
        }
        """
        _sts = pi_session.client('sts')
        return _sts.get_caller_identity()

    @classmethod
    def get_caller_account_id(cls, pi_session):
        """
        Get caller account id
        """
        return cls.get_caller_info(pi_session).get('Account')

    def get_current_account_info(self):
        """
        Get current account information from AWS
        {
            'UserId': 'string',
            'Account': 'string',
            'Arn': 'string'
        }
        """
        return self.get_caller_info(self.__session_ro)

    def lazy_get_current_account_info(self):
        if self.__current_account_info is None:
            self.__current_account_info = self.get_current_account_info()
        return self.__current_account_info; 
        

    def get_current_account(self):
        self.lazy_get_current_account_info()
        return deepcopy(self.__current_account_info.get('Account'))

    def get_current_arn(self):
        self.lazy_get_current_account_info()
        return deepcopy(self.__current_account_info.get('Arn'))

    def get_current_userid(self):
        self.lazy_get_current_account_info()
        return deepcopy(self.__current_account_info.get('UserId'))

    def get_summary(self):
        """
        Get account summary information
        Request:
        Return: dict type as following
        {
            'SummaryMap': {
                'AccessKeysPerUserQuota': 2,
                'AccountAccessKeysPresent': 1,
                'AccountMFAEnabled': 0,
                'AccountSigningCertificatesPresent': 0,
                'AttachedPoliciesPerGroupQuota': 10,
                'AttachedPoliciesPerRoleQuota': 10,
                'AttachedPoliciesPerUserQuota': 10,
                'GroupPolicySizeQuota': 5120,
                'Groups': 15,
                'GroupsPerUserQuota': 10,
                'GroupsQuota': 100,
                'MFADevices': 6,
                'MFADevicesInUse': 3,
                'Policies': 8,
                'PoliciesQuota': 1000,
                'PolicySizeQuota': 5120,
                'PolicyVersionsInUse': 22,
                'PolicyVersionsInUseQuota': 10000,
                'ServerCertificates': 1,
                'ServerCertificatesQuota': 20,
                'SigningCertificatesPerUserQuota': 2,
                'UserPolicySizeQuota': 2048,
                'Users': 27,
                'UsersQuota': 5000,
                'VersionsPerPolicyQuota': 5,
            },
            'ResponseMetadata': {
                '...': '...',
            },
        }
        """
        return self.__iam_ro.get_account_summary()

    def lazy_get_summary(self):
        if not self._account_summary:
            self._account_summary = self.get_summary()
        return self._account_summary

    def get_users(self, **kwargs):
        """
        Get all users from AWS within current account

        return list as followign:
        [
            {
                'Path': 'string',
                'UserName': 'string',
                'UserId': 'string',
                'Arn': 'string',
                'CreateDate': datetime(2015, 1, 1),
                'PasswordLastUsed': datetime(2015, 1, 1),
                'PermissionsBoundary': {
                    'PermissionsBoundaryType': 'PermissionsBoundaryPolicy',
                    'PermissionsBoundaryArn': 'string'
                }
            },
        ]
        """
        pi_max_requests = CommFunc.if_none_or_empty(
                                kwargs.get('MaxRequest'), 100)

        users = self.__iam_ro.list_users()
        all_users = []
        all_users += users.get('Users')
        is_truncated = users.get('IsTruncated')
        request_count = 1
        if is_truncated and request_count < pi_max_requests:
            marker = users.get('Marker')
            while True:
                request_count += 1
                if request_count > pi_max_requests:
                    raise Exception("Truncated, max_request: {}, requested:{}"
                                    .format(pi_max_requests, request_count))
                kwargs['Marker'] = marker
                users = self.__iam_ro.list_users(kwargs)
                all_users += users.get('Users')
                is_truncated = users.get('IsTruncated')
                if not is_truncated:
                    break
                marker = users.get('Marker')
        return all_users

    def lazy_get_users(self, **kwargs):
        if not self.__users:
            self.__users = self.get_users(**kwargs)
        return self.__users

    def search_users(self,
                  pi_create_from_dt=None,
                  pi_create_to_dt=None,
                  **kwargs):
        """
        Get users which:
            pi_create_from_dt <= CreateDate  < pi_create_to_dt

            if pi_create_from_dt is None, means from beginning time
            if pi_create_to_dt is None, means to newest time.
        self.__users format:
        [
            {
                'Path': 'string',
                'UserName': 'string',
                'UserId': 'string',
                'Arn': 'string',
                'CreateDate': datetime(2015, 1, 1),
                'PasswordLastUsed': datetime(2015, 1, 1),
                'PermissionsBoundary': {
                    'PermissionsBoundaryType': 'PermissionsBoundaryPolicy',
                    'PermissionsBoundaryArn': 'string'
                }
            },
        ]
        """
        self.lazy_get_users(**kwargs)
        user_list = [x['UserName'] for x in self.__users
                     if CommFunc.time_in_range(x['CreateDate'],
                     pi_create_from_dt, pi_create_to_dt)]
        return deepcopy(user_list)

    def list_users(self,
                   pi_create_from_dt=None,
                   pi_create_to_dt=None,
                   **kwargs):
        return self.search_users(pi_create_from_dt,
                                 pi_create_to_dt,
                                 **kwargs)

    def show_users(self,
                   pi_create_from_dt=None,
                   pi_create_to_dt=None,
                   **kwargs):
        """
        Show users, and total users
        """
        CommFunc.show(self.search_users(**kwargs))
        total_users = len(self.__users)
        CommFunc.echo("\nTotal: {}\n".format(total_users))

    @classmethod
    def c_get_users(self, pi_key_id, pi_key, pi_token):
        """
        """
        account = AwsAccountI(aws_access_key_id=pi_key_id, 
                              aws_secret_access_key=pi_key,
                              aws_session_token=pi_token)
        return account.get_users()

    @classmethod
    def c_pull_users_to_file(cls, pi_file, **session_kwargs):
        account = AwsAccountI(**session_kwargs)
        users = account.search_users()
        CommFunc.write_json_file(users, pi_file)

    @classmethod
    def c_pull_users_to_file2(cls, pi_file, pi_key_id, pi_key, pi_token):
        cls.c_pull_users_to_file(pi_file, 
                                 aws_access_key_id=pi_key_id, 
                                 aws_secret_access_key=pi_key,
                                 aws_session_token=pi_token)




    def get_roles(self, **kwargs):
        """
        Get all roles from AWS within current account

        
        AWS list roles return list as followign:
        {
            'Roles': [
                {
                    'Path': 'string',
                    'RoleName': 'string',
                    'RoleId': 'string',
                    'Arn': 'string',
                    'CreateDate': datetime(2015, 1, 1),
                    'AssumeRolePolicyDocument': 'string',
                    'Description': 'string',
                    'MaxSessionDuration': 123,
                    'PermissionsBoundary': {
                        'PermissionsBoundaryType': 'PermissionsBoundaryPolicy',
                        'PermissionsBoundaryArn': 'string'
                    }
                },
            ],
            'IsTruncated': True|False,
            'Marker': 'string'
        }

        This Function Return:
         [
                {
                    'Path': 'string',
                    'RoleName': 'string',
                    'RoleId': 'string',
                    'Arn': 'string',
                    'CreateDate': datetime(2015, 1, 1),
                    'AssumeRolePolicyDocument': 'string',
                    'Description': 'string',
                    'MaxSessionDuration': 123,
                    'PermissionsBoundary': {
                        'PermissionsBoundaryType': 'PermissionsBoundaryPolicy',
                        'PermissionsBoundaryArn': 'string'
                    }
                },
                {
                    ...
                },
          ]
        """
        pi_max_requests = CommFunc.if_none_or_empty(
                                kwargs.get('MaxRequest'), 100)

        roles = self.__iam_ro.list_roles()
        all_roles = []
        all_roles += roles.get('Roles')
        is_truncated = roles.get('IsTruncated')
        request_count = 1
        if is_truncated and request_count < pi_max_requests:
            marker = roles.get('Marker')
            while True:
                request_count += 1
                if request_count > pi_max_requests:
                    raise Exception("Truncated, max_request: {}, requested:{}"
                                    .format(pi_max_requests, request_count))
                kwargs['Marker'] = marker
                roles = self.__iam_ro.list_roles(**kwargs)
                all_roles += roles.get('Roles')
                is_truncated = roles.get('IsTruncated')
                if not is_truncated:
                    break
                marker = roles.get('Marker')
        return all_roles


    @classmethod
    def c_get_roles(cls, pi_key_id, pi_key, pi_token):
        """
        """
        account = AwsAccountI(aws_access_key_id=pi_key_id, 
                              aws_secret_access_key=pi_key,
                              aws_session_token=pi_token)
        return account.get_roles()

    def lazy_get_roles(self, **kwargs):
        if not self.__roles:
            self.__roles = self.get_roles(**kwargs)
        return self.__roles


    def get_access_keys(self, **kwargs):
        """
        Get access_keys from all users

        return list as followign:
        [
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAIV4M4KNJ7TXPKGRQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T07:31:33Z"
                },
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAI7CRPCRDLRZIXFNQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T04:48:20Z"
                }
        ]
        """
        self.lazy_get_users(**kwargs)
        user_list = [x['UserName'] for x in self.__users]
        results = []
        for user_name  in user_list:
            user = AwsUserI(user_name, session_ro=self.__session_ro, session_rw=self.__session_rw)
            result = user.get_access_keys_info()
            if result:
                results += result
        return results
        
    @classmethod
    def c_get_access_keys(cls, pi_key_id, pi_key, pi_token):
        """
        """
        account = AwsAccountI(aws_access_key_id=pi_key_id, 
                              aws_secret_access_key=pi_key,
                              aws_session_token=pi_token)
        return account.get_access_keys()



    def get_buckets(self, **kwargs):
        """
        Get all buckets from AWS within current account
        
        AWS list buckets return list as followign:
        {
            'Buckets': [
                {
                    'Name': 'string',
                    'CreationDate': datetime(2015, 1, 1)
                },
            ],
            'Owner': {
                'DisplayName': 'string',
                'ID': 'string'
            }
        }

        This Function Return as AWS return
        """
        s3 = AwsS3I(self.__session_ro, self.__session_ro)
        return s3.get_buckets()

    @classmethod
    def c_get_buckets(cls, pi_key_id, pi_key, pi_token):
        """
        """
        account = AwsAccountI(aws_access_key_id=pi_key_id, 
                              aws_secret_access_key=pi_key,
                              aws_session_token=pi_token)
        return account.get_buckets()