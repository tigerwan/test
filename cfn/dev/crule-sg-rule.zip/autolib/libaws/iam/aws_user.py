"""
Module: aws_user
Create Date: 2018-07-26
Function: Implement aws user module.
"""

from autolib.libcomm.commfunc import CommFunc, CommConstV
from autolib.libcomm.log2 import Log2
from autolib.libaws.aws_session import AwsSessionI
from copy import deepcopy


class AwsUserI:
    """
    private use and public use
    --------------------------
    For class internal use: call _get_access_keys_info(), for faster
    For public use: call get_access_keys_info(), for safe
    """

    def __init__(self, pi_username, session_ro=None, session_rw=None, session=None, lazy_load=True, **kwargs):
        """ Initalization.
        pi_username: (string)
            This parameter is optional. If it is not included,
            it defaults to the user making the request.
            This parameter allows (per its regex pattern )
            a string of characters consisting of upper
            and lowercase alphanumeric characters with no spaces.
            You can also include any of the following characters:
            _+=,.@-
        lazy_load: True|False
            True: get user information immediately
            Flase: get user information only when use it.
        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, 
                                                                    session_rw=session_rw, 
                                                                    session=session, 
                                                                    **kwargs)
        self.__iam_ro = self.__session_ro.client('iam')
        self.__iam_rw = self.__session_rw.client('iam')
        self.__name = pi_username
        self.__info = None
        self.__access_keys = None
        if not lazy_load:
            self.load()

    def get_name(self):
        return self.__name

    def load(self):
        """
        Load user information
        Request:
        Return: dict type as following
           {
                "User": {
                    "Arn": "arn:aws:iam::431525257644:user/testuser3",
                    "CreateDate": "2018-06-18 07:12:33+00:00",
                    "PasswordLastUsed": "2018-06-18 07:12:33+00:00",
                    "Path": "/",
                    "UserId": "AIDAJJLAKPDZUIKNJ4W3A",
                    "UserName": "testuser3"
                }
            }
        """
        self.__info = self.__iam_ro.get_user(UserName=self.__name)

    def reload(self):
        """
        the same as load
        """
        return self.load()

    def lazy_load(self):
        """
        the same as reload
        """
        if not self.__info:
            return self.load()

    def _get_info(self):
        """
        Get current user attributes
        Return: dict
        """
        self.lazy_load()
        return self.__info.get('User')

    def get_info(self):
        """
        Get current user attributes
        Return: dict
        """
        return deepcopy(self._get_info())

    def show_info(self):
        """
        Show current user attributes
        Return: None
        """
        CommFunc.show(self.get_info())

    def get_create_dt(self):
        """
        Get user create date time
        Return: datetime
        """
        self.lazy_load()
        return deepcopy(self._get_info().get('CreateDate'))

    def get_password_last_used_time(self):
        """
        Get user last used password date time
        Return: datetime
        """
        self.lazy_load()
        return deepcopy(self._get_info().get('PasswordLastUsed'))

    def get_arn(self):
        """
        Get user ARN
        """
        self.lazy_load()
        return deepcopy(self._get_info().get('Arn'))

    def get_path(self):
        """
        Get user path
        """
        self.lazy_load()
        return deepcopy(self._get_info().get('Path'))

    def get_id(self):
        """
        Get user ID
        """
        self.lazy_load()
        return deepcopy(self._get_info().get('UserId'))

    def load_access_keys(self, pi_max_requests=100):
        """
        get user all access keys

        aws response example:
        {
            "AccessKeyMetadata": [
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAIV4M4KNJ7TXPKGRQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T07:31:33Z"
                },
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAI7CRPCRDLRZIXFNQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T04:48:20Z"
                }
            ]
        }

        Return: list
            [
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAIV4M4KNJ7TXPKGRQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T07:31:33Z"
                },
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAI7CRPCRDLRZIXFNQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T04:48:20Z"
                }
            ]
        """
        access_keys = self.__iam_ro.list_access_keys(UserName=self.__name)
        self.__access_keys = []
        self.__access_keys += access_keys.get('AccessKeyMetadata')
        is_truncated = access_keys.get('IsTruncated')
        request_count = 1
        if is_truncated and request_count < pi_max_requests:
            marker = access_keys.get('Marker')
            while True:
                request_count += 1
                if request_count > pi_max_requests:
                    raise Exception("Truncated, max_request: {}, requested:{}"
                                    .format(pi_max_requests, request_count))
                access_keys = self.__iam_ro.list_access_keys(UserName=self.__name,
                                                         Marker=marker)
                self.__access_keys += access_keys.get('AccessKeyMetadata')
                is_truncated = access_keys.get('IsTruncated')
                if not is_truncated:
                    break
                marker = access_keys.get('Marker')

    def lazy_load_access_keys(self, pi_max_requests=100):
        """
        Load access keys by lazy mode
        """
        if not self.__access_keys:
            self.load_access_keys(pi_max_requests)

    def _get_access_keys_info(self):
        """
        Get current user access keys list info, for private use

        Output example:
         [
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAIV4M4KNJ7TXPKGRQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T07:31:33Z"
                },
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAI7CRPCRDLRZIXFNQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T04:48:20Z"
                }
        ]
        """
        self.lazy_load_access_keys()
        return self.__access_keys

    def _get_access_keys(self,
                         pi_status=None,
                         pi_create_from_dt=None,
                         pi_create_to_dt=None):
        """
        Get current user access keys list.
        (including all Active and Inactive keys)

        pi_status: Inactive|Active

        Output example:
        [
            "AKIAIV4M4KNJ7TXPKGAQ",
            "AKIAIV4M4KNJ7TXPKGBQ",
            "AKIAIV4M4KNJ7TXPKGCQ",
            "AKIAIV4M4KNJ7TXPKGDQ",
        ]
        """
        keys_list = None
        keys_info = self._get_access_keys_info()
        if keys_info:
            if pi_status:
                keys_list = [x['AccessKeyId']
                             for x in keys_info
                             if x['Status'].upper() == pi_status.upper()
                             if CommFunc.time_in_range(x['CreateDate'],
                                                       pi_create_from_dt,
                                                       pi_create_to_dt)]
            else:
                keys_list = [x['AccessKeyId'] for x in keys_info
                             if CommFunc.time_in_range(x['CreateDate'],
                                                       pi_create_from_dt,
                                                       pi_create_to_dt)]
        return keys_list

    def get_access_keys_active(self,
                               pi_create_from_dt=None,
                               pi_create_to_dt=None):
        """
        Get current user all Active access keys list.
        Return: list of keys
        """
        return deepcopy(self._get_access_keys("Active",
                                              pi_create_from_dt,
                                              pi_create_to_dt))

    def get_access_keys_inactive(self,
                                 pi_create_from_dt=None,
                                 pi_create_to_dt=None):
        """
        Get current user all Inactive access keys list.
        Return: list of keys
        """
        return deepcopy(self._get_access_keys("Inactive",
                                              pi_create_from_dt,
                                              pi_create_to_dt))

    def get_access_keys_info(self):
        """
        Get current user access keys list, for public use
        """
        return deepcopy(self._get_access_keys_info())

    def has_access_keys_active(self,
                               pi_create_from_dt=None,
                               pi_create_to_dt=None):
        """
        Check current user if has Active access keys.
        Return: total number of active keys
        """
        keys= self._get_access_keys("Active", pi_create_from_dt, pi_create_to_dt)
        if keys:
            return len(keys)
        else:
            return 0

    def show_access_keys(self):
        CommFunc.show(self.get_access_keys_info())

    def get_access_key_last_used(self, pi_access_key):
        """
        Retrieves information about when the specified access key
        was last used. The information includes the date and time
        of last use, along with the AWS service and region that
        were specified in the last request made with that key.
        Response Syntax
        {
            'UserName': 'string',
            'AccessKeyLastUsed': {
                'LastUsedDate': datetime(2015, 1, 1),
                'ServiceName': 'string',
                'Region': 'string'
            }
        }

        a real output example of AWS get_access_key_last_used
        {
            "AccessKeyLastUsed": {
                "Region": "N/A",
                "ServiceName": "N/A"
            },
            "ResponseMetadata": {
                "HTTPHeaders": {
                    "content-length": "431",
                    "content-type": "text/xml",
                    "date": "Fri, 27 Jul 2018 00:05:15 GMT",
                    "x-amzn-requestid": "bdb87426-9130-11e8-af54-896deb64abf1"
                },
                "HTTPStatusCode": 200,
                "RequestId": "bdb87426-9130-11e8-af54-896deb64abf1",
                "RetryAttempts": 0
            },
            "UserName": "testuser3"
        }
        a real output example of this funcion:
        {
            "AccessKeyLastUsed": {
                "Region": "N/A",
                "ServiceName": "N/A"
            },
            "UserName": "testuser3"
        }
        """
        data = self.__iam_ro.get_access_key_last_used(AccessKeyId=pi_access_key)
        del data['ResponseMetadata']
        return data

    def get_access_key_last_used_time(self, pi_access_key):
        """
        Get access key last used time
        """
        info = self.get_access_key_last_used(pi_access_key)
        if info:
            return info.get('AccessKeyLastUsed').get('LastUsedDate')

    def get_access_key_latest_used(self):
        """
        Go through all the keys, and find the latest used access key.
        return format:
        {
            "AccessKeyLastUsed": {
                "LastUsedDate": "2018-06-12 13:56:00+00:00",
                "Region": "sa-east-1",
                "ServiceName": "ec2"
            },
            "UserName": "hadi-hava-test"
        }
        """
        access_keys = self._get_access_keys_info()
        latest_used_dt = None
        latest_used_info = None
        for item in access_keys:
            key_id = item.get('AccessKeyId')
            last_used_info = self.get_access_key_last_used(key_id)
            last_used_dt = None
            if last_used_info:
                last_used_dt = last_used_info.get(
                    'AccessKeyLastUsed').get('LastUsedDate')
            if last_used_dt and (latest_used_dt is None or
                                 last_used_dt > latest_used_dt):
                # Log2.debug_l(5, "last_used_dt: {}".format(last_used_dt))
                # Log2.debug_l(5, "latest_used_dt: {}".format(latest_used_dt))
                latest_used_dt = last_used_dt
                latest_used_info = last_used_info
        return latest_used_info

    def get_access_key_latest_used_time(self):
        """
        Get latest access key used time
        """
        info = self.get_access_key_latest_used()
        if info:
            return info['AccessKeyLastUsed']['LastUsedDate']

    def get_latest_used_info(self):
        """
        Get user last password login and access_key access time
        Return
        {
            "AccessKeyLastUsed": {
                "LastUsedDate": "2018-03-25 04:21:00+00:00",
                "Region": "N/A",
                "ServiceName": "s3"
            },
            "PasswordLastUsed": "2018-04-30 12:03:32+00:00",
            "UserName": "wongw"
        }

        or
        {
            "AccessKeyLastUsed": null,
            "PasswordLastUsed": null,
            "UserName": "testuser3"
        }
        """
        latest_password_info = self.get_password_last_used_time()
        latest_accesskey_info = self.get_access_key_latest_used()

        data = None
        if latest_accesskey_info:
            data = latest_accesskey_info
        else:
            data = {"AccessKeyLastUsed": None, "UserName": self.__name}

        data['PasswordLastUsed'] = latest_password_info
        return data

    def get_latest_used_time(self):
        """
        Get user last access time, whatever from password login or access_key
        """
        latest_password_dt = self.get_password_last_used_time()
        latest_accesskey_info = self.get_access_key_latest_used()

        if not latest_password_dt and not latest_accesskey_info:
            return None

        if latest_password_dt and latest_accesskey_info:
            key_lastused_dt = latest_accesskey_info.get(
                'AccessKeyLastUsed').get('LastUsedDate')
            if latest_password_dt > key_lastused_dt:
                return latest_password_dt
            else:
                return key_lastused_dt

        if latest_password_dt:
            return latest_password_dt
        else:
            return latest_accesskey_info['AccessKeyLastUsed']['LastUsedDate']

    def get_access_key_info(self, pi_access_key):
        """
        Get a access key information.

        self.__access_keys format as following:
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAIV4M4KNJ7TXPKGRQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T07:31:33Z"
                },
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAI7CRPCRDLRZIXFNQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T04:48:20Z"
                }
        """
        self.lazy_load_access_keys()
        key_matchs = [x for x in self.__access_keys
                      if x.get('AccessKeyId') == pi_access_key]
        if key_matchs:
            return deepcopy(key_matchs[0])

    def get_access_key_status(self, pi_access_key):
        """
        Get access key status, Active|Inactive
        """
        info = self.get_access_key_info(pi_access_key)
        if info:
            return info.get('Status')

    def get_access_key_create_date(self, pi_access_key):
        """
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAIV4M4KNJ7TXPKGRQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T07:31:33Z"
                }
        """
        info = self.get_access_key_info(pi_access_key)
        if info:
            return info.get('CreateDate')

    def risky_set_access_key_inactivate(self, pi_access_key, p_acl=CommConstV.ACL_DEFAULT):
        """
        Set access key 'Inactive' status

        Active means that the key can be used for API calls to AWS,
        while Inactive means that the key cannot be used.
        """
        if CommFunc.is_aws_readwrite(p_acl):
            Log2.debug('risky_set_access_key_inactivate for user:{} key:{}'.format(self.__name, pi_access_key))
            """
            self.__iam_rw.update_access_key(AccessKeyId=pi_access_key,
                                           UserName=self.__name,
                                           Status='Inactive')
            """
        else:
            Log2.debug('{}: risky_set_access_key_inactivate for user:{} key:{}'.format(p_acl.upper(),self.__name, pi_access_key))

    def risky_set_access_key_activate(self, pi_access_key, p_acl=CommConstV.ACL_DEFAULT):
        """
        Set access key 'Active' status

        Active means that the key can be used for API calls to AWS,
        while Inactive means that the key cannot be used.
        """
        if CommFunc.is_aws_readwrite(p_acl):
            Log2.debug('risky_set_access_key_activate for account:{} key:{}'.format(self.__name, pi_access_key))
            """
            if pi_access_key:
                self.__iam_rw.update_access_key(AccessKeyId=pi_access_key,
                                               UserName=self.__name,
                                               Status='Active')
            """
        else:
            Log2.debug('{}: risky_set_access_key_activate for account:{} key:{}'.format(p_acl.upper(),self.__name, pi_access_key))

    def risky_delete_access_key(self, pi_access_key, pi_user_name=None, p_acl=CommConstV.ACL_DEFAULT):
        """
        Delete access key

        Input:
            pi_access_key: required.
            pi_user_name: optional.
        """
        if CommFunc.is_aws_readwrite(p_acl):
            Log2.debug('risky_delete_access_key for account:{} key:{}'.format(self.__name, pi_access_key))
            """
            if pi_access_key:
                if pi_user_name:
                    data = {"AccessKeyId": pi_access_key, "UserName": pi_user_name}
                else:
                    data = {"AccessKeyId": pi_access_key}
                self.__iam_rw.delete_access_key(data)
            """
        else:
            Log2.debug('{}: risky_delete_access_key for account:{} key:{}'.format(p_acl.upper(),self.__name, pi_access_key))

    def risky_set_all_access_keys_inactive(self, p_acl=CommConstV.ACL_DEFAULT):
        """
        Set all access keys to "Inactive" status. disable all access keys.

        Return: dict
            {
                "Success":[key1, key2, key3],
                "Failed": [key9, key4]
            }
        """
        result = {"Success": [], "Failed": [], "p_acl": p_acl}
        active_keys = self.get_access_keys_active()
        if active_keys:
            for key in active_keys:
                try:
                    self.risky_set_access_key_inactivate(key, p_acl)
                    result['Success'].append(key)
                except:
                    result['Failed'].append(key)
        return result

    def get_login_profile(self):
        self.__iam_ro.get_login_profile(UserName=self.__name)

    def is_console_login_enabled(self):
        """
        Checki if console login was disabled.

        if enabled, return True, if disabled, return False
        """
        try:
            self.__iam_ro.get_login_profile(UserName=self.__name)
            return True
        except self.__iam_ro.exceptions.NoSuchEntityException as e:
            Log2.debug_l(1, "the_error: {}".format(e.response['Error']['Code']))
            return False

    def is_console_login_disabled(self):
        return not self.is_console_login_enabled()

    def risky_delete_login_profile(self, p_acl=CommConstV.ACL_DEFAULT):
        if CommFunc.is_aws_readwrite(p_acl):
            Log2.debug('risky_delete_login_profile for account:{}'.format(self.__name))
            """
            self.__iam_rw.delete_login_profile(UserName=self.__name)
            """
        else:
            Log2.debug('{}: risky_delete_login_profile for account:{}'.format(p_acl.upper(), self.__name))

    def risky_disable_console_login(self, p_acl=CommConstV.ACL_DEFAULT):
        if self.is_console_login_enabled():
            self.risky_delete_login_profile(p_acl=p_acl)

    def risky_set_inactive(self, p_acl=CommConstV.ACL_DEFAULT):
        result = {}
        key_result = self.risky_set_all_access_keys_inactive(p_acl)
        try:
            if CommFunc.is_aws_readwrite(p_acl):
                self.risky_disable_console_login(p_acl=p_acl)
            result = {"AccessKeys": key_result,
                      "ConsoleLogin": "Disable",
                      "p_acl": p_acl}
        except:
            result = {"AccessKeys": key_result,
                      "ConsoleLogin": "Failed",
                      "p_acl": p_acl}
        return result

    def is_inactive(self):
        if self.has_access_keys_active() < 1 and self.is_console_login_disabled():
            return True
        else:
            return False

    def is_active(self):
        return not self.is_inactive()