
"""
Module: aws_role
Create Date: 2018-08-06
Function: Implement news account module.
"""

from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI
from copy import deepcopy

class AwsRoleI():
    """
    Aws Role Interface Class.

    Including functions in AWS role management level.
    """


    def __init__(self, **kwargs):
        """
        Parameters
        Session: if input session, will not use aws_access_key_id,
                aws_secret_access_key,aws_session_token to create new session 
                again.

        aws_access_key_id (string) -- AWS access key ID
        aws_secret_access_key (string) -- AWS secret access key
        aws_session_token (string) -- AWS temporary session token
        region_name (string) -- Default region when creating new connections
        botocore_session (botocore.session.Session) -- Use this Botocore
                session instead of creating a new default one.
        profile_name (string) -- The name of a profile to use. If not given,
                then the default profile is used.


        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(**kwargs)
        self.__sts = self.__session_ro.client('sts')

    def assume_role(self, 
                    pi_newrole_arn, 
                    pi_newrole_session_name,
                    region=None,
                    policy=None):
        """
        Assume to new role, return session

        Get role credential by account id
        Returns a set of temporary security credentials 
        (consisting of an access key ID, a secret access key, 
        and a security token) that you can use to access AWS 
        resources that you might not normally have access to.

        return: session (new role)
        """

        # assume role to get temorary credentials
        #
        # sts.assume_role return format:
        #    {
        #       'Credentials': {
        #           'AccessKeyId': 'string',
        #           'SecretAccessKey': 'string',
        #           'SessionToken': 'string',
        #           'Expiration': datetime(2015, 1, 1)
        #       },
        #       'AssumedRoleUser': {
        #           'AssumedRoleId': 'string',
        #           'Arn': 'string'
        #       },
        #       'PackedPolicySize': 123
        #   }
        #
        if policy:
            new_role = self.__sts.assume_role(
                    RoleArn=pi_newrole_arn,
                    RoleSessionName=pi_newrole_session_name,
                    Policy = policy
                )
        else:
            new_role = self.__sts.assume_role(
                    RoleArn=pi_newrole_arn,
                    RoleSessionName=pi_newrole_session_name
                )
        

        credentials = new_role['Credentials']
        if credentials:
            session = AwsSessionI.c_session(aws_access_key_id=credentials['AccessKeyId'], 
                                            aws_secret_access_key=credentials['SecretAccessKey'], 
                                            aws_session_token=credentials['SessionToken'],
                                            region_name=region)
            return session
        else:
            raise ValueError("Failed to get new role credentials")