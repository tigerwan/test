"""
Implement AWS API Gateway Interface

"""
import sys, os, base64, datetime, hashlib, hmac 
import requests # pip install requests
from autolib.libcomm.log2 import Log2


class AwsApiGatewayI:
    def __init__(self):
        """ Initalization. """
        pass

    @classmethod
    def _get_signature_key(cls, pi_key, pi_datestamp, pi_region, pi_service, pi_encode="utf-8"):
        """
        Key derivation functions. See:
        http://docs.aws.amazon.com/general/latest/gr/signature-v4-examples.html#signature-v4-examples-python
        """
        def sign(pi_key, msg):
            return hmac.new(pi_key, msg.encode(pi_encode), hashlib.sha256).digest()
        kDate = sign(('AWS4' + pi_key).encode(pi_encode), pi_datestamp)
        kRegion = sign(kDate, pi_region)
        kService = sign(kRegion, pi_service)
        kSigning = sign(kService, 'aws4_request')
        return kSigning


    @classmethod
    def auth4_get(cls, **kwargs):
        """
        Call AWS API Gateway (GET method)
        kwargs: 
        -------
            host: "vnith70o7l.execute-api.ap-southeast-2.amazonaws.com",
            region: "ap-southeast-2"
            endpoint: "https://vnith70o7l.execute-api.ap-southeast-2.amazonaws.com/dev/"

            method:"POST",  
            service: "execute-api",
            request_parameters: {}
            aws_access_key_id: ""
            aws_secret_access_key: ""
            aws_session_token: ""
            algorithm = "AWS4-HMAC-SHA256"
            encode_type="utf-8"

        

        host: (required) 
        region: (required) 
        endpoint: (required)
        service: (optional) default 'execute-api'
        method: (optional) default 'POST'
        algorithm: (optional) default "AWS4-HMAC-SHA256"
        encode_type: (optional) default "utf-8"

        aws_access_key_id: (optional) 
        aws_secret_access_key: (optional)
        aws_session_token: (optional)

        request_parameters: (optional) dict type: like 
            {"table_name": "account_table", 
            "attribute": [{"AttributeName": "Id","AttributeType": "S"}]
            }
        """
        host = kwargs["host"] 
        region = kwargs['region']
        endpoint = kwargs['endpoint']

        service = kwargs.get("service", "execute-api")
        method = "GET"
        request_parameters = str(kwargs.get("api_parameters", ''))
        algorithm = kwargs.get("algorithm", "AWS4-HMAC-SHA256")
        encode_type = kwargs.get("encode_type", "utf-8")

        # the content is JSON.

        # Read AWS access key from env. variables or configuration file. Best practice is NOT
        # to embed credentials in code.
        aws_access_key_id = kwargs.get("aws_access_key_id")
        aws_secret_access_key = kwargs.get("aws_secret_access_key")
        aws_session_token = kwargs.get("aws_session_token", None)

        # Create a date for headers and the credential string
        t = datetime.datetime.utcnow()
        amzdate = t.strftime('%Y%m%dT%H%M%SZ')
        datestamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope


        # ************* TASK 1: CREATE A CANONICAL REQUEST *************
        # http://docs.aws.amazon.com/general/latest/gr/sigv4-create-canonical-request.html

        # Step 1 is to define the verb (GET, POST, etc.)--already done.

        # Step 2: Create canonical URI--the part of the URI from domain to query 
        # string (use '/' if no path)
        canonical_uri = '/dev/' 

        # Step 3: Create the canonical query string. In this example (a GET request),
        # request parameters are in the query string. Query string values must
        # be URL-encoded (space=%20). The parameters must be sorted by name.
        # For this example, the query string is pre-formatted in the request_parameters variable.
        canonical_querystring = str(request_parameters)

        # Step 4: Create the canonical headers and signed headers. Header names
        # must be trimmed and lowercase, and sorted in code point order from
        # low to high. Note that there is a trailing \n.
        if aws_session_token:
            canonical_headers = 'host:' + host + '\n' + 'x-amz-date:' + amzdate + '\n' +'x-amz-security-token:'+ aws_session_token +'\n'
        else:
            canonical_headers = 'host:' + host + '\n' + 'x-amz-date:' + amzdate + '\n'

        # Step 5: Create the list of signed headers. This lists the headers
        # in the canonical_headers list, delimited with ";" and in alpha order.
        # Note: The request can include any headers; canonical_headers and
        # signed_headers lists those that you want to be included in the 
        # hash of the request. "Host" and "x-amz-date" are always required.
        if aws_session_token:
            signed_headers = 'host;x-amz-date;x-amz-security-token'
        else:
            signed_headers = 'host;x-amz-date'

        # Step 6: Create payload hash (hash of the request body content). For GET
        # requests, the payload is an empty string ("").
        payload_hash = hashlib.sha256(('').encode(encode_type)).hexdigest()

        # Step 7: Combine elements to create canonical request
        canonical_request = method + '\n' + canonical_uri + '\n' + canonical_querystring + '\n' + canonical_headers + '\n' + signed_headers + '\n' + payload_hash
        Log2.debug_l(4, "canonical_request: {}".format(canonical_request))


        # ************* TASK 2: CREATE THE STRING TO SIGN*************
        # Match the algorithm to the hashing algorithm you use, either SHA-1 or
        # SHA-256 (recommended)
        credential_scope = datestamp + '/' + region + '/' + service + '/' + 'aws4_request'
        string_to_sign = algorithm + '\n' +  amzdate + '\n' +  credential_scope + '\n' +  hashlib.sha256(canonical_request.encode(encode_type)).hexdigest()

        # ************* TASK 3: CALCULATE THE SIGNATURE *************
        # Create the signing key using the function defined above.
        signing_key = cls._get_signature_key(aws_secret_access_key, datestamp, region, service)

        # Sign the string_to_sign using the signing_key
        signature = hmac.new(signing_key, (string_to_sign).encode(encode_type), hashlib.sha256).hexdigest()


        # ************* TASK 4: ADD SIGNING INFORMATION TO THE REQUEST *************
        # The signing information can be either in a query string value or in 
        # a header named Authorization. This code shows how to use a header.
        # Create authorization header and add to request headers
        authorization_header = algorithm + ' ' + 'Credential=' + aws_access_key_id + '/' + credential_scope + ', ' +  'SignedHeaders=' + signed_headers + ', ' + 'Signature=' + signature

        # The request can include any headers, but MUST include "host", "x-amz-date", 
        # and (for this scenario) "Authorization". "host" and "x-amz-date" must
        # be included in the canonical_headers and signed_headers, as noted
        # earlier. Order here is not significant.
        # Python note: The 'host' header is added automatically by the Python 'requests' library.
        if aws_session_token:
            headers = {'x-amz-date':amzdate, 
                       'Authorization':authorization_header,
                        'x-Amz-security-token': aws_session_token}
        else:
            headers = {'x-amz-date':amzdate, 
                       'Authorization':authorization_header}
        # ************* SEND THE REQUEST *************
        request_url = endpoint + '?' + canonical_querystring
        return requests.get(request_url, headers=headers)
        



    @classmethod
    def auth4_post(cls, **kwargs):
        """
        Call AWS API Gateway (POST method)
        kwargs: 
        -------
            host: "vnith70o7l.execute-api.ap-southeast-2.amazonaws.com",
            region: "ap-southeast-2"
            endpoint: "https://vnith70o7l.execute-api.ap-southeast-2.amazonaws.com/dev/"

            method:"POST",  
            service: "execute-api",
            request_parameters: {}
            content_type: "application/x-amz-json-1.0"
            aws_access_key_id: ""
            aws_secret_access_key: ""
            aws_session_token: ""
            algorithm = "AWS4-HMAC-SHA256"
            encode_type="utf-8"

        

        host: (required) 
        region: (required) 
        endpoint: (required)
        service: (optional) default 'execute-api'
        method: (optional) default 'POST'
        content_type: (optional) default "application/x-amz-json-1.0" , Only for POST
        algorithm: (optional) default "AWS4-HMAC-SHA256"
        encode_type: (optional) default "utf-8"

        aws_access_key_id: (optional) 
        aws_secret_access_key: (optional)
        aws_session_token: (optional)

        request_parameters: (optional) dict type: like 
            {"table_name": "account_table", 
            "attribute": [{"AttributeName": "Id","AttributeType": "S"}]
            }
        """
        host = kwargs["host"] 
        region = kwargs['region']
        endpoint = kwargs['endpoint']

        service = kwargs.get("service", "execute-api")
        content_type = kwargs.get("content_type", "application/x-amz-json-1.0")
        method = kwargs.get("method", "POST")
        request_parameters = str(kwargs.get("api_parameters", {}))
        algorithm = kwargs.get("algorithm", "AWS4-HMAC-SHA256")
        encode_type = kwargs.get("encode_type", "utf-8")

        # the content is JSON.

        # Read AWS access key from env. variables or configuration file. Best practice is NOT
        # to embed credentials in code.
        aws_access_key_id = kwargs.get("aws_access_key_id")
        aws_secret_access_key = kwargs.get("aws_secret_access_key")
        aws_session_token = kwargs.get("aws_session_token", None)

        # Create a date for headers and the credential string
        t = datetime.datetime.utcnow()
        amz_date = t.strftime('%Y%m%dT%H%M%SZ')
        date_stamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope


        # ************* TASK 1: CREATE A CANONICAL REQUEST *************
        # http://docs.aws.amazon.com/general/latest/gr/sigv4-create-canonical-request.html

        # Step 1 is to define the verb (GET, POST, etc.)--already done.

        # Step 2: Create canonical URI--the part of the URI from domain to query 
        # string (use '/' if no path)
        #canonical_uri = '/'
        canonical_uri = '/dev/'

        ## Step 3: Create the canonical query string. In this example, request
        # parameters are passed in the body of the request and the query string
        # is blank.
        canonical_querystring = ''

        # Step 4: Create the canonical headers. Header names must be trimmed
        # and lowercase, and sorted in code point order from low to high.
        # Note that there is a trailing \n.
        if aws_session_token:
            canonical_headers = "content-type:{}\nhost:{}\nx-amz-date:{}\n"\
                    "x-amz-security-token:{}\n".format(content_type, host, 
                                                       amz_date, 
                                                       aws_session_token)
        else:
            canonical_headers = "content-type:{}\nhost:{}\nx-amz-date:{}\n".format(content_type, host, amz_date)
        Log2.debug_l(4, "canonical_headers: {}".format(canonical_headers))

        # Step 5: Create the list of signed headers. This lists the headers
        # in the canonical_headers list, delimited with ";" and in alpha order.
        # Note: The request can include any headers; canonical_headers and
        # signed_headers include those that you want to be included in the
        # hash of the request. "Host" and "x-amz-date" are always required.
        # For DynamoDB, content-type and x-amz-target are also required.
        #signed_headers = 'content-type;host;x-amz-date;x-amz-target'
        if aws_session_token:
            signed_headers = 'content-type;host;x-amz-date;x-amz-security-token'
        else:
            signed_headers = 'content-type;host;x-amz-date'

        # Step 6: Create payload hash. In this example, the payload (body of
        # the request) contains the request parameters.
        payload_hash = hashlib.sha256(request_parameters.encode(encode_type)).hexdigest()

        # Step 7: Combine elements to create canonical request
        canonical_request = method + '\n' + canonical_uri + '\n' + canonical_querystring + '\n' + canonical_headers + '\n' + signed_headers + '\n' + payload_hash
        Log2.debug_l(4, "=======================")
        Log2.debug_l(4, 'canonical_request: {}'.format(canonical_request))
        Log2.debug_l(4, "=======================")

        # ************* TASK 2: CREATE THE STRING TO SIGN*************
        # Match the algorithm to the hashing algorithm you use, either SHA-1 or
        # SHA-256 (recommended)
        credential_scope = date_stamp + '/' + region + '/' + service + '/' + 'aws4_request'
        string_to_sign = algorithm + '\n' +  amz_date + '\n' +  credential_scope + '\n' +  hashlib.sha256(canonical_request.encode(encode_type)).hexdigest()

        # ************* TASK 3: CALCULATE THE SIGNATURE *************
        # Create the signing key using the function defined above.
        signing_key = cls._get_signature_key(aws_secret_access_key, date_stamp, region, service)

        # Sign the string_to_sign using the signing_key
        signature = hmac.new(signing_key, (string_to_sign).encode(encode_type), hashlib.sha256).hexdigest()

        # ************* TASK 4: ADD SIGNING INFORMATION TO THE REQUEST *************
        # Put the signature information in a header named Authorization.
        authorization_header = algorithm + ' ' + 'Credential=' + aws_access_key_id + '/' + credential_scope + ', ' +  'SignedHeaders=' + signed_headers + ', ' + 'Signature=' + signature 

        # For DynamoDB, the request can include any headers, but MUST include "host", "x-amz-date",
        # "x-amz-target", "content-type", and "Authorization". Except for the authorization
        # header, the headers must be included in the canonical_headers and signed_headers values, as
        # noted earlier. Order here is not significant.
        # # Python note: The 'host' header is added automatically by the Python 'requests' library.
        if aws_session_token:
            headers = {'content-type':content_type,
                       'x-amz-date':amz_date,
                       'authorization':authorization_header,
                       'x-Amz-security-token': aws_session_token}
        else:
            headers = {'content-type':content_type,
                       'x-amz-date':amz_date,
                       'authorization':authorization_header}
        return requests.post(endpoint, data=request_parameters, headers=headers)

    @classmethod
    def auth4_request(cls, **kwargs):
        """
        Call AWS API Gateway
        kwargs: 
        -------
            host: "vnith70o7l.execute-api.ap-southeast-2.amazonaws.com",
            region: "ap-southeast-2"
            endpoint: "https://vnith70o7l.execute-api.ap-southeast-2.amazonaws.com/dev/"

            method:"POST",  
            service: "execute-api",
            request_parameters: {}
            content_type: "application/x-amz-json-1.0"
            aws_access_key_id: ""
            aws_secret_access_key: ""
            aws_session_token: ""
            algorithm = "AWS4-HMAC-SHA256"
            encode_type="utf-8"

        

        host: (required) 
        region: (required) 
        endpoint: (required)
        service: (optional) default 'execute-api'
        method: (optional) default 'POST'
        content_type: (optional) default "application/x-amz-json-1.0" , Only for POST
        algorithm: (optional) default "AWS4-HMAC-SHA256"
        encode_type: (optional) default "utf-8"

        aws_access_key_id: (optional) 
        aws_secret_access_key: (optional)
        aws_session_token: (optional)

        request_parameters: (optional) dict type: like 
            {"table_name": "account_table", 
            "attribute": [{"AttributeName": "Id","AttributeType": "S"}]
            }
        """
        method = kwargs.get("method", "POST").upper()
        if method == "POST":
            return cls.auth4_post(**kwargs)
        elif method == "GET":
            return cls.auth4_get(**kwargs)
        else:
            raise ValueError("Invalid method: {}".format(method))

    @classmethod
    def auth4_request_express(cls, pi_host, pi_region, pi_endpoint, method="POST"):
        """
        Express request

        Note: Credential read from os environment
        """
        return cls.auth4_request(
            host=pi_host,
            region=pi_region,
            endpoint=pi_endpoint,
            method=method,
            aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
            aws_session_token= os.environ.get('AWS_SESSION_TOKEN')
            )
        

    @classmethod
    def test_auth4_role_request(cls, pi_method="POST"):
        """
        Example of test by role

        username: test_api
        key_id: AKIAITGZWTIAH2OAA7ZQ
        secret access key: cIcGHzqIVh0xwuk+9bWINbPfRC3lBWmBL1R/45yd
        """
        result = cls.auth4_request_express(
            "vnith70o7l.execute-api.ap-southeast-2.amazonaws.com",
            "ap-southeast-2",
            "https://vnith70o7l.execute-api.ap-southeast-2.amazonaws.com/dev/",
            pi_method
            )
        Log2.echo(result.status_code)
        Log2.echo(result.text)

    @classmethod
    def test_auth4_user_request(cls, pi_method="POST"):
        """
        Example of test by user

        username: test_api
        key_id: AKIAITGZWTIAH2OAA7ZQ
        secret access key: cIcGHzqIVh0xwuk+9bWINbPfRC3lBWmBL1R/45yd
        """
        result = cls.auth4_request(
            host="vnith70o7l.execute-api.ap-southeast-2.amazonaws.com",
            region="ap-southeast-2",
            endpoint="https://vnith70o7l.execute-api.ap-southeast-2.amazonaws.com/dev/",
            method=pi_method,
            aws_access_key_id="AAAaaaaaaaa",
            aws_secret_access_key="cIcGHzqIVh0xwuk+9bWINbPfRC3lBWmBL1R/45yd"
            )
        Log2.echo(result.status_code)
        Log2.echo(result.text)



    @classmethod
    def test_auth4_role_request_withouttoken(cls, pi_method="POST"):
        """
        Example of test by user

        username: test_api
        key_id: AKIAITGZWTIAH2OAA7ZQ
        secret access key: cIcGHzqIVh0xwuk+9bWINbPfRC3lBWmBL1R/45yd
        """
        result = cls.auth4_request(
            host="vnith70o7l.execute-api.ap-southeast-2.amazonaws.com",
            region="ap-southeast-2",
            endpoint="https://vnith70o7l.execute-api.ap-southeast-2.amazonaws.com/dev/",
            method=pi_method,
            aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
            #aws_session_token= os.environ.get('AWS_SESSION_TOKEN')
            )
        Log2.echo(result.status_code)
        Log2.echo(result.text)