"""
Module of AWS Session
"""

from boto3.session import Session

class AwsSessionI():
    """
    """
    def __init__(self):
        """
        """
        pass

    @classmethod
    def c_init(cls, session=None, session_ro=None, session_rw=None, **kwargs):
        """
        :session_ro:  
        :session_rw:
        or
        :session:

        (session_ro,session_rw) have higher priority than (session)
        """
        if (not session and not session_ro and not session_rw):
            session = Session(**kwargs)
            return (session, session)
        if session and (session_ro or session_rw):
            raise ValueError("Invalid, (session_ro,session_rw) and (session) should not all assign value")
        elif session:
            return (session, session)
        elif session_ro and session_rw:
            return (session_ro, session_rw)
        elif session_ro:
            return (session_ro, session_ro)
        elif session_rw:
            return (session_rw, session_rw)

    @classmethod
    def c_session(cls, *args, **kwargs):
        return Session(*args, **kwargs)
