"""
Logger tool

"""
import os
import yaml
import datetime
#import logging

class Log2:
    """
    Class Log2

    Level	weight
    ------  -------
    CRITICAL    150
    ERROR	    140
    WARNING	    130
    INFO	    120
    DEBUG	    110
    NOTSET	    100
    """
    CRITICAL = 150
    ERROR = 140
    WARNING	= 130
    INFO = 120
    DEBUG = 110
    NOTSET= 100

    class ConstV:
        INDENT_PREFIX="indent-prefix"
        INDENT_ONLY="indent"
        PREFIX_ONLY="prefix"
        NO_PREFIX=""

        OUT_YAML="yaml"
        OUT_DEFAULT="plain"


    @classmethod
    def _output_yaml(cls, pi_info, prefix_format=ConstV.INDENT_ONLY):
        cls._log_n(cls.INFO, 
                   yaml.dump(pi_info, default_flow_style=False, indent=4),
                   prefix_format=prefix_format)
        """
        if isinstance(pi_info, dict):
            cls._log_n(cls.INFO, yaml.dump(pi_info), prefix_format=prefix_format)
        elif isinstance(pi_info, list):
            cls.prefix_indent_plus()
            for item in pi_info:
                cls._output_yaml(item, prefix_format)
            cls.prefix_indent_minus()
        else:
            cls._log_n(cls.INFO, pi_info, prefix_format=prefix_format)
        """


    @classmethod
    def set_prefix_indent(cls, pi_indent):
        """
        Set log message preifx informaiton to environemnt variable:
        G_LOG2_MSG_PREFIX_INDENT_G
        """
        os.environ["G_LOG2_MSG_PREFIX_INDENT_G"] = str(pi_indent)

    @classmethod
    def get_prefix_indent(cls):
        """
        Get log message preifx informaiton to environemnt variable:
        G_LOG2_MSG_PREFIX_INDENT_G
        """
        prefix_indent = os.environ.get("G_LOG2_MSG_PREFIX_INDENT_G")
        if (prefix_indent or "") == "":
            return 0
        else:
            return int(prefix_indent)

    @classmethod
    def prefix_indent_plus(cls, indent=4):
        """
        Set log message preifx informaiton to environemnt variable:
        G_LOG2_MSG_PREFIX_INDENT_G
        """
        current_indent = cls.get_prefix_indent()
        cls.set_prefix_indent(current_indent+indent)


    @classmethod
    def prefix_indent_minus(cls, indent=4):
        """
        Set log message preifx informaiton to environemnt variable:
        G_LOG2_MSG_PREFIX_INDENT_G
        """
        current_indent = cls.get_prefix_indent()
        if current_indent >= indent:
            cls.set_prefix_indent(current_indent-indent)
        else:
            cls.set_prefix_indent(0)

    @classmethod
    def set_prefix(cls, pi_prefix):
        """
        Set log message preifx informaiton to environemnt variable:
        G_LOG2_MSG_PREFIX_G
        """
        os.environ["G_LOG2_MSG_PREFIX_G"] = str(pi_prefix)

    @classmethod
    def get_prefix(cls, prefix_format=ConstV.INDENT_PREFIX):
        """
        Get log message preifx informaiton to environemnt variable:
        G_LOG2_MSG_PREFIX_G
        """
        return os.environ["G_LOG2_MSG_PREFIX_G"]

    @classmethod
    def get_prefix_info(cls, prefix_format=ConstV.INDENT_PREFIX):
        """
        Get log message preifx informaiton to environemnt variable:
        G_LOG2_MSG_PREFIX_G
        """
        prefix = ""
        if prefix_format.lower() == cls.ConstV.INDENT_ONLY:
            prefix_indent = cls.get_prefix_indent()
            if prefix_indent > 0:
                prefix = "{}".format("".ljust(prefix_indent))
            else:
                prefix = ""
        elif prefix_format.lower() == cls.ConstV.PREFIX_ONLY:
            prefix = os.environ.get("G_LOG2_MSG_PREFIX_G")
        elif prefix_format.lower() == cls.ConstV.INDENT_PREFIX:
            prefix_indent = cls.get_prefix_indent()
            if prefix_indent > 0:
                prefix = "{}{}".format("".ljust(prefix_indent),os.environ.get("G_LOG2_MSG_PREFIX_G") or "")
            else:
                prefix = os.environ.get("G_LOG2_MSG_PREFIX_G")
        return prefix or ""

    @classmethod
    def get_level(cls):
        """
        Get log message level
        G_LOG2_LEVEL_G
        """
        level = os.environ.get("G_LOG2_LEVEL_G")
        return level

    @classmethod
    def set_level(cls, pi_level):
        """
        Set log message level
        G_LOG2_LEVEL_G

        Level	weight
        ------  -------
        CRITICAL    150   <--
        ERROR	    140     |
        WARNING	    130     | Log2 level
        INFO	    120     |
        DEBUG	    110     |
        NOTSET	    100   <--

        CRITICAL    50    <--
        ERROR	    40      |
        WARNING	    30      | Logging level
        INFO	    20      |
        DEBUG	    10      |
        NOTSET	    0     <--
        """
        os.environ["G_LOG2_LEVEL_G"] = str(pi_level)
        #logging.basicConfig(level=pi_level)

    @classmethod
    def enable_progressing(cls):
        """
        Get log message level
        G_LOG2_PROGRESSING_G
        """
        os.environ["G_LOG2_PROGRESSING_G"]="on"
        return 

    @classmethod
    def disable_progressing(cls):
        """
        Get log message level
        G_LOG2_PROGRESSING_G
        """
        if cls.is_progressing():
            os.environ.unsetenv("G_LOG2_PROGRESSING_G")


    @classmethod
    def is_progressing(cls):
        """
        Get log message level
        G_LOG2_PROGRESSING_G
        """
        progressing = os.environ.get("G_LOG2_PROGRESSING_G")
        if (progressing or "") == "on":
            return True

    @classmethod
    def lazy_init_level(cls):
        if cls.get_level() is None:
            cls.set_level(cls.DEBUG)

    @classmethod
    def make_msg(cls, pi_msg, prefix_format=ConstV.INDENT_PREFIX):
        return cls.get_prefix_info(prefix_format) + pi_msg
         

    @classmethod
    def _log(cls, pi_level, pi_msg, prefix_format=ConstV.INDENT_PREFIX):
        cls._log_n(pi_level, "{}\n".format(pi_msg), prefix_format)

    @classmethod
    def _log_n(cls, pi_level, pi_msg, prefix_format=ConstV.INDENT_PREFIX):
        """
        log information according input info_type.
        input:
        pi_level:
        pi_msg: 
        :prefix_format: auto add prefix (if prefix defined in environment variable)
        """
        cls.lazy_init_level()
        if int(pi_level) >= int(cls.get_level()):
           print(cls.make_msg(pi_msg, prefix_format), end='')

    @classmethod
    def info(cls, pi_msg, msg_title="", output_format=ConstV.OUT_DEFAULT):
        if msg_title:
            cls._log_n(cls.INFO, msg_title)

        if output_format == cls.ConstV.OUT_YAML:
            cls._output_yaml(pi_msg)
            cls._log(cls.INFO, "", prefix_format=cls.ConstV.NO_PREFIX)
        else:
            cls._log(cls.INFO, pi_msg)

    @classmethod
    def info_yaml(cls, pi_msg, msg_title=""):
        cls.info(pi_msg, msg_title, output_format=cls.ConstV.OUT_YAML)

    @classmethod
    def debug(cls, pi_msg):
        cls._log(cls.DEBUG, pi_msg)


    @classmethod
    def __debug_level_retune(cls, pi_level):
        """
        pi_level, range 1-10
        """
        debug_level = pi_level
        if pi_level > 10:
            debug_level = 10
        elif pi_level < 1:
            debug_level = 1
        return int(cls.DEBUG) - 10 + int(debug_level)

    @classmethod
    def debug_ln(cls, pi_level, pi_msg, prefix_format=ConstV.INDENT_PREFIX):
        """
        pi_level, range 1-10
        show message without add new line
        """
        debug_level = cls.__debug_level_retune(pi_level)
        cls._log_n(debug_level, pi_msg, prefix_format)

    @classmethod
    def debug_l(cls, pi_level, pi_msg, prefix_format=ConstV.INDENT_PREFIX):
        cls.debug_ln(pi_level, "{}\n".format(pi_msg), prefix_format)

    @classmethod
    def warning(cls, pi_msg):
        cls._log(cls.WARNING, pi_msg)

    @classmethod
    def critical(cls, pi_msg):
        cls._log(cls.CRITICAL, pi_msg)

    @classmethod
    def error(cls, pi_msg):
        cls._log(cls.ERROR, pi_msg)

    
    @classmethod
    def echo(cls, pi_msg):
        """
        Just a wrapper of print
        """
        print(pi_msg)

    @classmethod
    def progressing(cls, pi_msg):
        """
        Show progressing informaiton if Log2.enable_progresssing() was 
        called to enable progressing.
        """
        if cls.is_progressing():
            print(pi_msg)

    @classmethod
    def progressing_if(cls, pi_msg, progressing=None):
        """
        Show progressing informaiton if progressing is True or on
        """
        if str(progressing).lower() in ["on", "true"]:
            print(pi_msg, end='', flush=True)

    @classmethod
    def progressing_time_if(cls, pi_msg, progressing=None):
        current_timestamp = datetime.datetime.strftime(datetime.datetime.utcnow(), '%Y-%m-%d %H:%M:%S')
        cls.progressing_if("{} {}".format(current_timestamp, pi_msg), progressing)