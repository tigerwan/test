"""
This module implements process pool management
"""
from multiprocessing import Process, Queue, current_process, freeze_support
from autolib.libcomm.log2 import Log2


class ProcessPool:
    """
    Class ProcessPool 

    Steps:

    main: init --> start --> put tasks -->            --> get result --> 
                                         |            |
    child:                               -> run task ->
    ...                                  ...        ...
    child:                               -> run task ->
    """

    def __init__(self):
        """ Init process_num, task_queue, result_queue """
        self.__process_num = 0
        self.__task_queue = Queue()
        self.__result_queue = Queue()

    def _run_task(self, pi_func, pi_args):
        """ Doing job, return result.
        Return: [current_process_name, result]
        """
        result = pi_func(*pi_args)
        return result

    def _worker(self, pi_input, pi_output):
        """
        Function: worker, working processes
           Get job from _task_queue, return result to _result_queue.
            when receive 'STOP', then stop.
        func: function 
        args: arguments
        uid: information for this task
        """
        #for func, args, uid in iter(pi_input.get, 'STOP'):
        for task in iter(pi_input.get, 'STOP'):
            uid = None
            if (len(task) == 2):
                func, args = task
            elif (len(task) == 3):
                func, args, uid = task
            else:
                raise ValueError("Invalid task: {}".format(task))
            
            Log2.debug_l(5, "worker get task: func={}  args={}  uid={}".format(func, args, uid))
            task_result = self._run_task(func, args)
            result = {}
            result['process_name'] = current_process().name
            result['task_uid'] = uid
            result['task_result'] = task_result
            pi_output.put(result)

    def start(self, pi_process_num=1):
        """ Start process pool with process number = <pi_process_num>
        """
        # Create task queue and result queue
        if self.__process_num > 0:
            return -1
        self.__process_num = pi_process_num
        for i in range(pi_process_num):
            Process(target=self._worker, args=(
                self.__task_queue, self.__result_queue)).start()

    def stop(self):
        """ Stop process pool
        """
        for i in range(self.__process_num):
            self.__task_queue.put('STOP')

    def put_tasks(self, tasks):
        """
        Put task to task queue
        """
        self.current_tasks = tasks
        for task in tasks:
            Log2.debug_l(5, "task: {}".format(task))
            self.__task_queue.put(task)

    def get_results(self):
        """
        Get task results from result queue.
        """
        results = []
        for i in range(len(self.current_tasks)):
            result = self.__result_queue.get().get('task_result')
            if isinstance(result, list):
                results += [result]
            else:
                results.append(result)
        return results

    def get_results_info(self):
        """
        Get task results from result queue.

        info including: 

        "results": 
        [
            {
                "process_name": ""
                "task_uid": ""
                "task_result": {}
            },
            ...
        ]
        """
        results = []
        for i in range(len(self.current_tasks)):
            result = self.__result_queue.get()
            Log2.debug_l(4, "\n\nresult: {}".format(result))
            if isinstance(result, list):
                results += [result]
            else:
                results.append(result)
        return results