"""
Module of common function  of python
"""
import os
import json
import datetime
import pytz
import tzlocal
import yaml
from inspect import getframeinfo, stack
from copy import deepcopy
import ipaddress
from dynamodb_json import json_util
from json2html import *
import dpath.util

class CommConstV:
    """
    Common Constant Variable

    Warning:
    Please do not change any definition here without permisson of creator.
    Otherwise would cause serious issues.
    """
    ACL_RDONLY = "read_only"
    ACL_RDWR_RISKY = "Read_Write"
    ACL_DRYRUN = "dryrun"
    ACL_EXCLUDE = "exclude"
    ACL_DEFAULT = ACL_RDONLY

    FILTER_EXCLUDE = "exclude"
    FILTER_EXCLUDE_RDONLY = "exclude_readonly"
    FILTER_INCLUDE_EXCLUDE_UPDATEABLE= "Include_Exclude_Updateable"


class CommFunc:

    @classmethod
    def _datetime_converter(cls, o):
        """
        Convert datatime type to string
        """
        if isinstance(o, datetime.datetime):
            return o.__str__()

    @classmethod
    def dumps(cls, pi_info):
        return json.dumps(pi_info, default=cls._datetime_converter)

    @classmethod
    def format(cls, pi_info, pi_title=None, pretty=True):
        if pi_info and (isinstance(pi_info, dict) or isinstance(pi_info, list)):
            if pretty:
                info = json.dumps(pi_info,
                                sort_keys=True,
                                indent=4,
                                default=cls._datetime_converter)
            else:
                info = json.dumps(pi_info, default=cls._datetime_converter)
            return info
        else:
            return pi_info

    @classmethod
    def get_session_env(cls, pi_key):
        """
        Get current session environment variable
        """
        try:
            value = os.environ[pi_key]
            return value
        except KeyError:
            return None

    @classmethod
    def set_session_env(cls, pi_key, pi_value):
        """
        Set key value in current session environment
        """
        os.environ[pi_key] = pi_value



    @classmethod
    def show(cls, pi_info, pi_title=None):
        if pi_title:
            print("----------------------------------------")
            print(pi_title)
            print("----------------------------------------")
        if not pi_info:
            return
        info = cls.format(pi_info, pi_title)
        print(info)


    @classmethod
    def if_none(cls, pi_value, pi_default=None):
        if pi_value is None:
            return pi_default
        else:
            return pi_value

    @classmethod
    def if_empty(cls, pi_value, pi_default=None):
        if pi_value is not None and pi_value == "":
            return pi_default
        else:
            return pi_value

    @classmethod
    def if_none_or_empty(cls, pi_value, pi_default=None):
        if pi_value is None or pi_value == "":
            return pi_default
        else:
            return pi_value

    @classmethod
    def echo(cls, pi_msg):
        print(pi_msg)

    @classmethod
    def time_to_tz(cls, pi_time, pi_from_tz, pi_to_tz):
        """
        Convert time from timezone <from_tz> to timezone <to_tz>
        """
        from_tz = pytz.timezone(pi_from_tz)
        to_tz = pytz.timezone(pi_to_tz)
        from_tz_time = pi_time.replace(tzinfo=from_tz)
        to_tz_time = from_tz_time.astimezone(to_tz)
        return to_tz_time

    @classmethod
    def localtime_to_tz(cls, pi_time, to_tz):
        """
        Convert time from timezone <from_tz> to timezone <to_tz>
        """
        return cls.time_to_tz(pi_time, str(tzlocal.get_localzone()), to_tz)

    @classmethod
    def time_plus(cls, pi_time, **kwargs):
        """
        Convert time from timezone <from_tz> to timezone <to_tz>

        example:
        time_plus(datetime.datetime.now(), days=10, hours=2, minutes=10, seconds=10)
        current time: 2018-07-30 15:50:41.270192
        after convert: 2018-08-09 18:01:15.270192
        **kwargs:
        days=10
        hours=10
        seconds=20
        """
        time_delata = datetime.timedelta(**kwargs)
        return pi_time + time_delata

    @classmethod
    def time_minus(cls, pi_time, **kwargs):
        """
        Convert time from timezone <from_tz> to timezone <to_tz>

        example:
        time_plus(datetime.datetime.now(), days=10, hours=2, minutes=10, seconds=10)
        current time: 2018-07-30 15:50:41.270192
        after convert: 2018-08-09 18:01:15.270192
        **kwargs:
        days=10
        hours=10
        seconds=20
        """
        time_delata = datetime.timedelta(**kwargs)
        return pi_time - time_delata

    @classmethod
    def time_in_range(cls, pi_time, pi_time_from, pi_time_to):
        """
        Check if:  pi_time_from <= pi_time < pi_time_to

        if pi_time_from is None, pi_time_to not None,
            means only check if pi_time < pi_time_to
        if pi_time_from is not None, pi_time_to is None,
            means only check if pi_time >= pi_time_from

        Return: True|False
        """
        if pi_time_from is None and pi_time_to is None:
            return pi_time
        elif pi_time_from is None:
            return pi_time < pi_time_to
        elif pi_time_to is None:
            return pi_time >= pi_time_from
        else:
            return pi_time_from <= pi_time < pi_time_to

    @classmethod
    def get_current_datetime(cls):
        return datetime.datetime.now()

    @classmethod
    def get_current_datetime_utc(cls):
        return datetime.datetime.utcnow()

    @classmethod
    def to_bytes(cls, pi_data):
        if isinstance(pi_data, bytes):
            return pi_data
        else:
            return str(pi_data).encode()

    @classmethod
    def replace_vars(cls, pi_template, key_prefix="{%", key_postfix="}",  **kwargs):
        """
        Replace variables in pi_template with value from **kwargs
        variable in pi_template as: {var_name}
        key value provide from **kwargs as: var_name='good luck'
        for example:
            pi_template: file_name_{%TIMESTAMP}
            kwargs:  TIMESTAMP=20180802
            result: file_name_20180802
        """
        result = deepcopy(pi_template)
        for key,value in kwargs.items():
            #print("DEBUG: key:{}  value:{}".format(key, value))
            if isinstance(value, str):
                result = result.replace(key_prefix+str(key)+key_postfix, value)
        return result


    @classmethod
    def current_timestamp(cls, pi_format="yyyymmddhhmmss"):
        """
        Current UTC timestamp
        """
        if pi_format == "yyyymmddhhmmss":
            return datetime.datetime.strftime(datetime.datetime.utcnow(), '%Y%m%d%H%M%S')
        elif pi_format == "yyyy-mm-dd hh:mm:ss":
            return datetime.datetime.strftime(datetime.datetime.utcnow(), '%Y-%m-%d %H:%M:%S')
        else:
            raise ValueError("Not support format {}".format(pi_format))

    @classmethod
    def current_daystamp(cls, pi_format="yyyymmdd"):
        """
        Current UTC timestamp
        """
        if pi_format == "yyyymmdd":
            return datetime.datetime.strftime(datetime.datetime.utcnow(), '%Y%m%d')
        else:
            raise ValueError("Not support format {}".format(pi_format))

    @classmethod
    def read_json_file(cls, pi_file):
        """
        Read json data from file. can used to read json config file.
        """
        fh = None
        with open(pi_file, "r") as fh:
            data = json.load(fh)
            fh.close()
        return data

    @classmethod
    def write_json_file(cls, pi_data, pi_file):
        """
        Write data to file by json format
        """
        with open(pi_file, "w") as fh:
            fh.write(cls.dumps(pi_data))
            fh.close()



    @classmethod
    def is_str_true_or_bool_true(cls, pi_value):
        """
        if value is str, its' lower case is "true", or is True,
        then return True
        else, return False
        """
        if isinstance(pi_value, str) and pi_value.lower() == "true":
            return True
        elif pi_value is True:
            return True
        else:
            return False

    @classmethod
    def str_to_datetime(cls, pi_str_datetime):
        """
        This is tranfer string datetime to datetime object

        pi_str_datetime format: '2016-07-14 06:50:00+00:00'
                            or: '2016-07-14 06:50:00+0000'

        Note:
        so far, not support format: 2018-08-16 02:36:39.395890+00:00
                                                        ------
        len('2016-07-14 06:50:00+00:00') = 25
        """
        if isinstance(pi_str_datetime, datetime.datetime):
            return pi_str_datetime

        str_len = len(pi_str_datetime)
        if str_len == 25:
            str_datetime = ''.join(pi_str_datetime.rsplit(':', 1))
        elif str_len == 24:
            str_datetime = pi_str_datetime
        else:
            raise ValueError("Not support format")
        return datetime.datetime.strptime(str_datetime, '%Y-%m-%d %H:%M:%S%z')

    @classmethod
    def latest_time_passed(cls, pi_str_dt1, pi_str_dt2):
        """
        Compute time passed since latest time of pi_str_dt1, pi_str_dt2 to now

        pi_str_dt1 and pi_str_dt2 is sting datetime,
        format as: '2016-07-14 06:50:00+00:00'
               or: '2016-07-14 06:50:00+0000'

        """
        if pi_str_dt1 is None and pi_str_dt2 is None:
            raise ValueError("At least one input datetime string has value")
        elif pi_str_dt1 is not None and pi_str_dt2 is not None:
            dt1 = cls.str_to_datetime(pi_str_dt1)
            dt2 = cls.str_to_datetime(pi_str_dt2)
            if dt1 > dt2:
                dt_latest = dt1
            else:
                dt_latest = dt2
        elif pi_str_dt1 is not None:
            dt_latest = cls.str_to_datetime(pi_str_dt1)
        elif pi_str_dt2 is not None:
            dt_latest = cls.str_to_datetime(pi_str_dt2)

        dt_now = datetime.datetime.now(pytz.utc)
        return dt_now - dt_latest


    @classmethod
    def latest_passed_days(cls, pi_str_dt1, pi_str_dt2):
        """
        Return latest time passed days according now
        """
        passed_dt = cls.latest_time_passed(pi_str_dt1, pi_str_dt2)
        return passed_dt.days

    @classmethod
    def list_files(cls,
                   pi_path,
                   filename_prefix=None,
                   filename_suffix=None,
                   filename_contains=None):
        """
        List files in a path
        """
        all_files = [f for f in os.listdir(pi_path) if os.path.isfile(os.path.join(pi_path, f))]
        if filename_prefix:
            files = [f for f in all_files if f.startswith(filename_prefix)]
            all_files = files

        if filename_suffix:
            files = [f for f in all_files if f.endswith(filename_suffix)]
            all_files = files

        if filename_contains:
            files = [f for f in all_files if filename_contains in f]
            all_files = files

        return all_files

    @classmethod
    def get_config(cls, config=None, config_file=None):
        """
        Get config from input.
        """
        if not config  and not config_file:
            raise ValueError("Must give config or config_file")
        if config:
            return config
        else:
            return cls.read_json_file(config_file)

    @classmethod
    def is_str_in_list(cls, pi_str, pi_str_list, case_sensitive=True):
        """
        check if str in a list
        Return: True | False

        example: pi_str="Hello"
                 pi_str_list = ["hello", "World"]
            if case_sensitive=True, then return False
            if case_sensitive=False, then return True
        """
        if pi_str_list:
            if case_sensitive:
                if pi_str in pi_str_list:
                    return True
                else:
                    return False
            else:
                lowercase_str_list = [x.lower() for x in pi_str_list]
                if pi_str.lower() in lowercase_str_list:
                    return True
                else:
                    return False
        else:
            return False

    @classmethod
    def json_to_yaml(cls, pi_json):
        yaml.dump(pi_json, allow_unicode=True)

    @classmethod
    def dicts_remove_key_of_value(cls, pi_dicts):
        """
        Remove value's key from dicts

        Example:
        Input:
            [
                {'accountId': {'S': '261912113761'},
                 'accountName': {'S': 'News DNA'},
                 'environment': {'S': 'PROD'}
                },
                ...
            ],
        Return:
            [
                {'accountId': '261912113761',
                 'accountName': 'News DNA',
                 'environment': 'PROD'
                },
                ...
            ]
        """
        return [dict(zip(row.keys(), [list(column_value.values())[0] for column_value in row.values()]))  for row in (pi_dicts or [])]


    @classmethod
    def libaws_init_session(self, **kwargs):
        """
        :session_ro:
        :session_rw:
        or
        :session:

        (session_ro,session_rw) have higher priority than (session)
        """
        session_ro = kwargs.get('session_ro')
        session_rw = kwargs.get('session_rw')
        if session_ro and session_rw:
            return (session_ro,session_rw)
        elif not session_ro and not session_rw:
            session = kwargs.get('session')
            if session:
                return (session, session)
            else:
                raise ValueError("Invalid, must given (session_ro,session_rw) or (session)")
        else:
            raise ValueError("session_ro and session_rw should both be assigned value")

    @classmethod
    def is_aws_readonly(cls, p_acl=CommConstV.ACL_RDONLY):
        if p_acl == CommConstV.ACL_RDONLY:
            return True
        else:
            return False

    @classmethod
    def is_aws_readwrite(cls, p_acl=CommConstV.ACL_RDONLY):
        """
        Check if input <p_acl> can do read_write
        """
        if p_acl == CommConstV.ACL_RDWR_RISKY and CommConstV.ACL_RDWR_RISKY == "Read_Write":
            if CommConstV.ACL_RDWR_RISKY == CommConstV.ACL_DEFAULT:
                raise ValueError("Fatal: Since ACL_RDWR_RISKY == ACL_DEFAULT, so data is not trustable")
            else:
                return True
        else:
            return False

    @classmethod
    def is_aws_exclude(cls, p_acl=CommConstV.ACL_EXCLUDE):
        """
        Check if input <p_acl> can do read_write
        """
        if p_acl == CommConstV.ACL_EXCLUDE or p_acl.lower() == CommConstV.ACL_EXCLUDE.lower():
            return True
        else:
            return False

    @classmethod
    def is_filter_pattern_exclude_readonly(cls, pi_filter_pattern):
        """
        varify the input <pi_filter_pattern>
        """
        if pi_filter_pattern:
            if pi_filter_pattern.lower() == CommConstV.FILTER_EXCLUDE_RDONLY.lower():
                return True
            else:
                return False
        else:
            return False

    @classmethod
    def is_filter_pattern_include_exclude_updateable(cls, pi_filter_pattern):
        """
        varify the input <pi_filter_pattern>
        """
        if pi_filter_pattern:
            if pi_filter_pattern.lower() == CommConstV.FILTER_INCLUDE_EXCLUDE_UPDATEABLE.lower():
                return True
            else:
                return False
        else:
            return False

    @classmethod
    def is_str_included(cls, pi_str, pi_data_set, case_sensitive=True, asterisk_for_all=True):
        """
        Check if a string A is included in B.
        B can be a string, e.g. '123' or '*', or a list, e.g. ['123,'456']
        """
        # if target is a string
        if isinstance(pi_data_set, str):
            # if '*' represent everything
            if asterisk_for_all and pi_data_set == '*':
                return True
            # for case sensitive mode
            elif case_sensitive and pi_str == pi_data_set:
                return True
            # for case insensitive mode
            elif not case_sensitive and pi_str.lower() == pi_data_set.lower():
                return True
        # if target in policy is a array, .e.g. ['12345','67890']
        elif isinstance(pi_data_set, (list, tuple, set)):
            # if '*' represent everything
            if asterisk_for_all and '*' in pi_data_set:
                return True
            # for case sensitive mode
            elif case_sensitive and pi_str in pi_data_set:
                return True
            # for case insensitive mode
            elif not case_sensitive:
                pi_data_set_l = [x.lower() for x in pi_data_set]
                if pi_str.lower() in pi_data_set_l:
                    return True
        # all other senarios
        return False

    @classmethod
    def is_valid_ip(cls, pi_ip_str):
        """
        Check if a string is a valid ipv4 address
        """
        try:
            if pi_ip_str:
                ip = ipaddress.ip_address(pi_ip_str)
                return True
            else:
                return False
        except ValueError:
            return False

    @classmethod
    def parse_ip_range(cls, pi_range_str):
        """
        Get the first and last ip range, e.g. 1.1.1.1 - 2.2.2.2
        """
        response = (None, None)
        if pi_range_str and pi_range_str.find('-') > 0:

            # get the first ip and the last ip of the range
            ip_range = pi_range_str.split('-')
            from_ip = str(ip_range[0]).strip()
            to_ip = str(ip_range[-1]).strip()

            # validate the ip address
            if cls.is_valid_ip(from_ip) and cls.is_valid_ip(to_ip):
                response = (from_ip, to_ip)
        return response

    @classmethod
    def parse_cidr(cls, pi_cidr_str, pi_stick=False):
        """
        Get the first and the last ip of a ipv4 CIDR
        """
        response = (None, None)
        try:
            if pi_cidr_str and pi_cidr_str.find('/') > 0:
                # get the first ip and the last ip of the CIDR
                ip_range = ipaddress.ip_network(pi_cidr_str, pi_stick)
                from_ip = str(ip_range[0]).strip()
                to_ip = str(ip_range[-1]).strip()

                # validate the ip address
                if cls.is_valid_ip(from_ip) and cls.is_valid_ip(to_ip):
                    response = (from_ip, to_ip)
            return response
        except ValueError as e:
            print('Unexpected error:{}'.format(str(e)))
            return response

    @classmethod
    def compare_ip_address(cls, pi_ip_address1, pi_ip_address2):
        """
        Compare two ip addresses
        Output:
            -1: ip address 1 is less than ip address 2
            0:  ip address 1 is equal to ip address 2
            1:  ip address 1 is larger than ip address 2
        """
        ip_address1 = ipaddress.ip_address(pi_ip_address1)
        ip_address2 = ipaddress.ip_address(pi_ip_address2)
        if ip_address1 < ip_address2:
            return -1
        elif ip_address1 == ip_address2:
            return 0
        else:
            return 1

    @classmethod
    def dynamodb_json_2_json(cls, pi_dynamodb_json):
        """
        Convert Dynamodb json to normal json
        Input:
            pi_dynamodb_json: Dynamodb json, e.g. {"key": {"S":"value"}}
        Output:
            normal json format, e.g. {"key":"value"}
        """
        return json_util.loads(pi_dynamodb_json, as_dict=True)

    @classmethod
    def json_2_html(cls, pi_json):
        """
        Convert JSON format to HTML format
        Input:
            pi_json: json format dictionary, e.g. {"key":"value"}
        Output:
            hmtl format string, e.g "<br>this is sample<br>"
        """
        return json2html.convert(json = pi_json)

    @classmethod
    def parse_json_by_path(cls, pi_json, pi_key, pi_separator='.'):
        """
        Get the value from a json by path
        Input:
            pi_json: a json object, e.g. {"key":"value"}
            pi_key: a key like a.b.c.d
        Output:
            the value of the given key
        """
        try:
            return dpath.util.get(pi_json, pi_key, pi_separator)
        except KeyError:
            return None
