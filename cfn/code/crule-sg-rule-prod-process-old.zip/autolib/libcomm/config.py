"""
Implement Config module
"""

import json


class Config:
    def __init__(self, pi_config_file):
        self.__config_file = pi_config_file
        with open(self.__config_file, 'r') as fh:
            self.__json_config = json.load(fh)

    def get_config(self):
        return self.__json_config

    def get(self, pi_value_path):
        """
        Get value from config.
        Input:
            json example:
                {
                    'system': {'proxy':'tcp'}
                    'env_list': ['prod','test','dev']
                }

            value_path: like: ['system']['proxy'] will return: tcp
                        like: ['env'][0] will return: prod
        """
        exec_str = "self.json_config{}".format(pi_value_path)
        return eval(exec_str)
