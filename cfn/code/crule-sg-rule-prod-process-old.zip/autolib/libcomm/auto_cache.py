
import os
import functools
import hashlib
import inspect
from diskcache import FanoutCache
from autolib.libcomm.log2 import Log2
from copy import deepcopy
import datetime


class AutoCache():
    """
    Auto cache, cache is help to improve performance,
    if any error happened, then will stop use cache,
    but will not stop normal work.
    """
    def __init__(self, pi_cache_file, enable_env_control=False, default_expired_seconds=10):
        """
        enable_env_control: True | False
        if value is True:
            means if use cache function rely on environment variable:
            G_AUTOCACHE_ENABLE_G, use cache only when its value 'on' or 'true'
        else: (default)
            means environment variable: G_AUTOCACHE_ENABLE_G not referred
            always do cache if AutoCache was called
        """
        self.__cache_file = pi_cache_file
        #self.__cache = Cache(self.__cache_file)
        self.__cache = FanoutCache(self.__cache_file)
        self.__enable_env_control = enable_env_control
        self.__default_expired_seconds = default_expired_seconds

    @classmethod
    def c_is_enabled(cls):
        """
        Check if auto cache enabled

        Return:
        True  : if enabled
        False : if disabled
        """
        value = os.environ.get('G_AUTOCACHE_ENABLE_G')
        if str(value).lower() in ["on", "true"]:
            return True
        else:
            return False

    @classmethod
    def c_is_disabled(cls):
        """
        Check if auto cache is disabled
        """
        return not cls.c_is_enabled()

    @classmethod
    def c_enable_cache(cls):
        """
        Set key value in current session environment
        """
        os.environ['G_AUTOCACHE_ENABLE_G'] = "ON"

    def is_disabled(self):
        """
        Check if auto cache is disabled
        """
        if self.__enable_env_control == True:
            return self.c_is_disabled()
        else:
            return False

    def set(self, key, value, expire_seconds=None):
        """
        set key value to cache,
        """
        if self.is_disabled(): return
        if expire_seconds is None:
            expire_seconds = self.__default_expired_seconds

        if expire_seconds is None:
            expire_seconds = 0
        else:
            expire_seconds = int(expire_seconds)

        if expire_seconds and expire_seconds > 0:
            self.__cache.set(key, value, expire=expire_seconds)

    def get(self, key, **kwargs):
        """
        get key value from cache,

        get(key, default=None, read=False, expire_time=False, tag=False, retry=False)
        Retrieve value from cache. If key is missing, return default.

        Parameters:	
        key – key for item
        default – return value if key is missing (default None)
        read (bool) – if True, return file handle to value (default False)
        expire_time (float) – if True, return expire_time in tuple (default False)
        tag – if True, return tag in tuple (default False)
        retry (bool) – retry if database timeout expires (default False)

        Returns:	
        value for item if key is found else default
        """
        if self.is_disabled(): return
        return self.__cache.get(key, **kwargs)


    def get_keys(self):
        """
        get keys list
        return:
        ['key1','key2','key3']
    
        """
        #return sorted(list(self.__cache.__iter__()))
        return list(self.__cache.__iter__())

    def clear(self):
        if self.is_disabled(): return
        self.__cache.clear()




    def call(self, pi_key_conf:dict, pi_func, *func_args, **func_kwargs):
        """
        Call function by cache mode, input key config 

        pi_cache_dict: {
            "key": "xxxxx"
            "expire_seconds": "100"
            "key_plus":""
        }
        """
        key_tag = pi_key_conf.get("key")
        if not key_tag:
            try:
                key_tag = pi_func.__qualname__
            except AttributeError:
                key_tag = pi_func.__name__
            key_tag = pi_func.__qualname__ + key_tag

        key_plus = pi_key_conf.get("key_plus", "")
        if key_plus:
            key_plus = hashlib.md5(str(key_plus).encode('utf-8')).hexdigest()
        cache_key = key_tag + key_plus

        data = self.get(cache_key)
        if data:
            Log2.debug("Get data from cache: {}".format(cache_key))
            return data
        else:
            Log2.debug("Get data from fresh call: {}".format(cache_key))
            result = pi_func(*func_args, **func_kwargs)
            if result:
                self.set(cache_key, result, pi_key_conf.get("expire_seconds", 0))
                return result
            else:
                return None


    def b_make_key(self, pi_func, pi_locals, pi_name=None, pi_typed=False):
        """
        {
            'kwargs': {'arg1': 'spam', 'arg2': 'eggs'}, 
            'args': (30, 40, 50), 'a': 20
        }
        """
        if pi_name is None:
            try:
                reference = pi_func.__qualname__
            except AttributeError:
                reference = pi_func.__name__
            reference = pi_func.__module__ + reference
        else:
            reference = pi_name
        reference = (reference,)
        #print("pi_func info={}".format(inspect.getargspec(pi_func)))
        print("pi_func info={}".format(inspect.getfullargspec(pi_func)))

        print("pi_locals={}".format(pi_locals))
        print("reference={}".format(reference))
        args = pi_locals.get('args')
        kwargs = pi_locals.get('kwargs')
        print("args={}".format(args))
        print("kwargs={}".format(kwargs))
        key = reference
        if args or kwargs:
            if args:
                print("inside args: {}".format(args))
                key = reference + args 
            if kwargs:
                    sorted_items = sorted(kwargs.items())
                    for item in sorted_items:
                        key += item
            if pi_typed:
                    key += tuple(type(arg) for arg in args)
                    if kwargs:
                        key += tuple(type(value) for _, value in sorted_items)
        else:
            args = pi_locals
            sorted_items = sorted(args.items())
            for item in sorted_items:
                key += item

        return key


    @classmethod
    def c_call(cls, pi_typed, pi_expire, pi_tag, **cache_kwargs):
        if cls.c_is_disabled():
            def wrapper_func_withoutcache_decorator(func):
                @functools.wraps(func)
                def wrapper_func_withoutcache(*args, **kwargs):
                    return func(*args, **kwargs)
                return wrapper_func_withoutcache
            return wrapper_func_withoutcache_decorator
        else:
            cache = FanoutCache('/tmp/diskcache')
            return cache.memoize(typed=pi_typed, expire=pi_expire, tag=pi_tag)


class CacheConfig():
    """
    Class of CacheConfig
    Use especially for AutoCache related configuration

    {
        "keys" :{
            "org_files": {
                "key_plus":
                "expire_seconds":
            },
            ...
        }
        "cache_path": "/tmp/abc"
    }
    """

    def __init__(self, pi_conf):
        self.__conf = pi_conf

    def get_config(self):
        return deepcopy(self.__conf)

    def _get_keys(self):
        """
        Get cache keys
        return dict type
        """
        return deepcopy(self.__conf.get("keys"))

    def get_key_config(self, pi_key_name):
        """
        Get cache key config by key name
        return key_name
        """
        key_config = self._get_keys().get(pi_key_name)
        if key_config is None:
            raise ValueError("key:{} not found".format(pi_key_name))
        key_config["key"] = pi_key_name
        return key_config

    def get_key(self, pi_key_name):
        """
        Get cache key_plus value by given key name
        return key_plus (str)
        """
        return (self.get_key_config(pi_key_name) or {}).get('key')



    def get_key_plus(self, pi_key_name):
        """
        Get cache key_plus value by given key name
        return key_plus (str)
        """
        return (self.get_key_config(pi_key_name) or {}).get('key_plus')

    def get_key_expire_seconds(self, pi_key_name):
        """
        Get cache key_plus value by given key name
        return key_plus (str)
        """
        return (self.get_key_config(pi_key_name) or {}).get('expire_seconds')

    def get_cache_path(self):
        """
        """
        return deepcopy(self.__conf.get('cache_path'))