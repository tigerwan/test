import requests
import json
import sys
import os
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc
from autolib.libcomm.processpool import ProcessPool


class NewsSentry:
    """
    class of News Sentry Interface
    Use to get keys from News Sentry system
    """
    def __init__(self):
        requests.packages.urllib3.disable_warnings()
        self.__request_session = requests.Session()

    def get_saml_by_login_ad(self, pi_login_url, pi_username, pi_password):
        """
        Get SAML by credential login to Windows AD 

        pi_login_url: url to login to windows AD
                      "https://sentry.news.newslimited.local/api/login",

        Request:
        {
            "username": "string",
            "password": "string"
        }
        Response
        {
            "Roles": [
                {
                    "account": "string",
                    "awsrole": "string"
                }
                ...
                {
                    "account": "string",
                    "awsrole": "string"
                }
            ],
            "SAMLResponse": "string"
        }
        """
        auth = {'username': pi_username, 'password': pi_password}
        self.__request_session.trust_env = False
        response = self.__request_session.post(pi_login_url, data=auth, verify=False)
        if response.status_code == 200:
            return response.json()
        else:
            msg = "login failed, Error code: {}".format(str(response.status_code))
            more_msg = "{} \nresponse: {}".format(msg, response)
            raise Exception(more_msg)

    def get_key(self, 
                pi_saml, 
                pi_getkey_url,
                pi_account_id,
                pi_role):
        """
        Get key from Sentry

        pi_getkey_url: "https://sentry.news.newslimited.local/api/getkey",

        Return format:
        {
            "AccessKeyId": "BCIA4YYIC7UIVWJJ3CMH",
            "SecretAccessKey": "ovsYC4z1RqFHujlUiZVYLGBN9zqWSsQK2ypS+wxD",
            "SessionToken": "FQoGZXIvYXdzEKH//////////wEaDFI+aoQZ4r1kC1b0MiKuAipdK09f8NCnpRHLffdxKC8sx7AV1ZyODqkOMkgqqAS8rordmejaEIk8KjqN8O2uoUhAxBRy4M2sgc88b9nmrCEtYI8py10TRZ2oLXzAcyco7x/0A8NTLSY9HRU0iGzuedvtH7pU/Dou7D7SAWQrjWCFIdZPffwL7trIuArejPV9cBZDJA3+VVnT+yuRIPquAYaPOYyTqt6ZIwpfolrFd9C1yWU+qsV/+UtcfXEtcZjIto/LMgdC8EvML2wSJXBYqR9Rw0jg8DvHF9EDV65Xlv5EG95rnheftbIyt1FARHG0WhJwMZpzsme0V9JoLfPFEdgHoZGMFylhj5qH0fixiUJfRV96lTO0oFw1GZNl+qHmrjtNHta5+0oHRcmhGqivOPDVoOkdOad7pXfanXuoKKHpk9wF",
            "Expiration": "2018-08-28T08:07:13.000Z"
        }
        """
        requests.packages.urllib3.disable_warnings()
        payload = {'samlResponse': pi_saml,
                   'aws_account': pi_account_id,
                   'aws_role': pi_role}
        self.__request_session.trust_env = False
        response = self.__request_session.post(
                        pi_getkey_url, data=payload, verify=False)
        if response.status_code == 200:
            credentials=response.json()
            return credentials.get("Credentials")
        else:
            msg = "get key failed, account {0} and role {1}".format(pi_account_id, pi_role)
            more_msg = "{} \nresponse: {}".format(msg, response)
            raise Exception(more_msg)



    def get_keys_bysaml(self, 
                        pi_saml,
                        pi_saml_roles,
                        pi_getkey_url,
                        progressing=None
                        ):

        """
        pi_saml: returned by get_saml_by_login_ad, response/SAMLResponse
        pi_saml_roles: returned by get_saml_by_login_ad, response/Roles
        pi_getkey_url: url to get key from Sentry
                       "https://sentry.news.newslimited.local/api/getkey"
                    
        Get keys by saml response. SAML and Roles

        Return format:
        {
            "AccountId": "xxxxxxxxxx"
            "Role": "yyyyyyyyy"
            "AccessKeyId": "BCIA4YYIC7UIVWJJ3CMH",
            "SecretAccessKey": "ovsYC4z1RqFHujlUiZVYLGBN9zqWSsQK2ypS+wxD",
            "SessionToken": "FQoGZXIvYXdzEKH//////////wEaDFI+aoQZ4r1kC1b0MiKuAipdK09f8NCnpRHLffdxKC8sx7AV1ZyODqkOMkgqqAS8rordmejaEIk8KjqN8O2uoUhAxBRy4M2sgc88b9nmrCEtYI8py10TRZ2oLXzAcyco7x/0A8NTLSY9HRU0iGzuedvtH7pU/Dou7D7SAWQrjWCFIdZPffwL7trIuArejPV9cBZDJA3+VVnT+yuRIPquAYaPOYyTqt6ZIwpfolrFd9C1yWU+qsV/+UtcfXEtcZjIto/LMgdC8EvML2wSJXBYqR9Rw0jg8DvHF9EDV65Xlv5EG95rnheftbIyt1FARHG0WhJwMZpzsme0V9JoLfPFEdgHoZGMFylhj5qH0fixiUJfRV96lTO0oFw1GZNl+qHmrjtNHta5+0oHRcmhGqivOPDVoOkdOad7pXfanXuoKKHpk9wF",
            "Expiration": "2018-08-28T08:07:13.000Z"
        }

        """
        key_profiles = []
        if pi_saml_roles:
            for saml_role in pi_saml_roles:
                account_id = saml_role["account"]
                role = saml_role["awsrole"]
                Log2.progressing_time_if("{} {} ... ".format(account_id, role), progressing)

                credentials = self.get_key(pi_saml, pi_getkey_url, account_id, role)
                profile = {}
                profile['AccountId'] = account_id
                profile['Role'] = role
                profile.update(credentials)
                key_profiles.append(profile)
                Log2.progressing_if("done\n", progressing)
        return key_profiles

    def get_keys(self, 
                 pi_username,
                 pi_password,
                 pi_login_url,
                 pi_getkey_url,
                 progressing=None
                 ):
        """
        Get keys by credentials that login AD

        pi_login_url: url to login to windows AD
                        "https://sentry.news.newslimited.local/api/login",
        pi_getkey_url: url to get key from Sentry
                       "https://sentry.news.newslimited.local/api/getkey"
        """
        Log2.progressing_time_if("Get SAML from Sentry...", progressing)
        saml_response = self.get_saml_by_login_ad(pi_login_url, pi_username, pi_password)
        Log2.progressing_if("done \n", progressing)

        saml = saml_response.get('SAMLResponse')
        saml_roles = saml_response.get('Roles')
        saml_roles.sort(key=lambda x: x["account"])

        Log2.progressing_time_if("Get keys from Sentry...\n", progressing)
        return self.get_keys_bysaml(saml, saml_roles, pi_getkey_url, progressing)

    def get_key2(self, 
                        pi_saml, 
                        pi_getkey_url,
                        pi_account_id,
                        pi_role):
        """
        Return extra information including AccountId and Role
        """
        result = self.get_key(pi_saml, pi_getkey_url, pi_account_id, pi_role)
        if result:
            result['AccountId'] = pi_account_id
            result['Role'] = pi_role
        return result

    def get_keys_bysaml_bypool(self, 
                               pi_process_pool,
                               pi_saml,
                               pi_saml_roles,
                               pi_getkey_url,
                               progressing=None
                            ):

        """
        pi_saml: returned by get_saml_by_login_ad, response/SAMLResponse
        pi_saml_roles: returned by get_saml_by_login_ad, response/Roles
        pi_getkey_url: url to get key from Sentry
                       "https://sentry.news.newslimited.local/api/getkey"
                    
        Get keys by saml response. SAML and Roles

        Return format:
        {
            "AccountId": "xxxxxxxxxx"
            "Role": "yyyyyyyyy"
            "AccessKeyId": "BCIA4YYIC7UIVWJJ3CMH",
            "SecretAccessKey": "ovsYC4z1RqFHujlUiZVYLGBN9zqWSsQK2ypS+wxD",
            "SessionToken": "FQoGZXIvYXdzEKH//////////wEaDFI+aoQZ4r1kC1b0MiKuAipdK09f8NCnpRHLffdxKC8sx7AV1ZyODqkOMkgqqAS8rordmejaEIk8KjqN8O2uoUhAxBRy4M2sgc88b9nmrCEtYI8py10TRZ2oLXzAcyco7x/0A8NTLSY9HRU0iGzuedvtH7pU/Dou7D7SAWQrjWCFIdZPffwL7trIuArejPV9cBZDJA3+VVnT+yuRIPquAYaPOYyTqt6ZIwpfolrFd9C1yWU+qsV/+UtcfXEtcZjIto/LMgdC8EvML2wSJXBYqR9Rw0jg8DvHF9EDV65Xlv5EG95rnheftbIyt1FARHG0WhJwMZpzsme0V9JoLfPFEdgHoZGMFylhj5qH0fixiUJfRV96lTO0oFw1GZNl+qHmrjtNHta5+0oHRcmhGqivOPDVoOkdOad7pXfanXuoKKHpk9wF",
            "Expiration": "2018-08-28T08:07:13.000Z"
        }

        """
        if pi_saml_roles:
            tasks = []
            for saml_role in pi_saml_roles:
                account_id = saml_role["account"]
                role = saml_role["awsrole"]
                tasks.append((self.get_key2, (pi_saml, pi_getkey_url, account_id, role)))
            pi_process_pool.put_tasks(tasks)
            results = pi_process_pool.get_results()
            return results
        else:
            return None


    def get_keys_bypool(self, 
                        pi_process_pool,
                        pi_username,
                        pi_password,
                        pi_login_url,
                        pi_getkey_url,
                        progressing=None
                        ):
        """
        Get keys by credentials that login AD

        pi_login_url: url to login to windows AD
                        "https://sentry.news.newslimited.local/api/login",
        pi_getkey_url: url to get key from Sentry
                       "https://sentry.news.newslimited.local/api/getkey"
        """
        saml_response = self.get_saml_by_login_ad(pi_login_url, pi_username, pi_password)

        saml = saml_response.get('SAMLResponse')
        saml_roles = saml_response.get('Roles')
        saml_roles.sort(key=lambda x: x["account"])

        return self.get_keys_bysaml_bypool(pi_process_pool, saml, saml_roles, pi_getkey_url, progressing)

    @classmethod
    def c_test_get_keys(cls, pi_username, pi_password):
        start_time = CommFunc.get_current_datetime()
        sentry = NewsSentry()
        key_profiles = sentry.get_keys(pi_username,
                        pi_password,
                        "https://sentry.news.newslimited.local/api/login",
                        "https://sentry.news.newslimited.local/api/getkey", progressing="On")
        end_time = CommFunc.get_current_datetime()
        Log2.echo(key_profiles)
        Log2.echo("start: {} \n  End: {}".format(start_time, end_time))
        

    @classmethod
    def c_test_get_keys_bypool(cls, pi_username, pi_password, pi_process_num=3):
        start_time = CommFunc.get_current_datetime()
        Log2.set_level(130)
        proc_pool=ProcessPool()
        # Start processes pool
        proc_pool.start(pi_process_num)

        sentry = NewsSentry()
        key_profiles = sentry.get_keys_bypool(
                        proc_pool,
                        pi_username,
                        pi_password,
                        "https://sentry.news.newslimited.local/api/login",
                        "https://sentry.news.newslimited.local/api/getkey", progressing="On")
        end_time = CommFunc.get_current_datetime()
        Log2.echo(key_profiles)
        Log2.echo("Run task by pool, processes: {}".format(pi_process_num))
        Log2.echo("Start: {} \n  End: {}".format(start_time, end_time))
        proc_pool.stop()