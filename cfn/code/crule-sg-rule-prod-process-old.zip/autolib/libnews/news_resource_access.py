"""
Module: news_resource_access
Create Date: 2018-07-31
Function: Implement functions of managing resource access permission
"""

# from autolib.libcomm.log2 import Log2
# from copy import deepcopy
from autolib.libaws.aws_dynamodb import AwsDynamodbI
from autolib.libaws.aws_session import AwsSessionI
from autolib.libcomm.log2 import Log2


class NewsResourceAccessPermission:
    """
    NewsResourceAccessPermission Class.

    Including functions of processing resource access/remediation permission which is stored in dyanmodb
    """

    def __init__(self, pi_session_ro=None, pi_session_rw=None, pi_session=None, pi_auto_cache=None, **kwargs):
        """
        Initalization.
        """
        self.__auto_cache = pi_auto_cache
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)
        self.__resources = None

    def get_resource(self, pi_table_name, pi_tool_name=None, pi_account_id=None, pi_action_permission=None, pi_resource_type=None):
        """
        Get allow/deny list of a given tool from dynamodb table
        Input:
            pi_table_name:  the table name to query
            pi_tool_name:   the tool name, e.g. configrule-cloudtrail
            pi_account_id:  the account id
            pi_action_permission:    True|False, which is to fetch the resources allowing/denying action
            pi_resource_type:   the resource type to query, e.g. ['instance', 'elb'], None means all resource type
        Return:
            an array of scan/query result.e.g
            [
                {
                    'tool':'tool1',
                    'account':'12345',
                    'resource_id':'i-1234',
                    ....
                },
                {
                    ....
                }
            ]
        """

        # generate FilterExpression, ExpressionAttributeNames and ExpressionAttributeValues
        filter_dict = {}
        if pi_tool_name:
            filter_dict['tool'] = {'S': pi_tool_name}
        if pi_account_id:
            filter_dict['account_id'] = [
                {'S': pi_account_id},
                {'S': '*'}
            ]
        if pi_action_permission:
            filter_dict['run_action'] = {'S': pi_action_permission}
        if pi_resource_type:
            filter_dict['resource_type'] = {'S': pi_resource_type}

        filter_expression = AwsDynamodbI.generate_filter_expression(pi_dict=filter_dict)

        # concat scan/query parameters
        param = {
            'TableName': pi_table_name
        }

        if filter_expression:
            param.update(filter_expression)

        # scan table
        dbi = AwsDynamodbI(self.__session_ro)
        table = dbi.scan_table(**param)
        result = {
            'Items': table['Items'],
            'Count': table['Count'],
            'ScannedCount': table['ScannedCount']
        }

        # remove data type from the result
        self.__resources = AwsDynamodbI.extract_rows_without_type(result)
        return self.__resources

    def lazy_get_resource(self, pi_table_name, pi_tool_name=None, pi_account_id=None, pi_action_permission=None, pi_resource_type=None):
        if not self.__resources and pi_table_name:
            self.__resources = self.get_resource(
                pi_table_name=pi_table_name,
                pi_tool_name=pi_tool_name,
                pi_account_id=pi_account_id,
                pi_action_permission=pi_action_permission,
                pi_resource_type=pi_resource_type
            )
        return self.__resources

    def get_resource_id(self, pi_table_name=None, pi_tool_name=None, pi_account_id=None, pi_action_permission=None, pi_resource_type=None):
        """
        Get allow/deny resource list of a given tool from dynamodb table
        Input:
            pi_table_name:  the table name to query
            pi_tool_name:   the tool name, e.g. configrule-cloudtrail
            pi_account_id:  the account id
            pi_action_permission:    True|False, which is to fetch the resources allowing/denying action
            pi_resource_type:   the resource type to query, e.g. ['instance', 'elb'], None means all resource type
        Return:
            a dictionary of included and excluded resource ids, e.g.
            {
                "allow": ['i-123', 'i-456'],
                "deny": ['i-7777', 'i-88888']
            }
        """
        response = {
            'allow': [],
            'deny': []
        }

        if not self.__resources and pi_table_name:
            self.lazy_get_resource(
                pi_table_name=pi_table_name,
                pi_tool_name=pi_tool_name,
                pi_account_id=pi_account_id,
                pi_action_permission=pi_action_permission,
                pi_resource_type=pi_resource_type
            )

        if self.__resources:
            for item in self.__resources:
                item_action_permission = item.get('run_action','deny')
                if item_action_permission not in response:
                    response[item_action_permission] = []

                if 'resource_id' in item:
                    response[item_action_permission].append(item['resource_id'])
        else:
            Log2.debug('No resource explicitly configured in dynamodb to be preserved or must be proceed')

        return response
