"""
Module: news_policy
Create Date: 2018-07-31
Function: Implement news organization module.
"""
import json
from copy import deepcopy
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc
# from autolib.libaws.aws_dynamodb import AwsDynamodbI
from autolib.libaws.aws_session import AwsSessionI
from autolib.libnews.news_resource_access import NewsResourceAccessPermission


class NewsAccountAccessPolicy:
    """
    NewsAccountAccessPolicy Class.

    Including functions for checking account level access/remediation based on policy.
    """

    def __init__(self, pi_session_ro=None, pi_session_rw=None, pi_session=None, pi_auto_cache=None, **kwargs):
        """
        Initalization.
        """
        self.__auto_cache = pi_auto_cache
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)
        self.__raw_policy = None
        self.__policy = None

    def set_policy(self, pi_raw_policy):
        """
        Set policy
        Input:
            pi_raw_policy:  policy for accessing account as follows
                {
                    'allow': {
                        'account': [],
                        'managed': True,
                        'env': ['DEV', 'UAT', 'PROD']
                    },
                    'deny': {
                        'account': [],
                        'managed': False,
                        'env': []
                    },
                    'force_allow': {
                        'account': [],
                        'env': []
                    }
                }

                Note:
                    1. it currently supports allow/deny/force_allow sections, all sections support account, managed, and env elements.
                    2. deny section ovrwrite allow section, and force_allow section overwrite deny
        """
        self.__raw_policy = pi_raw_policy
        self.__policy = pi_raw_policy

    def get_policy(self):
        """
        Return baked policy
        """
        return self.__policy

    def match_account(self, pi_account_id, pi_account_on_policy):
        """
        Check if the given account id is in the account list of policy
        Input:
            pi_account_id:     account id to match
            pi_account_on_policy:   the account list defined in the policy
                                    it can be either '*', or a single account id or a account list
        Output:
            True means matched, False means not
        """

        if not pi_account_id or not pi_account_on_policy:
            return False

        return CommFunc.is_str_included(pi_str=pi_account_id, pi_data_set=pi_account_on_policy)

    def match_env(self, pi_account_env, pi_account_env_on_policy, case_sensitive=False):
        """
        Check if the given account environment match the environment in the policy
        Input:
            pi_account_env:     account environment .e.g. dev, uat, prod
            pi_account_env_on_policy:   account environment in policy
            case_sensitive:     match in case sensitive mode or not
        Output:
            True means matched, False means not
        """

        if not pi_account_env or not pi_account_env_on_policy:
            return False

        return CommFunc.is_str_included(pi_str=pi_account_env, pi_data_set=pi_account_env_on_policy)

    def match_managed(self, pi_managed_account, pi_managed_account_on_policy):
        """
        Check if the given account's managed flag matches the policy
        Input:
            pi_managed_account:     account's managed flag, True means managed account, False means no
            pi_managed_account_on_policy:   account's managed flag in policy
        Output:
            True means matched, False means not
        """

        if pi_managed_account == pi_managed_account_on_policy:
            return True
        else:
            return False

    def check_access(self, pi_managed_account):
        """
        Check if the given account allow access
        Input:
            pi_managed_account:  True means the managed account, False means nomanaged account
        Output
            True means allow access, False means not
        """
        return pi_managed_account

    def check_remediation(self, pi_policy, pi_account_id=None, pi_account_env=None, pi_managed_account=None, pi_allow_remediation=None):
        """
        Check if the given account allow remediation
        Input:
            pi_policy:          sub section of the policy, e.g. allow/deny/force_allow
            pi_account_id:      account id
            pi_account_env:     account environment .e.g. dev, uat, prod
            pi_managed_account: account's managed flag, True means managed account, False means no
        Output
            True means allow remediation, False means report only
        """
        response = False

        # if pi_allow_remediation is False, it means disallow remediation
        if not pi_allow_remediation:
            return False

        is_matched = {}
        # check if the given account allows access
        # check force_allow section
        if pi_policy.get('force_allow'):
            Log2.debug('Processing account remediation policy(force_allow)')
            is_matched['force_allow'] = self.check_policy(
                pi_policy=pi_policy.get('force_allow'),
                pi_account_id=pi_account_id,
                pi_account_env=pi_account_env,
                pi_managed_account=pi_managed_account
            )

        # if not in force_allow section(or force_allow is not defined ), check if it's in deny section
        if not is_matched.get('force_allow') and pi_policy.get('deny'):
            Log2.debug('Processing account remediation policy(deny)')
            is_matched['deny'] = self.check_policy(
                pi_policy=pi_policy.get('deny'),
                pi_account_id=pi_account_id,
                pi_account_env=pi_account_env,
                pi_managed_account=pi_managed_account
            )

        # if not in force_allow section(or force_allow is ot defined ), and not in deny section(or deny section is not defined), check if it's allow section
        if not is_matched.get('force_allow') and not is_matched.get('deny') and pi_policy.get('allow'):
            Log2.debug('Processing account remediation policy(allow)')
            is_matched['allow'] = self.check_policy(
                pi_policy=pi_policy.get('allow'),
                pi_account_id=pi_account_id,
                pi_account_env=pi_account_env,
                pi_managed_account=pi_managed_account
            )

        # account allows remediation when
        #   1. matches force_allow section configuration, or
        #   2. match allow section but neither force_allow section nor deny section
        if is_matched.get('force_allow'):
            response = True
        elif is_matched.get('deny'):
            response = False
        elif is_matched.get('allow'):
            response = True

        return response

    def check_policy(self, pi_policy, pi_account_id=None, pi_account_env=None, pi_managed_account=False):
        """
        Check if the given account match policy
        Input:
        Input:
            pi_policy:          sub section of the policy, e.g. allow/deny/force_allow
            pi_account_id:      account id
            pi_account_env:     account environment .e.g. dev, uat, prod
            pi_managed_account: account's managed flag, True means managed account, False means no
        Output
            True means allow remediation, False means report only
        """

        # check account id
        if 'account' in pi_policy and pi_account_id and self.match_account(pi_account_id=pi_account_id, pi_account_on_policy=pi_policy['account']):
            Log2.debug('Found the matched account id {} in the policy of {}'.format(pi_account_id, str(pi_policy)))
            return True

        # check account env
        if 'env' in pi_policy and pi_account_env and self.match_env(pi_account_env=pi_account_env, pi_account_env_on_policy=pi_policy['env']):
            Log2.debug('Found the matched account env {} in the policy of {}'.format(pi_account_env, str(pi_policy)))
            return True

        # check account env
        if 'managed' in pi_policy and self.match_managed(pi_managed_account=pi_managed_account, pi_managed_account_on_policy=pi_policy['managed']):
            Log2.debug('Found the matched managed flag {} in the policy of {}'.format(str(pi_managed_account), str(pi_policy)))
            return True

        return False

    def check_allow_permission(self, pi_account_id=None, pi_account_env=None, pi_managed_account=False, pi_allow_remediation=False):
        """
        Check if the the given account is allowed to access and remediation by the given policy
        Input:
            pi_account_id:      account id
            pi_account_env:     account environment .e.g. dev, uat, prod
            pi_managed_account: account's managed flag, True means managed account, False means no
            pi_allow_remediation:  account's remediation flag, True means the given account allows remediation.
        Output:
            a dictionary like below, allow_access is account is allowed to access or not, allow_remediation is account is allowed to remediated or not. if allow_access is False, allow_remediation is False too
            {
                'allow_access': False,
                'allow_remediation': False
            }

        """

        response = {
            'allow_access': False,
            'allow_remediation': False
        }

        # check if the account allows tool to access
        response['allow_access'] = self.check_access(pi_managed_account=pi_managed_account)
        if not response['allow_access']:
            return response

        # check if the account allows tool to remediate
        if not self.__policy:
            Log2.debug('Warning while checking account access policy: policy is not configured')
            return response

        response['allow_remediation'] = self.check_remediation(
            pi_policy=self.__policy,
            pi_account_id=pi_account_id,
            pi_account_env=pi_account_env,
            pi_managed_account=pi_managed_account,
            pi_allow_remediation=pi_allow_remediation
        )

        return response


class NewsResourceAccessPolicy:
    """
    NewsAResourceAccessPolicy Class.

    Including functions for checking resource level access/remediation based on policy.
    """

    def __init__(self, pi_raw_policy=None, pi_session_ro=None, pi_session_rw=None, pi_session=None, pi_auto_cache=None, **kwargs):
        """
        Initalization.
        """
        self.__auto_cache = pi_auto_cache
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)
        self.__raw_policy = pi_raw_policy
        self.__policy = None

    def set_policy(self, pi_raw_policy, pi_tool_name=None, pi_account_id=None, pi_action_permission=None, pi_resource_type=None):
        """
        Set the raw policy,
        read resources from table refered by resource_source_table, and fill in final policy
        """
        if pi_raw_policy:
            self.__raw_policy = pi_raw_policy

            self.__policy = self.feed_resource_from_db(
                pi_session=self.__session_ro,
                pi_access_policy=self.__raw_policy,
                pi_tool_name=pi_tool_name,
                pi_account_id=pi_account_id,
                pi_action_permission=pi_action_permission,
                pi_resource_type=pi_resource_type
            )

    def get_policy(self):
        """
        Return baked policy
        """
        return self.__policy

    def match_resource(self, pi_resource_id, pi_resource_on_policy):
        """
        Check if the given account id is in the account list of policy
        Input:
            pi_resource_id:     resource id to match
            pi_resource_on_policy:   the resource id list defined in the policy
                                    it can be either '*', or a single resource id or a resource list
        Output:
            True means matched, False means not
        """
        if not pi_resource_id or not pi_resource_on_policy:
            return False

        return CommFunc.is_str_included(pi_str=pi_resource_id, pi_data_set=pi_resource_on_policy)

    def check_policy(self, pi_policy=None, pi_resource_id=None, pi_tag=None):
        """
        Check if the given resource matchs policy
        Input:
            pi_policy:          sub policy of resource acess policy, .e.g, allow/deny/force_allow part of the policy
            pi_tag:             resource tags
        Output
            True means allowed, False means no
        """
        # check resource id
        if 'resource' in pi_policy and pi_resource_id and self.match_resource(pi_resource_id=pi_resource_id, pi_resource_on_policy=pi_policy['resource']):
            Log2.debug('Found the matched resource id {} in the policy of {}'.format(pi_resource_id, str(pi_policy)))
            return True

        return False

    def check_allow_permission(self, pi_resource_id=None, pi_tag=None):
        """
        Check if the the given resource is allowed for the operation by the given policy
        Input:
            pi_resource_id:     resource id
            pi_tag:             resource tags
        """

        response = False

        if not self.__policy:
            Log2.debug('Warning while checking resource access policy: policy is not configured')
            return response

        is_matched = {}
        # check if the given resource allows access
        # check force_allow section
        if self.__policy.get('force_allow'):
            Log2.debug('Processing resource access policy(force_allow)')
            is_matched['force_allow'] = self.check_policy(
                pi_policy=self.__policy.get('force_allow'),
                pi_resource_id=pi_resource_id,
                pi_tag=pi_tag
            )

        # if not in force_allow section(or force_allow is not defined ), check if it's in deny section
        if not is_matched.get('force_allow') and self.__policy.get('deny'):
            Log2.debug('Processing resource access policy(deny)')
            is_matched['deny'] = self.check_policy(
                pi_policy=self.__policy.get('deny'),
                pi_resource_id=pi_resource_id,
                pi_tag=pi_tag
            )

        # if not in force_allow section(or force_allow is ot defined ), and not in deny section(or deny section is not defined), check if it's allow section
        if not is_matched.get('force_allow') and not is_matched.get('deny') and self.__policy.get('allow'):
            Log2.debug('Processing resource access policy(allow)')
            is_matched['allow'] = self.check_policy(
                pi_policy=self.__policy.get('allow'),
                pi_resource_id=pi_resource_id,
                pi_tag=pi_tag
            )

        # resource is allowed to operate
        #   1. matches force_allow section configuration, or
        #   2. match allow section but neither force_allow section, nor deny section
        if is_matched.get('force_allow'):
            response = True
        elif is_matched.get('deny'):
            response = False
        elif is_matched.get('allow'):
            response = True

        return response

    def feed_resource_from_db(self, pi_session, pi_access_policy, pi_tool_name, pi_account_id, pi_action_permission=None, pi_resource_type=None):

        # duplicated policy for the following update
        final_access_policy = deepcopy(pi_access_policy)

        # if resource_source_table has been configured, load resources from table
        # please note resource_source_table value must be same through the policy
        is_matched = {}
        resource_source_table = ''
        for item in ['deny', 'allow', 'force_allow']:
            if item in final_access_policy and 'resource_source_table' in final_access_policy[item]:
                is_matched[item] = True
                resource_source_table = final_access_policy[item]['resource_source_table']

        if is_matched:
            # validate the arguments
            if not resource_source_table:
                raise Exception('Error while reading allow/deny resources from Dynamodb table: table name is not configured')

            if not pi_tool_name:
                raise Exception('Error while reading allow/deny resources from Dynamodb table: tool name is not configured')

            if not pi_account_id:
                raise Exception('Error while reading allow/deny resources from Dynamodb table: account id is not configured')

            # fetch allow/deny resources from dynamodb
            news_resource = NewsResourceAccessPermission(pi_session_ro=pi_session)
            matched_resource = news_resource.get_resource_id(
                pi_table_name=resource_source_table,
                pi_tool_name=pi_tool_name,
                pi_account_id=pi_account_id,
                pi_action_permission=pi_action_permission,
                pi_resource_type=pi_resource_type
            )

            # replace resource_source_table with resource list
            for item in ['deny', 'allow', 'force_allow']:
                if is_matched.get(item):
                    if item in ['force_allow', 'allow'] and matched_resource and matched_resource.get('allow'):
                        final_access_policy[item]['resource'] = matched_resource.get('allow')
                    elif item == 'deny' and matched_resource and matched_resource.get('deny'):
                        final_access_policy[item]['resource'] = matched_resource.get('deny')

                    # remove resource_source_table and resource_type after finding the corresponding resources
                    if 'resource_source_table' in final_access_policy[item]:
                        del final_access_policy[item]['resource_source_table']
                    if 'resource_type' in final_access_policy[item]:
                        del final_access_policy[item]['resource_type']

        return final_access_policy


class NewsSecurityGroupRuleCheckList:
    """
    NewsSecurityGroupRuleCheckList Class.

    Including functions for checking if SG protocol/port/ip range are in the block list.
    """

    def __init__(self, pi_raw_list=None, pi_session_ro=None, pi_session_rw=None, pi_session=None, pi_auto_cache=None, **kwargs):
        """
        Initalization.
        """
        self.__auto_cache = pi_auto_cache
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)
        self.__raw_list = pi_raw_list
        self.__check_list = None
        self.__check_list = self.bake_check_list(pi_raw_list=self.__raw_list)

    def set_policy(self, pi_raw_list):
        """
        Set the raw policy
        Convert it to the check list
        """
        self.__check_list = self.bake_check_list(pi_raw_list=pi_raw_list)

    def get_check_list(self):
        """
        Set the raw policy
        Convert it to the check list
        """
        return self.__check_list

    def bake_check_list(self, pi_raw_list):
        """
        Bake the check list.
        Basically, it break down the mapping of port range and ip range. In the end, it creates the pair of the single port range and single ip range
        Input:
            pi_raw_list: a dictionary like below
                [
                    {
                        'protocol': tcp|udp|icmp|-1         # one of protocl that SG supports, e.g. tcp, udp or icpm. If not configured, it means all protocol
                        'port_range': '22,500-600',      # support port, and port range
                        'ip_range': '10.0.0.1,1.1.1.1-2.2.2.2,192.168.0.1/24'  #support single ip, ip range or CIDR
                    },
                    ....
                ]
        Output:
            a dictionary, the baked result for the above input is like below
            [
                { 'protocl': 'tcp', 'from_port':22, 'to_port':22, 'from_ip':10.0.0.1, 'to_ip':10.0.0.1, 'raw_check_list' : { ... }},
                { 'protocl': 'tcp', 'from_port':22, 'to_port':22, 'from_ip':1.1.1.1, 'to_ip':2.2.2.2, 'raw_check_list' : { ... }},
                { 'protocl': 'tcp', 'from_port':22, 'to_port':22, 'from_ip':192.168.0.1 , 'to_ip':192.168.0.255, 'raw_check_list' : { ... } },
                { 'protocl': 'tcp', 'from_port':500, 'to_port':600, 'from_ip':10.0.0.1, 'to_ip':10.0.0.1, 'raw_check_list' : { ... } },
                { 'protocl': 'tcp', 'from_port':500, 'to_port':600, 'from_ip':1.1.1.1, 'to_ip':2.2.2.2, 'raw_check_list' : { ... }},
                { 'protocl': 'tcp', 'from_port':500, 'to_port':600, 'from_ip':192.168.0.1 , 'to_ip':192.168.0.255, 'raw_check_list' : { ... } },
            ]

        """
        raw_list = pi_raw_list
        baked_list = None

        # exit if the input check list is empty
        if not raw_list:
            return baked_list

        # Log2.debug('raw list:{}'.format(str(raw_list)))
        # loop through all the port/ip range definition
        for list_item in raw_list:

            item = ''
            if isinstance(list_item, dict):
                item = list_item
            else:
                item = json.loads(list_item)

            # retreive protocol
            if 'protocol' in item:
                protocol = item.get('protocol')
            else:
                protocol = '-1'

            # bake ip range to a list of first/last ip pair
            baked_ip_ranges = []
            if 'ip_range' in item:
                ip_ranges = item['ip_range'].split(',')
                # extract the first ip and last ip from a range, CIDR or a single ip
                for range_item in ip_ranges:
                    from_ip = None
                    to_ip = None
                    # CIDR, e.g. 10.0.0.0/24
                    if range_item.find('/') > 0:
                        from_ip, to_ip = CommFunc.parse_cidr(range_item)
                    # ip range, e.g. CIDR, e.g. 1.1.1.1-2.2.2.2
                    elif range_item.find('-') > 0:
                        from_ip, to_ip = CommFunc.parse_ip_range(range_item)
                    # single ip address, 3.3.3.3
                    elif CommFunc.is_valid_ip(range_item):
                        from_ip = to_ip = range_item

                    # Log2.debug('ip: {} -> {}/{}'.format(str(range_item), str(from_ip), str(to_ip)))

                    # store the baked ip range
                    if from_ip and to_ip:
                        baked_ip_ranges.append({'from_ip': str(from_ip).strip(), 'to_ip': str(to_ip).strip()})
                    else:
                        Log2.debug('Error while parsing ip range {}, please make sure it is the valid ip range in the table.'.format(range_item))
                        # raise ValueError('Error while parsing ip range {}, please make sure it is the valid ip range in the table.'.format(range_item))
            # else:
            #   baked_ip_ranges.append({'from_ip': '0.0.0.0', 'to_ip': '255.255.255.255'})

            # bake port range to a list of first/last ip port
            baked_port_ranges = []
            if 'port_range' in item:
                port_ranges = item['port_range'].split(',')

                # extract the first port and last port from a range or single port
                for range_item in port_ranges:
                    from_port = None
                    to_port = None
                    # port range, e.g. 1-10
                    if range_item.find('-') > 0:
                        port_pair = range_item.split('-')
                        from_port = port_pair[0]
                        to_port = port_pair[-1]
                    # single port, e.g. 10
                    else:
                        from_port = to_port = range_item

                    # Log2.debug('port: {} -> {}/{}'.format(str(range_item), str(from_port), str(to_port)))

                    # store the baked port range
                    if from_port and to_port:
                        baked_port_ranges.append({'from_port': int(from_port), 'to_port': int(to_port)})
                    else:
                        Log2.debug('Error while parsing port range {}, please make sure it is the valid port range in the table.'.format(range_item))
                        # raise ValueError('Error while parsing port range {}, please make sure it is the valid port range in the table'.format(range_item))
            # else:
            #    baked_port_ranges.append({'from_port': 0, 'to_port': 255})

            # break down combination of multiple port ranges to mutliple ip ranges,  and convert it to 1 port range to 1 ip range
            for port_item in baked_port_ranges:
                for ip_item in baked_ip_ranges:

                    rule = {
                        'protocol': protocol,
                        'from_port': port_item.get('from_port'),
                        'to_port': port_item.get('to_port'),
                        'from_ip': ip_item.get('from_ip'),
                        'to_ip': ip_item.get('to_ip'),
                        'raw_check_list': item
                    }

                    # add baked port/ip pair into the array
                    if not baked_list:
                        baked_list = []
                    baked_list.append(rule)

        # Log2.debug('Bake is done:' + str(baked_list))
        return baked_list

    def compare_protocol(self, pi_sg_protocol='-1', pi_check_list_protocol='-1'):
        """
        Compare SG rule's protocol with the one in a single check list rule
        Output:
            0: no overlap between sg rule and check list item
            1: sg rule equal to check list item
            2: sg rule is samller/less than check list item
            3: sg rule is larger than check list item
            4: all other cases
        """
        protocol_match = 0
        if pi_sg_protocol == pi_check_list_protocol:
            protocol_match = 1
        elif pi_check_list_protocol == '-1':
            protocol_match = 2
        elif pi_sg_protocol == '-1':
            protocol_match = 3
        else:
            protocol_match = 0

        # Log2.debug('SG vs check list(protocol): {} vs {} =  {}'.format(pi_sg_protocol, pi_check_list_protocol, str(protocol_match)))

        return protocol_match

    def compare_port(self, pi_sg_from_port=0, pi_sg_to_port=65535, pi_check_list_from_port=0, pi_check_list_to_port=65535):
        """
        Compare SG rule's port range with the one in a single check list rule
        Output:
            0: no overlap between sg rule and check list item
            1: sg rule equal to check list item
            2: sg rule is samller/less than check list item
            3: sg rule is larger than check list item,
            4: all other cases
        """
        port_match = 0
        if pi_check_list_from_port > pi_sg_to_port or pi_check_list_to_port < pi_sg_from_port:
            port_match = 0
        elif pi_check_list_from_port == pi_sg_from_port and pi_check_list_to_port == pi_sg_to_port:
            port_match = 1
        elif pi_check_list_from_port <= pi_sg_from_port and pi_check_list_to_port >= pi_sg_to_port:
            port_match = 2
        elif pi_check_list_from_port >= pi_sg_from_port and pi_check_list_to_port <= pi_sg_to_port:
            port_match = 3
        else:
            port_match = 4

        # Log2.debug('SG vs check list(port): {}-{} vs {}-{} = {}'.format(str(pi_sg_from_port), str(pi_sg_to_port), str(pi_check_list_from_port), str(pi_check_list_to_port), str(port_match)))

        return port_match

    def compare_ip(self, pi_sg_from_ip='0.0.0.0', pi_sg_to_ip='255.255.255.255', pi_check_list_from_ip='0.0.0.0', pi_check_list_to_ip='255.255.255.255'):
        """
        Compare SG urle's ip rang with the one in check list
        Output:
            0: no overlap between sg rule and check list item
            1: sg rule equal to check list item
            2: sg rule is samller/less than check list item
            3: sg rule is larger than check list item,
            4: all other cases
        """
        ip_match = 0
        if CommFunc.compare_ip_address(pi_check_list_from_ip, pi_sg_to_ip) > 0 or CommFunc.compare_ip_address(pi_check_list_to_ip, pi_sg_from_ip) < 0:
            ip_match = 0
        elif CommFunc.compare_ip_address(pi_check_list_from_ip, pi_sg_from_ip) == 0 and CommFunc.compare_ip_address(pi_check_list_to_ip, pi_sg_to_ip) == 0:
            ip_match = 1
        elif CommFunc.compare_ip_address(pi_check_list_from_ip, pi_sg_from_ip) <= 0 and CommFunc.compare_ip_address(pi_check_list_to_ip, pi_sg_to_ip) >= 0:
            ip_match = 2
        elif CommFunc.compare_ip_address(pi_check_list_from_ip, pi_sg_from_ip) >= 0 and CommFunc.compare_ip_address(pi_check_list_to_ip, pi_sg_to_ip) <= 0:
            ip_match = 3
        else:
            ip_match = 4

        # Log2.debug('SG vs check list(ip): {}-{} vs {}-{} = {}'.format(str(pi_sg_from_ip), str(pi_sg_to_ip), str(pi_check_list_from_ip), str(pi_check_list_to_ip), str(ip_match)))

        return ip_match

    # def match_ingress_rule(self, pi_sg_ingress_rule, pi_match_criteria):
    def match_ingress_rule(self, pi_sg_ingress_rule):
        """
        Compare one single SG ingress rule with the pre-defined blocked rule
        Input:
            pi_sg_ingress_rule: a dictionary like below, it can found in  SecurityGroups[*]['IpPermissions'] of the output of the describe-security-groups
                {
                    "PrefixListIds": [],
                    "FromPort": 22,
                    "IpRanges": [
                        {
                            "CidrIp": "172.0.0.0/32"
                        }
                    ],
                    "ToPort": 22,
                    "IpProtocol": "tcp",
                    "UserIdGroupPairs": [],
                    "Ipv6Ranges": []
                }
        Output:
            a dictionary, e.g
            {
                'result': x
                'protocol_match': y,
                'port_match': z,
                'ip_match': m,
                'matched_check_list':
                    { 'protocl': 'tcp', 'from_port':22, 'to_port':22, 'from_ip':10.0.0.1, 'to_ip':10.0.0.1 },
            }
            x, y, z, m can be any one of the following value
                0: dismatch - no overlap in one or more of protocol, port or ip
                1: exact match - sg rule equal to check list item
                2: particlly match(included) - sg rule is samller/less than check list item
                3: particlly match(contain) - sg rule is larger than check list item,
                4: all other cases
        """

        response = {
            # 'matched': False
            'result': 0,
            'protocol_match': 0,
            'port_match': 0,
            'ip_match': 0,
            'matched_check_list': {},
            'matched_check_list_break_down': {}
        }

        if not self.__check_list:
            Log2.debug('Warning while comparing SG ingress rule with check list: blank check list')
            # raise ValueError('Error while comparing SG ingress rule with check list: blank check list')
            return response

        if not pi_sg_ingress_rule:
            Log2.debug('Error while comparing SG ingress rule with check list: blank SG ingress rule')
            # raise ValueError('Error while comparing SG ingress rule with check list: blank SG ingress rule')
            return response

        # validate the ingress
        if not pi_sg_ingress_rule.get('IpProtocol'):
            Log2.debug('Warning while parsing SG ingress rule: invalid ingress rule {}'.format(pi_sg_ingress_rule))
            return response

        # only check the rule which has specified configured IP or CIDR as the source, skip those use SG as the source
        if not pi_sg_ingress_rule.get('IpRanges'):
            Log2.debug('Warning while parsing SG ingress rule: no "IpRange" field {}, skip it'.format(pi_sg_ingress_rule))
            return response
        elif len(pi_sg_ingress_rule['IpRanges']) > 1:
            Log2.debug('Error while parsing SG ingress rule: "IpRanges" {} has more than 1 items, skip it'.format(str(pi_sg_ingress_rule['IpRanges'])))
            return response

        # parse CIDR and compare the SG rule with pre-defined check list
        ip_range = pi_sg_ingress_rule['IpRanges'][0]
        if not ip_range.get('CidrIp'):
            Log2.debug('Error while comparing SG ingress rule with check list: invalid CIDR {}'.format(ip_range.get('CidrIp')))
            return response

        # parse the first and last ip from CIDR
        from_ip, to_ip = CommFunc.parse_cidr(pi_cidr_str=ip_range.get('CidrIp'))
        if not from_ip or not to_ip:
            Log2.debug('Error while comparing SG ingress rule with check list: fail to parse CIDR {}'.format(ip_range.get('CidrIp')))
            return response

        previous_match_result = {}
        # match each single check list item
        for check_list_item in self.__check_list:

            # compare match criteria
            protocol_match = self.compare_protocol(
                pi_sg_protocol=pi_sg_ingress_rule.get('IpProtocol', '-1'),
                pi_check_list_protocol=check_list_item.get('protocol', '-1')
            )

            # compare port
            if 'FromPort' in pi_sg_ingress_rule:
                sg_from_port = int(pi_sg_ingress_rule['FromPort'])
            else:
                sg_from_port = 0

            if 'ToPort' in pi_sg_ingress_rule:
                sg_to_port = int(pi_sg_ingress_rule['ToPort'])
            else:
                sg_to_port = 65535

            if 'from_port' in check_list_item:
                check_list_from_port = int(check_list_item['from_port'])
            else:
                check_list_from_port = 0

            if 'to_port' in check_list_item:
                check_list_to_port = int(check_list_item['to_port'])
            else:
                check_list_to_port = 65535

            port_match = self.compare_port(
                pi_sg_from_port=sg_from_port,
                pi_sg_to_port=sg_to_port,
                pi_check_list_from_port=check_list_from_port,
                pi_check_list_to_port=check_list_to_port
            )

            # compare ip
            ip_match = self.compare_ip(
                pi_sg_from_ip=from_ip,
                pi_sg_to_ip=to_ip,
                pi_check_list_from_ip=check_list_item.get('from_ip', '0.0.0.0'), pi_check_list_to_ip=check_list_item.get('to_ip', '255.255.255.255')
            )
            # SG rule has one or more field which has no overlap at all, it means SG rule and check list item refer to the completely different ingress rule
            if protocol_match == 0 or port_match == 0 or ip_match == 0:
                # continue the loop to check if there is any other exact matched item
                continue
            elif protocol_match in [1, 2] and port_match in [1, 2] and ip_match in [1, 2]:
                # SG rule equqals to a check list item in all protocol, por and ip
                if protocol_match == 1 and port_match == 1 and ip_match == 1:
                    match_result = 1
                # SG rule is part of a check list item in protocol, port and ip
                else:
                    match_result = 2

                response = {
                    'result': match_result,
                    'protocol_match': protocol_match,
                    'port_match': port_match,
                    'ip_match': ip_match,
                    'matched_check_list': check_list_item.get('raw_check_list')
                }
                matched_check_list_break_down = deepcopy(check_list_item)
                if 'raw_check_list' in matched_check_list_break_down:
                    del matched_check_list_break_down['raw_check_list']
                response['matched_check_list_break_down'] = matched_check_list_break_down
                # Log2.debug('Match result:{}'.format(str(response)))
                return response
            else:

                # SG rule completely contains a check list item in protocol, port and ip
                if protocol_match in [1, 3] and port_match in [1, 3] and ip_match in [1, 3]:
                    match_result = 3
                # all other scenarios, including SG rule completely larger/smaller than check list item, or there is overlap
                else:
                    match_result = 4

                previous_match_result = {
                    'result': match_result,
                    'protocol_match': protocol_match,
                    'port_match': port_match,
                    'ip_match': ip_match,
                    'matched_check_list': check_list_item.get('raw_check_list')
                }
                matched_check_list_break_down = deepcopy(check_list_item)
                if 'raw_check_list' in matched_check_list_break_down:
                    del matched_check_list_break_down['raw_check_list']
                previous_match_result['matched_check_list_break_down'] = matched_check_list_break_down
                continue

        # if still not matched in the end, use the previous match result in the history that SG rule overlaps or contains a check list item
        if previous_match_result:
            response = previous_match_result

        # Log2.debug('Match result:{}'.format(str(response)))
        return response
