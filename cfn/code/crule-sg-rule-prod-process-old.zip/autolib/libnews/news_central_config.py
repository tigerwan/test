"""
Module: news_central_cnofig
Create Date: 2018-07-31
Function: Implement news organization module.
"""
import json
# from copy import deepcopy
from autolib.libcomm.log2 import Log2
# from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI
from autolib.libnews.news_org import NewsOrg
from autolib.libnews.news_tool_config import NewsToolConfig
from autolib.libnews.news_policy import NewsAccountAccessPolicy
from autolib.libnews.news_policy import NewsResourceAccessPolicy


class NewsCentralConfig:
    """
    NewsCentralConfig Class.

    Including functions of fetching all configuration from Shared Account.
    """

    def __init__(self, pi_account_table, pi_tool_config_table, pi_resource_access_table, pi_tool_name, pi_account_id, pi_resource_type=None, pi_session_ro=None, pi_session_rw=None, pi_session=None, pi_auto_cache=None, **kwargs):
        """
        Initalization.
        """
        self.__auto_cache = pi_auto_cache
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)

        self.__account_table = pi_account_table
        self.__tool_config_table = pi_tool_config_table
        self.__resource_access_table = pi_resource_access_table

        self.__tool_name = pi_tool_name
        self.__account_id = pi_account_id
        self.__account_resource = pi_resource_type

        self.__account_env = None
        self.__account_name = None

        self.__account_access = False
        self.__account_remediation = False

        self.__news_org = NewsOrg(session_ro=self.__session_ro, session_rw=self.__session_rw)
        self.__news_tool_config = NewsToolConfig(pi_session_ro=self.__session_ro, pi_session_rw=self.__session_rw)

        self.__news_account_policy = NewsAccountAccessPolicy(pi_session_ro=self.__session_ro, pi_session_rw=self.__session_rw)
        self.__news_resource_policy = NewsResourceAccessPolicy(pi_session_ro=self.__session_ro, pi_session_rw=self.__session_rw)

    def get_config(self, pi_account_policy_config_name='account_remediation_policy', pi_resource_policy_config_name='resource_remediation_policy'):
        """
        Retrive all centrally stored configuration
        Input:
            pi_account_policy_config_name:  key of account access policy in dynamodb
            pi_resource_policy_config_name: key of resource access policy in dynamodb
        """
        # retrieve account details
        if not self.__account_id:
            raise Exception('Error while reading account table: invalid id')
        if not self.__account_table:
            raise Exception('Error while reading account table: invalid table name')

        Log2.debug('Retrive account details')
        self.__news_org.get_account_byid(
            pi_table_name=self.__account_table,
            pi_account_id=self.__account_id
        )

        # retrieve tool configuration
        if not self.__tool_name:
            raise Exception('Error while reading tool configuration table: Invalid tool name')
        if not self.__tool_config_table:
            raise Exception('Error while reading tool configuration table: invalid table name')

        Log2.debug('Retrive tool configuration details')
        self.__news_tool_config.get_config(
            pi_table_name=self.__tool_config_table,
            pi_tool_name=self.__tool_name
        )

        # retrive account access policy for the further account access/remediation premission checking
        if pi_account_policy_config_name:
            Log2.debug('Retrive account access policy')
            account_policy = self.__news_tool_config.get_config_bykey(
                pi_key=pi_account_policy_config_name,
                pi_tool_name=self.__tool_name,
                pi_table_name=self.__tool_config_table
            )

            if account_policy:
                Log2.debug('Bake account access policy')
                # store retrieved policy
                self.__news_account_policy.set_policy(pi_raw_policy=json.loads(account_policy))
                # Log2.debug('Account access policy:'+str(self.__news_account_policy.get_policy()))
            else:
                Log2.debug('The tool of {} has no account access policy in the table'.format(self.__tool_name))
        else:
            Log2.debug('Error while reading tool configuration table: invalid account access policy name')

        # retrive resource access policy for the further resource remediation permission checking
        if pi_resource_policy_config_name:
            Log2.debug('Retrive resource access policy')
            resource_policy = self.__news_tool_config.get_config_bykey(
                pi_key=pi_resource_policy_config_name,
                pi_tool_name=self.__tool_name,
                pi_table_name=self.__tool_config_table
            )

            if resource_policy:
                Log2.debug('Bake resource access policy')
                self.__news_resource_policy.set_policy(
                    pi_raw_policy=json.loads(resource_policy),
                    pi_tool_name=self.__tool_name,
                    pi_account_id=self.__account_id,
                )

                # Log2.debug('Resource access policy:'+str(self.__news_resource_policy.get_policy()))
            else:
                Log2.debug('The tool of {} has no resource access policy in the table'.format(self.__tool_name))
        else:
            Log2.debug('Error while reading tool configuration table: invalid resource access policy name')

        Log2.debug('Rretrieve the access to the account')
        # check if the account allow the tool to access and process remmediation based on the policy fetched above
        self.check_account_access_permission()

    def get_tool_config_bykey(self, pi_key):
        """
        Fetch a tool configuration by key
        """
        return self.__news_tool_config.get_config_bykey(pi_key=pi_key)

    def get_account_property(self, pi_property_name):
        """
        Fetch a account property,e.g. accountName, environment
        Input:
            pi_property_name:   a account property in the dyanmodb,e.g. accountName, environment
        Return:
            account property value
        """
        return self.__news_org.get_account_property(
            pi_account_id=self.__account_id,
            pi_property_name=pi_property_name,
            pi_table_name=self.__account_table
        )

    def get_account_env(self):
        """
        Fetch account enviroment value
        """
        if not self.__account_env:
            self.__account_env = self.get_account_property(
                pi_property_name='environment'
            )
        return self.__account_env

    def get_account_name(self):
        """
        Fetch account name value
        """
        if not self.__account_name:
            self.__account_name = self.get_account_property(
                pi_property_name='accountName'
            )
        return self.__account_name

    def check_account_access_permission(self):
        """
        Check if account allows the tool access/remediate
        Return:
            a dictionary, e.g.
                {
                    "allow_access": True  #True means the tool is permitted to check the account, False means No
                    "allow_remediation": True #True means the tool is permitted to remmediate on the account, False means No

                }
        """
        account_env = self.get_account_env()

        managed_account = self.get_account_property(pi_property_name='managed')
        account_allow_remediation = self.get_account_property(pi_property_name='allowRemediation')

        # fetch account level access/remediation permission
        result = self.__news_account_policy.check_allow_permission(
            pi_account_id=self.__account_id,
            pi_account_env=account_env,
            pi_managed_account=managed_account,
            pi_allow_remediation=account_allow_remediation
        )

        if result:
            self.__account_access = result.get('allow_access')
            self.__account_remediation = result.get('allow_remediation')
            Log2.debug('Account access permission for {}:{}'.format(self.__tool_name, str(result)))
        else:
            Log2.debug('No account access permission for {}'.format(self.__tool_name))

    def is_account_access_allowed(self):
        """
        Check if account allows the tool access
        Return:
            True means the tool is permitted to check the account, False means No
        """
        return self.__account_access

    def is_account_remediation_allowed(self):
        """
        Check if account allows the tool process remediate
        Return:
            True means the tool is permitted to remmediate on the account, False means No
        """
        return self.__account_remediation

    def is_resource_remediation_allowed(self, pi_resource_id, pi_tag=None):
        """
        Check if the resource allows the tool process remediate
        Return:
            True means the tool is permitted to remmediate on the given resource, False means No
        """
        return self.__news_resource_policy.check_allow_permission(
            pi_resource_id=pi_resource_id,
            pi_tag=pi_tag
        )
