"""
Module: news_configrule
Create Date: 2018-07-31
Function: Implement news organization module.
"""

import json
import datetime

from autolib.libcomm.log2 import Log2
# from copy import deepcopy
# from autolib.libaws.aws_dynamodb import AwsDynamodbI
from autolib.libaws.aws_session import AwsSessionI


class NewsConfigRule:
    """
    NewsConfigRule Class.

    Including functions about Config Rule Lambda
    """

    def __init__(self, pi_event, pi_context, pi_session_ro=None, pi_session_rw=None, pi_session=None, pi_auto_cache=None, **kwargs):
        """
        Initalization.
        """
        self.__auto_cache = pi_auto_cache
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)
        self.__session = self.__session_ro
        self.__config_rule = self.__session.client('config')
        self.__event = pi_event
        self.__context = pi_context
        self.__invoking_event = None
        self.__message_type = None
        self.__rule_parameters = None
        self.__configuration_item = None
        self.__configuration_item_diff = None
        self.__result_token = None
        self.__account_id = None

        self.parse_event()

    def get_event(self):
        return self.__event

    def get_context(self):
        return self.__context

    def get_invoking_event(self):
        return self.__invoking_event

    def get_message_type(self):
        return self.__message_type

    def get_rule_parameters(self):
        return self.__rule_parameters

    def get_configuration_item(self):
        return self.__configuration_item

    def get_configuration_item_diff(self):
        return self.__configuration_item_diff

    def get_result_token(self):
        return self.__result_token

    def get_configuration_item_diff_member(self, pi_key):
        if self.__configuration_item_diff and pi_key and pi_key in self.__configuration_item_diff:
            return self.__configuration_item_diff[pi_key]
        return None

    def get_change_type(self):
        return self.get_configuration_item_diff_member(pi_key='changeType')

    def is_deletion_event(self):
        if self.get_change_type() == 'DELETE':
            return True
        return False

    def get_configuration_item_member(self, pi_key):
        if self.__configuration_item and pi_key and pi_key in self.__configuration_item:
            return self.__configuration_item[pi_key]
        return None

    def get_resource_id(self):
        return self.get_configuration_item_member(pi_key='resourceId')

    def get_resource_type(self):
        return self.get_configuration_item_member(pi_key='resourceType')

    def get_account_id(self):
        return self.__account_id

    def raise_error(self, pi_error):
        if pi_error:
            Log2.debug(pi_error)
            raise Exception(pi_error)

    def parse_event(self):

        # validate event
        if self.__event:
            event = self.__event

            # retrive accountId
            if 'accountId' in event:
                self.__account_id = event['accountId']
            else:
                self.raise_error('Invalid input: not account id in event')

            # retrive resultToken
            if 'resultToken' in event:
                self.__result_token = event['resultToken']
            else:
                self.raise_error('Invalid input: not resultToken in event')

            # retrieve ruleParameters
            if 'ruleParameters' in event:
                self.__rule_parameters = json.loads(event['ruleParameters'])

            # retrieve invokingEvent
            if 'invokingEvent' in event:
                self.__invoking_event = json.loads(event['invokingEvent'])
                invoking_event = self.__invoking_event

                # retrieve messageType
                if 'messageType' in invoking_event:
                    self.__message_type = invoking_event['messageType']

                    # validate messageType
                    if self.__message_type not in ['ScheduledNotification', 'ConfigurationItemChangeNotification', 'OversizedConfigurationItemChangeNotification']:
                        self.raise_error('Unexpected message type: {}'.format(self.__message_type))

                else:
                    self.raise_error('Invalid input:invokingEvent does not contain messageType')

                # retrieve configurationItem
                self.__configuration_item = self.get_configuration_item_from_event(invoking_event)

                # retrieve configurationItemDiff
                if 'configurationItemDiff' in invoking_event:
                    self.__configuration_item_diff = invoking_event['configurationItemDiff']

            else:
                self.raise_error('Invalid input: event does not contain invokingEvent')

        else:
            self.raise_error('Invalid input: the input does not contain event')

    def is_oversized_changed_notification(self):
        """Check whether the message is OversizedConfigurationItemChangeNotification or not."""
        return self.__message_type == 'OversizedConfigurationItemChangeNotification'

    def is_scheduled_notification(self):
        """Check whether the message is a ScheduledNotification or not."""
        return self.__message_type == 'ScheduledNotification'

    def get_configuration(self, pi_resource_type, pi_resource_id, pi_configuration_capture_time):
        """Get configurationItem using getResourceConfigHistory API"""
        """in case of OversizedConfigurationItemChangeNotification"""
        result = self.__config_rule.get_resource_config_history(
            resourceType=pi_resource_type,
            resourceId=pi_resource_id,
            laterTime=pi_configuration_capture_time,
            limit=1)
        configurationItem = result['configurationItems'][0]
        return self.convert_api_configuration(configurationItem)

    def convert_api_configuration(self, pi_configurationItem):
        """Convert from the API model to the original invocation model"""
        configurationItem = {}
        for k, v in pi_configurationItem.items():
            if isinstance(v, datetime.datetime):
                configurationItem[k] = str(v)
        configurationItem['awsAccountId'] = pi_configurationItem['accountId']
        configurationItem['ARN'] = pi_configurationItem['arn']
        configurationItem['configurationStateMd5Hash'] = pi_configurationItem['configurationItemMD5Hash']
        configurationItem['configurationItemVersion'] = pi_configurationItem['version']
        configurationItem['configuration'] = json.loads(pi_configurationItem['configuration'])
        if 'relationships' in pi_configurationItem:
            for i in range(len(pi_configurationItem['relationships'])):
                configurationItem['relationships'][i]['name'] = pi_configurationItem['relationships'][i]['relationshipName']
        return configurationItem

    def get_configuration_item_from_event(self, pi_invoking_event):
        """
        Based on the type of message get the configuration item
        either from configurationItem in the invoking event
        or using the getResourceConfigHistiry API in getConfiguration function.
        """
        if self.is_oversized_changed_notification():
            if 'configurationItemSummary' not in pi_invoking_event:
                return None
            configurationItemSummary = pi_invoking_event['configurationItemSummary']
            return self.get_configuration(
                configurationItemSummary['resourceType'],
                configurationItemSummary['resourceId'],
                configurationItemSummary['configurationItemCaptureTime']
            )
        elif self.is_scheduled_notification():
            return None
        elif 'configurationItem' in pi_invoking_event:
            return pi_invoking_event['configurationItem']

        return None

    def build_evaluation(self, pi_resource_type, pi_resource_id, pi_time_stamp, pi_compliance_type, pi_annotation=None):
        """Form an evaluation as a dictionary. Usually suited to report on configuration change rules.

        Keyword arguments:
        configuration_item -- the configurationItem dictionary in the invokingEvent
        compliance_type -- either COMPLIANT, NON_COMPLIANT or NOT_APPLICABLE
        annotation -- an annotation to be added to the evaluation (default None)
        """
        eval_ci = {}
        if pi_annotation:
            eval_ci['Annotation'] = pi_annotation
        eval_ci['ComplianceResourceType'] = pi_resource_type
        eval_ci['ComplianceResourceId'] = pi_resource_id
        eval_ci['ComplianceType'] = pi_compliance_type
        eval_ci['OrderingTimestamp'] = pi_time_stamp
        return eval_ci

    def put_evaluation(self, pi_compliance_results):
        """
        Update Config Rule evaluation result
        """
        evaluations = []

        # loop compliance reuslt list
        for compliance_result in pi_compliance_results:
            if 'type' in compliance_result and compliance_result['type'] in ['NON_COMPLIANT', 'NOT_APPLICABLE', 'COMPLIANT']:
                # get time stamp
                if self.__configuration_item:
                    compliance_result['time_stamp'] = self.__configuration_item['configurationItemCaptureTime']
                else:
                    compliance_result['time_stamp'] = self.__invoking_event['notificationCreationTime']

                # generate teh evaluation result
                if compliance_result['resource_type'] and compliance_result['resource_id'] and compliance_result['type']:
                    evaluation = self.build_evaluation(
                        pi_resource_type=compliance_result['resource_type'],
                        pi_resource_id=compliance_result['resource_id'],
                        pi_time_stamp=compliance_result['time_stamp'],
                        pi_compliance_type=compliance_result['type'],
                        pi_annotation=None
                    )
                    evaluations.append(evaluation)

                if len(evaluations) >= 90:

                    # Put together the request that reports the evaluation status
                    test_mode = False
                    if self.__result_token == 'TESTMODE':
                        # Used solely for RDK test to skip actual put_evaluation API call
                        test_mode = True

                    # Invoke the Config API to report the result of the evaluation
                    Log2.debug('Update Config rule evaluation state')

                    self.__config_rule.put_evaluations(
                        Evaluations=evaluations,
                        ResultToken=self.__result_token,
                        TestMode=test_mode
                    )

                    evaluations = []

        if evaluations:

            # Put together the request that reports the evaluation status
            test_mode = False
            if self.__result_token == 'TESTMODE':
                # Used solely for RDK test to skip actual put_evaluation API call
                test_mode = True

            # Invoke the Config API to report the result of the evaluation
            Log2.debug('Update Config rule evaluation state')

            self.__config_rule.put_evaluations(
                Evaluations=evaluations,
                ResultToken=self.__result_token,
                TestMode=test_mode
            )
