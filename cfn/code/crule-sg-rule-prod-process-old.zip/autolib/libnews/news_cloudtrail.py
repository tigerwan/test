"""
Module: news_cloudtrail
Create Date: 2018-07-31
Function: Implement news exclude list module.
"""

# from autolib.libcomm.log2 import Log2
from copy import deepcopy
from autolib.libaws.aws_cloudtrail import AwsCloudtrailI
from autolib.libaws.aws_session import AwsSessionI


class NewsCloudTrail:
    """
    NewsCloudTrail Class.

    Including functions in organization management level.
    """

    def __init__(self, pi_session_ro=None, pi_session_rw=None, pi_session=None, **kwargs):
        """Initalization."""
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)
        self.__trail = None
        self.__trail_status = None

    def describe_trail(self, pi_trail_name):
        """Describe a trail configuration."""

        cloud_trail = AwsCloudtrailI(session_ro=self.__session_ro)
        result = cloud_trail.describe_trails(trailNameList=[pi_trail_name])
        if result['trailList']:
            response = result['trailList'][0]
        else:
            response = {}

        return response

    def lazy_describe_trail(self, pi_trail_name):
        """Describe a trail configuration."""

        if self.__trail is None:
            self.__trail = self.describe_trail(pi_trail_name=pi_trail_name)

        return deepcopy(self.__trail)

    def set_session(self, pi_session_ro=None, pi_session_rw=None):
        if pi_session_ro:
            self.__session_ro = pi_session_ro

        if pi_session_rw:
            self.__session_rw = pi_session_rw

    def create_trail(self, **kwargs):
        """Create a trail."""

        cloud_trail = AwsCloudtrailI(session_rw=self.__session_rw)
        response = cloud_trail.create_trail(**kwargs)
        return response

    def update_trail(self, **kwargs):
        """Udate a trail"""

        cloud_trail = AwsCloudtrailI(session_rw=self.__session_rw)
        response = cloud_trail.update_trail(**kwargs)
        return response

    def start_logging(self, pi_trail_name):
        """Start logging."""

        cloud_trail = AwsCloudtrailI(session_rw=self.__session_rw)
        response = cloud_trail.start_logging(Name=pi_trail_name)
        return response

    def get_trail_status(self, pi_trail_name):
        """
        Get logging status
        """
        cloud_trail = AwsCloudtrailI(session_ro=self.__session_ro)
        response = cloud_trail.get_trail_status(Name=pi_trail_name)
        return response

    def lazy_get_trail_status(self, pi_trail_name):
        """
        Get logging status
        """
        if self.__trail_status is None:
            self.__trail_status = self.get_trail_status(pi_trail_name=pi_trail_name)
        return self.__trail_status

    def is_trail_enabled(self, pi_trail_name):
        """
        Get logging status
        """
        response = self.lazy_get_trail_status(pi_trail_name=pi_trail_name)
        return response.get('IsLogging')

    def diff_to_target(self, target_state):
        """
        Return didfference between current trail settings to target settings.

        Input:
            target_state: a dictionary looks like below
            {
                S3BucketName': 'ops-prod-logging-1',
                'S3KeyPrefix': 'cloudtrail',
                'SnsTopicName': 'arn:aws:sns:ap-southeast-2:account_id:cloudtrial-stackdriver-logging',
                'IncludeGlobalServiceEvents': True,
                'IsMultiRegionTrail': True,
                'EnableLogFileValidation': True,
                'CloudWatchLogsLogGroupArn': 'arn:aws:logs:ap-southeast-2:account_id:log-group:CloudTrail/DefaultLogGroup:*',
                'CloudWatchLogsRoleArn':'arn:aws:iam::account_id:role/CloudTrail_CloudWatchLogs_Role',
                'KmsKeyId': 'arn:aws:kms:ap-southeast-2:account_id:key/1234567'
            }

            note: all keys used in target state dictionary are ones used by boto3 create_trail()
        Retrun:
            the difference between trail target settings and real settings.
            After adding 'Name' attribute, it can be uesd to as parameters
            of create_trail() and update_trail()
            it may looks like
            {
                S3BucketName': 'ops-prod-logging-1',
                'S3KeyPrefix': 'cloudtrail'
            }
        """
        state_gap = {}

        # loop all keys in target state dictionary

        for key in target_state.keys():

            if key == 'EnableLogFileValidation':
                trail_key = 'LogFileValidationEnabled'
            else:
                trail_key = key

            # if there is difference, use settings in dynamodb
            if target_state[key] != self.__trail.get(trail_key):
                state_gap[key] = target_state[key]
        return state_gap
