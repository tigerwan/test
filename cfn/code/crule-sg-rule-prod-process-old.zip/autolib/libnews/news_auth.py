"""
Module of News Authentication

To realize check and get authentication easier

                ---------
                NewsAuth
                ---------
                    |
            ----------------
            |               |
       -----------      -----------
        NewsSentry      NewsRole
       -----------      -----------

"""
from copy import deepcopy
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI
from autolib.libnews.news_role import NewsRole


class NewsAuth():
    """
    """
    def __init__(self):
        """
        """
        #self.__session = self.init_session(*args, **kwargs)
        pass

    def _init_session_v0(self, **kwargs):
        """
        AWS defauLt session Mode
        """
        session = AwsSessionI.c_session(**kwargs)
        return (session, session)

                    
    def _init_session_v1(self, **kwargs):
        """
        Init session based on input credentials.

        Credentials from input parameters:
        :aws_access_key_id: 
        :aws_secret_access_key:
        :aws_session_token:
        :region_name:
        """
        session = AwsSessionI.c_session(aws_access_key_id=kwargs["aws_access_key_id"],
                                        aws_secret_access_key=kwargs['aws_secret_access_key'],
                                        aws_session_token=kwargs['aws_session_token'],
                                        region_name=kwargs['region_name'])
        return (session,session)


    def _init_session_v2(self, **kwargs):
        """
        Init session based on input config: credentials_config (dict type)

        :credentials_config:
            {
                "aws_access_key_id":"",
                "aws_secret_access_key":"",
                "aws_session_token":"",
                "region_name":"ap-southeast-2"
            }
        """

        ci_credentials = kwargs.get('credentials_config')
        # print("ci_credentials= {}".format(ci_credentials))
        # print("ci_credentials_key_id= {}".format(ci_credentials.get("aws_access_key_id")))

        session = AwsSessionI.c_session(aws_access_key_id=ci_credentials.get("aws_access_key_id"),
                                        aws_secret_access_key=ci_credentials.get('aws_secret_access_key'),
                                        aws_session_token=ci_credentials('aws_session_token'),
                                        region_name=ci_credentials.get('region_name'))
        return (session,session)


    def _init_session_v3(self):
        """
        Initial Session based on Local Environment Variables (Current Session)
        """
        session = AwsSessionI.c_session(aws_access_key_id=CommFunc.get_session_env("aws_access_key_id"),
                                        aws_secret_access_key=CommFunc.get_session_env('aws_secret_access_key'),
                                        aws_session_token=CommFunc.get_session_env('aws_session_token'),
                                        region_name=CommFunc.get_session_env('region_name'))
        return (session,session)

    def _init_session_v4(self, **kwargs):
        """
        Initial Session based on current auto hold session. (like running as Lambda)

        :region_name: 
        """
        session = AwsSessionI.c_session(region_name=kwargs.get('region_name'))
        return (session,session)

    def _init_session_v10(self, **kwargs):
        """
        :session_ro:  
        :session_rw:
        or
        :session:

        (session_ro,session_rw) have higher priority than (session)
        """
        session_ro = kwargs.get('session_ro')
        session_rw = kwargs.get('session_rw')
        if not session_ro and not session_rw:
            return (session_ro,session_rw)
        elif session_ro or session_rw:
            raise ValueError("session_ro and session_rw should both be assigned value")
        else:
            session = kwargs.get('session')
            if session:
                return (session, session)
            else:
                raise ValueError("Invalid, must given (session_ro,session_rw) or (session)")

    def _init_session_v11(self, **kwargs):
        """               ---
        :session_ro:        |
        :session_rw:        | same higher priroity but should not be both used
        or                  |
        :session:         ---
        or                  
        :aws credentials    | lower priority, only if (session_ro, session_rw) and session all None, then will check if have credentials

        (session_ro,session_rw) and (session) should not be both used
        session_ro and session_rw can be both assign value or only one of it.
            if only one of session_ro or session_rw was assigned, 
            then function will assign the same value to another one.
        """
        return AwsSessionI.c_init(**kwargs)

    def _init_session_v101(self, **kwargs):
        """
        from session assume to account by given account id.

        :from_session: 
        :assume_config:
            {
                    "to_account_id": ""
                    "role_table": "aws-tool-roles",
                    "session_name": "abc",
                    "region_name": "ap-southeast-2",
            },
        """
        pi_assume_config = kwargs.get('assume_config')
        pi_from_session = kwargs.get('from_session')

        newsrole = NewsRole(session_ro=pi_from_session, session_rw=pi_from_session)
        (newrole_session_ro,newrole_session_rw) = newsrole.assume_role_byaccid_rw(
                            pi_assume_config.get('role_table'),
                            pi_assume_config.get('session_name'),
                            pi_assume_config.get('to_account_id'),
                            pi_assume_config.get('region_name')
                            )
        return (newrole_session_ro,newrole_session_rw)


    def _init_session_v102(self, **kwargs):
        """
        from main account(by credentials) assume to account by given account id.

        :credentials_config:
            {
                "aws_access_key_id":"",
                "aws_secret_access_key":"",
                "aws_session_token":"",
                "region_name":"ap-southeast-2"
            }

        :base_auth_vn: use this for base session authentication
        :assume_config:
            {
                    "from_session": ""
                    "to_account_id": ""
                    "role_table": "aws-tool-roles",
                    "session_name": "abc",
                    "region_name": "ap-southeast-2",
            },
        """
        base_auth_vn = kwargs.get('base_auth_vn')
        Log2.prefix_indent_plus()
        (session_ro, session_rw) = self.get_session(credentials_config=kwargs['credentials_config'], auth_vn=base_auth_vn)
        tuple_session = self._init_session_v101(from_session=session_rw, assume_config=kwargs['assume_config'])
        Log2.prefix_indent_minus()
        return tuple_session



    def get_session(self, *args, **kwargs):
        """
        Initialize original session based on authentication method priority

        :auth_vn: authentiction version number sequence list

        """
        auth_vn = deepcopy(kwargs.get('auth_vn'))
        if not (isinstance(auth_vn, list) or isinstance(auth_vn, tuple)):
            if auth_vn is None or auth_vn == '':
                auth_vn = [1]
            else:
                auth_vn = [auth_vn]

        for i in auth_vn:
            if i == 0:      # session is given as parameters directly
                try:
                    Log2.debug_ln(5, "trying auth_v0 ... ")
                    kwargs.pop("auth_vn")
                    result = self._init_session_v0(**kwargs)
                    Log2.debug_l(5, "session ready", prefix_format=Log2.ConstV.NO_PREFIX)
                    return result
                except Exception as ex:
                    Log2.debug_l(5, "failed: {}".format(ex), prefix_format=Log2.ConstV.NO_PREFIX)
            elif i == 1:    # by input credentials as boto3 required
                try:
                    Log2.debug_ln(5, "trying auth_v1 ... ")
                    result = self._init_session_v1(**kwargs)
                    Log2.debug_l(5, "session ready", prefix_format=Log2.ConstV.NO_PREFIX)
                    return result
                except Exception as ex:
                    Log2.debug_l(5, "failed: {}".format(ex), prefix_format=Log2.ConstV.NO_PREFIX)
            elif i == 2:    # by input credentials as config parameter, dict type
                try:
                    Log2.debug_ln(5, "trying auth_v2 ... ")
                    result = self._init_session_v2(**kwargs)
                    Log2.debug_l(5, "session ready", prefix_format=Log2.ConstV.NO_PREFIX)
                    return result
                except Exception as ex:
                    Log2.debug_l(5, "failed: {}".format(ex), prefix_format=Log2.ConstV.NO_PREFIX)
            elif i == 3:    # Credentials read from local environment variable
                try:
                    Log2.debug_ln(5, "trying auth_v3 ... ")
                    result = self._init_session_v3()
                    Log2.debug_l(5, "session ready", prefix_format=Log2.ConstV.NO_PREFIX)
                    return result
                except Exception as ex:
                    Log2.debug_l(5, "failed: {}".format(ex), prefix_format=Log2.ConstV.NO_PREFIX)
            elif i == 4:    # by auto hold session, like run as lambda
                try:
                    Log2.debug_ln(5, "trying auth_v4 ... ")
                    result = self._init_session_v4(**kwargs)
                    Log2.debug_l(5, "session ready", prefix_format=Log2.ConstV.NO_PREFIX)
                    return result
                except Exception as ex:
                    Log2.debug_l(5, "failed: {}".format(ex), prefix_format=Log2.ConstV.NO_PREFIX)
            elif i == 10:      # session is given as parameters directly
                try:
                    Log2.debug_ln(5, "trying auth_v10 ... ")
                    result = self._init_session_v10(**kwargs)
                    Log2.debug_l(5, "session ready", prefix_format=Log2.ConstV.NO_PREFIX)
                    return result
                except Exception as ex:
                    Log2.debug_l(5, "failed: {}".format(ex), prefix_format=Log2.ConstV.NO_PREFIX)
            elif i == 101:    # from session assume role to another account 
                try:
                    Log2.debug_ln(5, "trying auth_v101 ... ")
                    result = self._init_session_v101(**kwargs)
                    Log2.debug_l(5, "session ready", prefix_format=Log2.ConstV.NO_PREFIX)
                    return result
                except Exception as ex:
                    Log2.debug_l(5, "failed: {}".format(ex), prefix_format=Log2.ConstV.NO_PREFIX)
            elif i == 102:    # from main account (by credentials) assume role to another account 
                try:
                    Log2.debug_ln(5, "trying auth_v102 ... ")
                    result = self._init_session_v102(**kwargs)
                    Log2.debug_l(5, "session ready", prefix_format=Log2.ConstV.NO_PREFIX)
                    return result
                except Exception as ex:
                    Log2.debug_l(5, "failed: {}".format(ex), prefix_format=Log2.ConstV.NO_PREFIX)
            else:
                    Log2.debug_l(5, "Invalid auth type: {}".format(i))
        raise Exception("authentication:{} all failed.".format(auth_vn))

    @classmethod
    def session(cls, *args, **kwargs):
        cls_auth = NewsAuth()
        return cls_auth.get_session(*args, **kwargs)

    @classmethod
    def usage(cls):
        usage = "0: Session(**kwargs) as aws default"\
                "1: Input credentials as boto3 required" \
                "2: Input credentials as config parameter, dict type"\
                "3: Credentials read from local environment variable"\
                "4: By current hold session, like run as lambda"\
                "10: Session is given as parameters directly"\
                "101: From session assume role to another account "\
                "102: From main account(by credentials) assume to another account"
        CommFunc.echo(usage)


