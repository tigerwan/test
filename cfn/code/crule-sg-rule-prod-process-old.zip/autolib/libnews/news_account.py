"""
Module: news_account
Create Date: 2018-09-13
Function: Implement news account module.
"""
from copy import deepcopy
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc,CommConstV
from autolib.libaws.iam.aws_account import AwsAccountI
from autolib.libnews.news_user import NewsUser, NewsIamFilter
from autolib.libnews.news_report import NewsReport

class NewsAccount(AwsAccountI):
    """
    NewsAccount Class.

    Including functions in account management level.
    """

    def __init__(self, session_ro=None, session_rw=None, session=None, **kwargs):
        """
        Initalization.
        :session_ro:
        :session_rw:

        <optional>
        :account_name:
        :account_env:
        """
        super().__init__(session_ro=session_ro, session_rw=session_rw, session=session, **kwargs)
        self.__account_name = (kwargs.get("account_name") or "")
        self.__account_env = (kwargs.get("account_env") or "")

    def clean_iam(self, pi_conf, pi_disable_day_guard=30):
        """
        Disalbe iam(user's console login and accesskeys) not in use
        according the config of pi_config.

        disable_day_gurard: used for protect user to be disactived by mistake.
                user only can be diabled when no activity until
                the max(disable_day_gurard, no_activity_days) days
                example: if disable_day_gurard=30, no_activity_days=20
                    then will not disable user until no activity for 30 days
                    if disable_day_gurard=30, no_activity_days=45
                    then will not disable user until no activity for 45 days
        pi_conf example:
        {
            'no_activity_days': 45,
            'warning_days': 45,
            'aws_timezone': 'UTC',
            'p_acl': '',

            "iam_filter": {
                "filter_pattern":"Exclude",
                "exclude": {
                    "users": [],
                    "user_key_ids": [],
                    "console_login": []
                }
            }
            "report": {
            }
        }

        return format:
         {
            "account_env": "DEV",
            "account_name": "Operations",
            "account_id": "431525257644",
            "account_p_acl": "Read_Write",
            "result": [
                {
                    "AccessKeys": {
                        "Disabled": [
                            {
                                "CreateDate": "2015-09-15 06:05:36+00:00",
                                "Key": "AKIAIJNH6EXMT33J72QQ",
                                "LastUsed": "2015-10-21 03:48:00+00:00",
                                "real_acl": "Read_Write"
                            }
                        ]
                    },
                    "User": "aws_go",
                    "p_acl": "Read_Write"
                },
                {
                    "ConsoleLogin": {
                        "Action": "disabled",
                        "CreateDate": "2018-02-16 01:10:56+00:00",
                        "PasswordLastUsed": "2018-02-16 01:13:05+00:00",
                        "real_acl": "Read_Write"
                    },
                    "User": "lab_user_j98u",
                    "p_acl": "Read_Write"
                },
                {
                    "AccessKeys": {
                        "Disabled": [
                            {
                                "CreateDate": "2018-06-19 07:31:33+00:00",
                                "Key": "AKIAIV4M4KNJ7TXPKGRQ",
                                "LastUsed": null,
                                "real_acl": "Read_Write"
                            },
                            {
                                "CreateDate": "2018-06-19 04:48:20+00:00",
                                "Key": "AKIAI7CRPCRDLRZIXFNQ",
                                "LastUsed": null,
                                "real_acl": "Read_Write"
                            }
                        ]
                    },
                    "ConsoleLogin": {
                        "Action": "disabled",
                        "CreateDate": "2018-06-19 04:48:19+00:00",
                        "PasswordLastUsed": null,
                        "real_acl": "Read_Write"
                    },
                    "User": "testuser4",
                    "p_acl": "Read_Write"
                }
            ],
            "task_run_id": "20180919080850"
        }






        Following format not valid anymore

        {
            "account": "xxxxxx",
            "environment": "prod",
            "report":
            [
                {
                    "User": "hello"
                    "dry_run": False
                    "ConsoleLogin": {                   <---  Including only
                            "CreateDate":                   | when console have
                            "PasswordLastUsed":             | action to disable
                            "Action": 'disabled' | 'warning'| or warning
                            }                           <---
                    "AccessKeys":                       <---
                        {"Disabled":                        |
                            [                               |
                                {                           |
                                    "Key":"xxxxxxxx"        |
                                    "LastUsed":             |
                                    "CreateDate":           |
                                },                          | Including only
                            ]                               | when user have
                        }                                   | keys to be
                        {"Warning":                         | disabled or
                            [                               | warning
                                {                           |
                                    "Key":"yyyyy"           |
                                    "LastUsed":             |
                                    "CreateDate":           |
                                },                          |
                            ]                               |
                        }                               <---
                },
            ]
        }
        """
        results = []

        cls_task_conf = NewsCleanIamConf(config=pi_conf)
        err_info = cls_task_conf.check_config_error()
        if err_info:
            raise ValueError("Config Error: {}".format(err_info))

        users_list = self.search_users(None, cls_task_conf.compute_aws_datetime_to_warning())
        Log2.info_yaml(users_list, "User(in time range) List [Account:{} Env:{}]:\n".format(self.__account_name, self.__account_env))
        for user_name in users_list:
            user = NewsUser(user_name, session_ro=self.get_session_ro(), session_rw=self.get_session_rw())
            user_result = user.disable_if(cls_task_conf.compute_aws_datetime_to_warning(), 
                                          cls_task_conf.compute_aws_datetime_to_disable(),
                                          cls_task_conf.get_iam_filter(),
                                          p_acl=cls_task_conf.get_p_acl()
                                         )
            if user_result:
                results += [user_result]

        clean_result = {'result': results, 
                         'task_run_id': cls_task_conf.get_task_run_id(),
                         'account_name': self.__account_name,
                         'account_env': self.__account_env,
                         'account_id': self.get_current_account(),
                         'account_p_acl': cls_task_conf.get_p_acl()
                        }
        return clean_result


    def clean_iam_and_report(self, pi_conf, report_session_ro, report_session_rw, pi_disable_day_guard=30):
        """
        Do clean and write report to s3
        """
        result = self.clean_iam(pi_conf, pi_disable_day_guard)
        cls_task_conf = NewsCleanIamConf(config=pi_conf)

        cls_report = NewsReport(config=cls_task_conf.get_report_conf())
        cls_report.write_to(result, session_ro=report_session_ro, session_rw=report_session_rw, ACCOUNT_ID=self.get_current_account())

        return result





###############################################################################
# NewsCleanIamConf
###############################################################################
class NewsCleanIamConf():
    """
    Class CleanIamConf, analysis and parse Clean IAM configuration

    """

    def __init__(self, config=None, config_file=None, disable_day_guard=30):
        """
        Init

        config format:
        {
            'no_activity_days': 45,
            'warning_days': 45,
            'aws_timezone': 'UTC',
            'p_acl': ''

            "iam_filter": {
                "filter_pattern":"Exclude",
                "exclude": {
                    "users": [],
                    "user_key_ids": [],
                    "console_login": []
                }
            }
            "report": {


            }
        }
        """
        self.__config = CommFunc.get_config(config, config_file)
        if (disable_day_guard or 0) < 10:
            raise ValueError("disable_day_guard is Invalid or Risky.")
        self._disable_day_guard = disable_day_guard

        iam_filter_conf = self.__config.get('iam_filter')
        if iam_filter_conf:
            self._cls_iam_filter = NewsIamFilter(config=iam_filter_conf)
        else:
            self._cls_iam_filter = None

    def get_iam_filter(self):
        return self._cls_iam_filter

    def check_config_error(self):
        """
        if found error, return error information.
        if not found, then return None
        """
        if not self.__config:
            return "config is None"

        if self.get_no_activity_days() <= self.get_warning_days():
            return "warning_days should less than no_activity_days"
        else:
            return None

    def get_task_name(self):
        return deepcopy(self.__config.get('task_name'))


    def get_no_activity_days(self):
        return deepcopy(self.__config.get('no_activity_days'))

    def get_warning_days(self):
        return deepcopy(self.__config.get('warning_days'))

    def get_p_acl(self):
        return deepcopy(self.__config.get('p_acl'))

    def get_task_run_id(self):
        return deepcopy(self.__config.get('task_run_id'))

    def get_days_to_disable(self):
        return max(self._disable_day_guard, self.get_no_activity_days())

    def get_aws_timezone(self):
        return deepcopy(self.__config.get('aws_timezone'))

    def get_report_conf(self):
        return deepcopy(self.__config.get('report'))

    def debug_config_info(self):
        # Show config information
        Log2.debug(
                "disable_day_guard = {}\n".format(self._disable_day_guard) +
                "no_activity_days = {}\n".format(self.get_no_activity_days()) +
                "warning_days = {}\n".format(self.get_warning_days()) +
                "p_acl = {}\n".format(self.get_p_acl())) 

        # Show work information
        Log2.debug(
                "days_to_disable = {}\n".format(self.get_days_to_disable()) +
                "tl_to_disable = {}\n".format(self.compute_datetime_to_disable()) +
                "utc_tl_to_disable = {}\n".format(self.compute_aws_datetime_to_disable()) +
                "utc_tl_to_warning = {}\n".format(self.compute_aws_datetime_to_warning()))

    def compute_datetime_to_disable(self):
        return CommFunc.time_minus(
                    CommFunc.get_current_datetime(), days=self.get_days_to_disable())

    def compute_aws_datetime_to_disable(self):
        tl_to_disable = self.compute_datetime_to_disable()
        return CommFunc.localtime_to_tz(tl_to_disable,
                                        self.get_aws_timezone())

    def compute_aws_datetime_to_warning(self):
        return CommFunc.time_plus(self.compute_aws_datetime_to_disable(),
                                  days=self.get_warning_days())
