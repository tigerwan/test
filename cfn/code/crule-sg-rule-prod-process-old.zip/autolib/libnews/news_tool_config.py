"""
Module: news_tool_config
Create Date: 2018-07-31
Function: Implement news organization module.
"""

# from autolib.libcomm.log2 import Log2
from copy import deepcopy
from autolib.libcomm.log2 import Log2
from autolib.libaws.aws_dynamodb import AwsDynamodbI
from autolib.libaws.aws_session import AwsSessionI


class NewsToolConfig:
    """
    NewsToolConfig Class.

    Including functions retrieving tool configuration from dynamodb
    """

    def __init__(self, pi_tool_name=None, pi_session_ro=None, pi_session_rw=None, pi_session=None, pi_auto_cache=None, **kwargs):
        """
        Initalization.
        """
        self.__auto_cache = pi_auto_cache
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=pi_session_ro, session_rw=pi_session_rw, session=pi_session, **kwargs)
        self.__session = self.__session_ro
        self.__tool_config = None
        self.__tool_config_default = None
        self.__tool_config_dict = None
        self.__tool_name = pi_tool_name

    def set_tool(self, pi_tool_name):
        """
        Get all configuration of a given tool from dynamodb table
        Input:
            pi_tool_name:   tool name
        """
        self.__tool_name = pi_tool_name

    def get_config(self, pi_table_name, pi_tool_name=None):
        """
        Get all configuration of a given tool from dynamodb table
        Input:
            pi_table_name:  the table name to query
            pi_tool_name:   the tool name/id
        Return:
            rows_info, dict type
            format as following:
                    [
                        {'tool': 'cloudtrail-rule',
                        'config_key':'s3bucket',
                        'config_value': cloudtrail-log'
                        },
                        ...
                    ]
        """

        dbi = AwsDynamodbI(self.__session_ro)
        if not pi_tool_name:
            table = dbi.scan_table(TableName=pi_table_name)
        else:
            table = dbi.query_by_key(
                pi_table_name=pi_table_name,
                pi_key_name='tool',
                pi_dict_val={'S': pi_tool_name})

        result = {
            'Items': table['Items'],
            'Count': table['Count'],
            'ScannedCount': table['ScannedCount']
        }

        response = AwsDynamodbI.extract_rows_without_type(result)
        return response

    def lazy_get_config(self, pi_table_name, pi_tool_name=None, pi_expire_seconds=0):
        """
        Lazy get all automation tools configuration rows from dynamodb table.
        Support cache mode.
        """

        if not self.__tool_config:
            self.__tool_config = self.get_config(
                pi_table_name=pi_table_name,
                pi_tool_name=pi_tool_name
            )

        return deepcopy(self.__tool_config)

    def lazy_get_config_key_value_by_tool(self, pi_table_name, pi_tool_name, pi_expire_seconds=0, pi_include_default=True):
        """
        Lazy get the given tool's configuration rows and default rows from dynamodb table.
        Input:
            pi_table_name:  tool configuration table name
            pi_tool_name:   tool name
            pi_expire_seconds:  : legacy value
            pi_include_default  : True means including default configuration, tool's configuration overwrite default configuration
        Return:
            a dictionary of key-value, .e.g
                {
                    'config1': 'val1',
                    'config2': 'val2'
                    ...
                }
        """
        if not self.__tool_config_dict:
            # load all default configuration
            if not self.__tool_config_default and pi_include_default:
                self.__tool_config_default = self.get_config(
                    pi_table_name=pi_table_name,
                    pi_tool_name='default'
                )

            # load all configuration of the given tool
            if not self.__tool_config:
                self.__tool_config = self.get_config(
                    pi_table_name=pi_table_name,
                    pi_tool_name=pi_tool_name
                )

            # place default configurations into dictionary
            self.__tool_config_dict = {}
            if self.__tool_config_default:
                for item in self.__tool_config_default:
                    self.__tool_config_dict[item['config_name']] = item['config_value']

            # place tool's specific configurations into dictionary
            if self.__tool_config:
                for item in self.__tool_config:
                    self.__tool_config_dict[item['config_name']] = item['config_value']

        return deepcopy(self.__tool_config_dict)

    def get_config_bykey(self, pi_key, pi_tool_name=None, pi_table_name=None):
        """
        Get the specific configuration value by key.
        Input:
            pi_key:         tool's configuration key
            pi_tool_name:   tool name
            pi_table_name:  configuration table name, default is ops-tool-configuration
        Return:
            the configuration value of the given key of the given tool
        """
        # set tool name
        tool_name = self.__tool_name
        if pi_tool_name:
            tool_name = pi_tool_name

        # fetch tool configuration
        if not self.__tool_config_dict and pi_table_name:
            self.lazy_get_config_key_value_by_tool(
                pi_table_name=pi_table_name,
                pi_tool_name=tool_name
            )

        if self.__tool_config_dict:
            if pi_key in self.__tool_config_dict:
                return self.__tool_config_dict[pi_key]

        return None
