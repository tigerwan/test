"""
News Operation Library.

Especially from the org level to grab and collect daily operation information.
"""
from autolib.libcomm.log2 import Log2
from autolib.libcomm.auto_cache import AutoCache, CacheConfig
from autolib.libcomm.commfunc import CommFunc
from autolib.libcomm.processpool import ProcessPool
from autolib.libnews.news_sentry import NewsSentry
from autolib.libnews.news_org import NewsOrg

class NewsOps:
    """
    """
    def __init__(self, config=None, config_file=None):
        self.__ops_conf = OpsConfig(config, config_file)
        self.__cache_conf = self.__ops_conf.get_cache_config()
        self.__cache = AutoCache(self.__cache_conf.get_cache_path())

    def clean_cache(self):
        self.__cache.clear()

    def get_cache_keys(self):
        return self.__cache.get_keys()

    def get_org_keys(self, pi_process_num):
        proc_pool=ProcessPool()
        # Start processes pool
        proc_pool.start(pi_process_num)

        sentry = NewsSentry()
        org_keys =self.__cache.call(
                            self.__cache_conf.get_key_config("org_keys"),
                            sentry.get_keys_bypool,
                            proc_pool,
                            self.__ops_conf.get_runas_user(),
                            self.__ops_conf.get_runas_pass(),
                            self.__ops_conf.get_sentry_login_url(),
                            self.__ops_conf.get_sentry_getkey_url(),
                            progressing="On"
                            )
        proc_pool.stop()
        return org_keys

    def list_org_keys(self, pi_process_num):
        org_keys0 = self.get_org_keys(pi_process_num)
        org_keys = sorted(org_keys0, key=lambda k: k['AccountId']) 

        info_format = "{0:<12s} {1:<45s} {2:<25s}"
        Log2.echo(info_format.format("AccountId", "Role", "Expiration"))
        Log2.echo(info_format.format(
                "------------",
                "----------------------------------------",
                "-------------------------"))
        count_accounts = 0
        count_keys = 0
        for acc_key in org_keys:
            count_accounts += 1
            acc_id = acc_key.get('AccountId')
            role = acc_key.get('Role')
            expireation = acc_key.get('Expiration')
            Log2.echo(info_format.format(acc_id, 
                                         role,
                                         expireation))
            
        Log2.echo("\nTotal: {} accounts, {} users".format(count_accounts, count_keys))




    def get_org_users(self, pi_process_num):
        
        org_users = self.__cache.get('org_users')
        if org_users:
            return org_users

        proc_pool=ProcessPool()
        # Start processes pool
        proc_pool.start(pi_process_num)

        sentry = NewsSentry()
        org_keys =self.__cache.call(
                            self.__cache_conf.get_key_config("org_keys"),
                            sentry.get_keys_bypool,
                            proc_pool,
                            self.__ops_conf.get_runas_user(),
                            self.__ops_conf.get_runas_pass(),
                            self.__ops_conf.get_sentry_login_url(),
                            self.__ops_conf.get_sentry_getkey_url(),
                            progressing="On"
                            )

        org_users=self.__cache.call(
                            self.__cache_conf.get_key_config("org_users"),
                            NewsOrg.c_get_users_bypool, 
                            org_keys, 
                            proc_pool)
        proc_pool.stop()
        return org_users

    def list_org_users(self, pi_process_num):
        account_users = self.get_org_users(pi_process_num)

        info_format = "{0:<12s} {1:<38s} {2:<25s} {3:<28s} {4:<40s}"
        Log2.echo(info_format.format("accountId", "UserName", "UserId", "CreateDate", "ARN"))
        Log2.echo(info_format.format(
                "------------",
                "------------------------------",
                "-------------------------",
                "----------------------------",
                "----------------------------------------"))
        count_accounts = 0
        count_users = 0
        for acc_users in account_users:
            count_accounts += 1
            acc_id = acc_users.get('AccountId')
            users = acc_users.get('Users')
            for user in users:
                count_users += 1
                Log2.echo(info_format.format(acc_id, 
                                         user['UserName'],
                                         user['UserId'],
                                         str(user['CreateDate']),
                                         user['Arn']))
            
        Log2.echo("\nTotal: {} accounts, {} users".format(count_accounts, count_users))
        


    def get_org_roles(self, pi_process_num):
        
        org_roles = self.__cache.get('org_roles')
        if org_roles:
            return org_roles

        proc_pool=ProcessPool()
        # Start processes pool
        proc_pool.start(pi_process_num)

        sentry = NewsSentry()
        org_keys =self.__cache.call(
                            self.__cache_conf.get_key_config("org_keys"),
                            sentry.get_keys_bypool,
                            proc_pool,
                            self.__ops_conf.get_runas_user(),
                            self.__ops_conf.get_runas_pass(),
                            self.__ops_conf.get_sentry_login_url(),
                            self.__ops_conf.get_sentry_getkey_url(),
                            progressing="On"
                            )

        org_roles =self.__cache.call(
                            self.__cache_conf.get_key_config("org_roles"),
                            NewsOrg.c_get_roles_bypool, 
                            org_keys, 
                            proc_pool)
        proc_pool.stop()
        return org_roles

    def list_org_roles(self, pi_process_num):
        """
        List organization roles, show each role in one row

        Role structure:
                            {'Path': '/', 
                             'RoleName': 'workspaces_DefaultRole', 
                             'RoleId': 'AROAI5QZEAIEO654L2RKE', 
                             'Arn': 'arn:aws:ia    m::877800914193:role/workspaces_DefaultRole', 
                             'CreateDate': datetime.datetime(2014, 10, 22, 4, 13, 20, tzinfo=tzutc()), 
                             'AssumeRolePolicyDocument': {'Version': '2008-10-17', 
                                                          'Statement': [{'Sid': '', 
                                                                         'Effect': 'Allow', 
                                                                         'Principal': {'Service': 'workspaces.amazonaws.    com'}, 
                                                                         'Action': 'sts:AssumeRole'
                                                                         }]
                                                          }, 
                             'MaxSessionDuration': 3600
                            },
        """
        account_roles = self.get_org_roles(pi_process_num)

        info_format = "{0:<12s} {1:<48s} {2:<25s} {3:<28s} {4:<60s} {5:<20s} {6:<30s}"
        Log2.echo(info_format.format("accountId", 
                                 "RoleName", 
                                 "RoleId", 
                                 "CreateDate", 
                                 "ARN", 
                                 "MaxSessionDuration",
                                 "AssumeRolePolicyDocument"))
        Log2.echo(info_format.format(
                "------------",
                "------------------------------",
                "-------------------------",
                "----------------------------",
                "----------------------------------------",
                "--------------------",
                "------------------------------",
                ))
        count_accounts = 0
        count_roles = 0
        for acc_roles in account_roles:
            count_accounts += 1
            acc_id = acc_roles.get('AccountId')
            roles = acc_roles.get('Roles')
            for role in roles:
                count_roles += 1
                Log2.echo(info_format.format(acc_id, 
                                         role.get('RoleName'),
                                         role.get('RoleId'),
                                         str(role.get('CreateDate')),
                                         role.get('Arn'),
                                         str(role.get('MaxSessionDuration')),
                                         role.get('AssumeRolePolicyDocument'),
                                         ))
            
        Log2.echo("\nTotal: {} accounts, {} roles".format(count_accounts, count_roles))

    def list_org_roles2(self, pi_process_num):
        """
        List organization roles, show each role in multiple rows

        Role structure:
                            {'Path': '/', 
                             'RoleName': 'workspaces_DefaultRole', 
                             'RoleId': 'AROAI5QZEAIEO654L2RKE', 
                             'Arn': 'arn:aws:ia    m::877800914193:role/workspaces_DefaultRole', 
                             'CreateDate': datetime.datetime(2014, 10, 22, 4, 13, 20, tzinfo=tzutc()), 
                             'AssumeRolePolicyDocument': {'Version': '2008-10-17', 
                                                          'Statement': [{'Sid': '', 
                                                                         'Effect': 'Allow', 
                                                                         'Principal': {'Service': 'workspaces.amazonaws.    com'}, 
                                                                         'Action': 'sts:AssumeRole'
                                                                         }]
                                                          }, 
                             'MaxSessionDuration': 3600
                            },
        """
        account_roles = self.get_org_roles(pi_process_num)

        #info_format = "{0:<12s} {1:<48s} {2:<25s} {3:<28s} \n        {4:<60s}\n        {5:<20s}\n        {6:<30s}"
        info_format = "{0:<12s} {1:<48s} {2:<25s} {3:<28s}"
        Log2.echo(info_format.format("accountId", 
                                 "RoleName", 
                                 "RoleId", 
                                 "CreateDate", 
                                ))
        Log2.echo(info_format.format(
                "------------",
                "------------------------------",
                "-------------------------",
                "----------------------------"))
        Log2.echo("        {}\n        ----------------------------------------".format("ARN")), 
        Log2.echo("        {}\n        ----------------------------------------".format("MaxSessionDuration")), 
        Log2.echo("        {}\n        ----------------------------------------".format("AssumeRolePolicyDocument")), 
        count_accounts = 0
        count_roles = 0
        for acc_roles in account_roles:
            count_accounts += 1
            acc_id = acc_roles.get('AccountId')
            roles = acc_roles.get('Roles')
            for role in roles:
                count_roles += 1
                Log2.echo(info_format.format(acc_id, 
                                         role.get('RoleName'),
                                         role.get('RoleId'),
                                         str(role.get('CreateDate')),
                                         ))
                Log2.echo("        {}".format(role.get('Arn')))
                Log2.echo("        {}".format(role.get('MaxSessionDuration')))
                Log2.echo("        {}".format(role.get('AssumeRolePolicyDocument')))
            
        Log2.echo("\nTotal: {} accounts, {} roles".format(count_accounts, count_roles))


    def get_org_access_keys(self, pi_process_num):
        org_access_keys = self.__cache.get('org_access_Keys')
        if org_access_keys:
            return org_access_keys

        proc_pool=ProcessPool()
        # Start processes pool
        proc_pool.start(pi_process_num)

        sentry = NewsSentry()
        org_keys = self.__cache.call(
                            self.__cache_conf.get_key_config("org_keys"),
                            sentry.get_keys_bypool,
                            proc_pool,
                            self.__ops_conf.get_runas_user(),
                            self.__ops_conf.get_runas_pass(),
                            self.__ops_conf.get_sentry_login_url(),
                            self.__ops_conf.get_sentry_getkey_url(),
                            progressing="On"
                            )

        org_access_keys = self.__cache.call(
                            self.__cache_conf.get_key_config("org_access_keys"),
                            NewsOrg.c_get_access_keys_bypool, 
                            org_keys, 
                            proc_pool)
        proc_pool.stop()
        return org_access_keys
    
    def list_org_access_keys(self, pi_process_num):
        """
        List organization access keys, show each access_key in one row

        AccessKey structure:
                {
                    "UserName": "testuser4",
                    "AccessKeyId": "AKIAIV4M4KNJ7TXPKGRQ",
                    "Status": "Inactive",
                    "CreateDate": "2018-06-19T07:31:33Z"
                },
        """
        org_access_keys = self.get_org_access_keys(pi_process_num)

        info_format = "{0:<12s} {1:<48s} {2:<25s} {3:<28s} {4:<60s}"
        Log2.echo(info_format.format("accountId", 
                                     "UserName", 
                                     "AccessKeyId", 
                                     "CreateDate", 
                                     "Status"))
        Log2.echo(info_format.format(
                "------------",
                "------------------------------",
                "-------------------------",
                "----------------------------",
                "----------------------------------------"
                ))
        count_accounts = 0
        count_access_keys = 0
        for acc_access_keys in org_access_keys:
            count_accounts += 1
            acc_id = acc_access_keys.get('AccountId')
            access_keys = acc_access_keys.get('AccessKeys')
            for access_key in access_keys:
                count_access_keys += 1
                Log2.echo(info_format.format(acc_id, 
                                         access_key.get('UserName'),
                                         access_key.get('AccessKeyId'),
                                         str(access_key.get('CreateDate')),
                                         access_key.get('Status')
                                         ))
            
        Log2.echo("\nTotal: {} accounts, {} access_keys".format(count_accounts, count_access_keys))



    def get_org_buckets(self, pi_process_num):
        """
        Get org buckets
        """
        org_buckets = self.__cache.get('org_buckets')
        if org_buckets:
            return org_buckets

        proc_pool=ProcessPool()
        # Start processes pool
        proc_pool.start(pi_process_num)

        sentry = NewsSentry()
        org_keys = self.__cache.call(
                            self.__cache_conf.get_key_config("org_keys"),
                            sentry.get_keys_bypool,
                            proc_pool,
                            self.__ops_conf.get_runas_user(),
                            self.__ops_conf.get_runas_pass(),
                            self.__ops_conf.get_sentry_login_url(),
                            self.__ops_conf.get_sentry_getkey_url(),
                            progressing="On"
                            )

        org_buckets = self.__cache.call(
                            self.__cache_conf.get_key_config("org_buckets"),
                            NewsOrg.c_get_buckets_bypool, 
                            org_keys, 
                            proc_pool)
        proc_pool.stop()
        return org_buckets

    def list_org_buckets(self, pi_process_num):
        """
        List organization buckets, show each bucket in one row

        Buckets structure:
                {
                    'Buckets': [{'Name': 'adltemp', 
                                  'CreationDate': datetime.datet    ime(2018, 8, 3, 20, 2, tzinfo=tzutc())
                                 },
                                 ...
                                ]
                    'Owner': {'DisplayName': 'ndm-dl-awsaccount', 
                               'ID': 'c3a2a61e11a8cd9fde7dfc39fdb690877e6d84005f8e6e5f1645675a24afd877'
                             }
                },
        """
        org_buckets = self.get_org_buckets(pi_process_num)

        info_format = "{0:<12s} {1:<70s} {2:<28s} {3:<28s} {4:<30s}"
        Log2.echo(info_format.format("accountId", 
                                     "Name", 
                                     "CreationDate",
                                     "Owner",
                                     "ID"))
        Log2.echo(info_format.format(
                "------------",
                "------------------------------",
                "----------------------------",
                "----------------------------",
                "----------------------------"))
        count_accounts = 0
        count_buckets = 0
        for acc_buckets in (org_buckets or []):
            count_accounts += 1
            acc_id = acc_buckets.get('AccountId')
            owner = (acc_buckets.get('Buckets') or {}).get('Owner')
            owner_name = owner.get('DisplayName')
            owner_id = owner.get('ID')
            buckets = (acc_buckets.get('Buckets') or {}).get('Buckets')
            for bucket in buckets:
                count_buckets += 1
                Log2.echo(info_format.format(acc_id, 
                                         bucket.get('Name'),
                                         str(bucket.get('CreationDate')),
                                         owner_name,
                                         owner_id
                                         ))
            
        Log2.echo("\nTotal: {} accounts, {} buckets".format(count_accounts, count_buckets))


###############################################################################
# OpsConfig
###############################################################################
class OpsConfig:
    """
    class of OPS Config

    format:
    {
        "run_as": {
            "user": "svc_aws_rw"
            "password": "4SVXFr2LbH!!8m"
            "sentry_login_url": "https://sentry.news.newslimited.local/api/login",
            "sentry_getkey_url":"https://sentry.news.newslimited.local/api/getkey"
        }
        "cache": {
            "keys": {
                "org_keys": { 
                            "key": ""
                            "key_plus": ""
                            "expire_seconds": ""
                },
            }
            "cache_path": "/tmp/cache"
        }
    }

    """
    def __init__(self, config=None, config_file=None):
        self.__config = CommFunc.get_config(config, config_file)

    def get_config(self):
        return self.__config

    def _get_runas(self):
        return self.__config.get("run_as")

    def get_runas_user(self):
        return (self._get_runas() or {}).get("user")

    def get_runas_pass(self):
        return (self._get_runas() or {}).get("password")

    def get_sentry_login_url(self):
        return (self._get_runas() or {}).get("sentry_login_url")

    def get_sentry_getkey_url(self):
        return (self._get_runas() or {}).get("sentry_getkey_url")

    def get_cache_config(self):
        """
        Get cache config
        return dict
        """
        cache_config = self.__config.get('cache')
        return CacheConfig(cache_config) 

