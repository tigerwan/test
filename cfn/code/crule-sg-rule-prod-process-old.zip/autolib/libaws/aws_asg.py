"""
This module implements AWS ASG interface.
"""
from copy import deepcopy
from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI


class AwsAsgI:
    """ ASG operation """
    def __init__(self, session_ro=None, session_rw=None, session=None, **kwargs):
        """
        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, session_rw=session_rw, session=session, **kwargs)
        self.__session = self.__session_ro
        self.__client = self.__session.client('autoscaling')
        self.__asg = None
        self.__lc = None

    def describe_launch_configurations(self, **kwargs):
        """Wrapper of AWS SDK describe_launch_configurations"""
        params = deepcopy(kwargs)

        lc = self.__client.describe_launch_configurations(**params)
        all_lc = lc
        next_token = lc.get('NextToken')
        while next_token:
            params['NextToken'] = next_token
            lc = self.__client.describe_auto_scaling_groups(**params)
            if len(lc['LaunchConfigurations']) > 0:
                all_lc['LaunchConfigurations'] += lc['LaunchConfigurations']
            else:
                break
            next_token = lc.get('NextToken')
        self.__lc = all_lc
        return self.__lc

    def describe_lc_by_name(self, pi_lc_name):
        """Retrive one single Launch Configuration."""
        params = {}
        if (isinstance(pi_lc_name, (set, list, tuple))):
            params['LaunchConfigurationNames'] = list(pi_lc_name)
        else:
            params['LaunchConfigurationNames'] = [pi_lc_name]

        return self.describe_launch_configurations(**params)

    def describe_lc_by_asg(self, pi_asg):
        """Retrive one single Launch Configuration."""

        if pi_asg and 'AutoScalingGroups' in pi_asg and len(pi_asg['AutoScalingGroups']) > 0 and 'LaunchConfigurationName' in pi_asg['AutoScalingGroups'][0]:

            return self.describe_launch_configurations(
                LaunchConfigurationNames=[
                    pi_asg['AutoScalingGroups'][0]['LaunchConfigurationName']
                ]
            )
        else:
            return None

    def describe_auto_scaling_groups(self, **kwargs):
        """Wrapper of AWS SDK describe_auto_scaling_groups"""
        params = deepcopy(kwargs)

        asg = self.__client.describe_auto_scaling_groups(**params)
        all_asg = asg
        next_token = asg.get('NextToken')
        while next_token:
            params['NextToken'] = next_token
            asg = self.__client.describe_auto_scaling_groups(**params)
            if len(asg['AutoScalingGroups']) > 0:
                all_asg['AutoScalingGroups'] += asg['AutoScalingGroups']
            else:
                break
            next_token = asg.get('NextToken')
        self.__asg = all_asg
        return self.__asg

    def load_asg(self):
        """
        Get all ASGs describe information.

        Input:
        Output:

        Return:
            all_asg
        """

        return self.describe_auto_scaling_groups()

    def lazy_load_asg(self):
        """
        Get all ASGs describe information.

        Input:
        Output:

        Return:
            all_asg
        """
        if not self.__asg:
            self.describe_auto_scaling_groups()

        return self.__asg

    def get_asg(self):
        """Get all ASGs."""
        if not self.__asg:
            self.lazy_load_asg()
        return self.__asg

    def describe_asg_by_name(self, pi_asg_name):
        """Retrive one single ASG."""
        params = {}
        if (isinstance(pi_asg_name, (set, list, tuple))):
            params['AutoScalingGroupNames'] = list(pi_asg_name)
        else:
            params['AutoScalingGroupNames'] = [pi_asg_name]

        return self.describe_auto_scaling_groups(**params)
