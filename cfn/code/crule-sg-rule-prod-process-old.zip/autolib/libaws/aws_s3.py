
"""
Module: aws_s3
Create Date: 2018-08-01
Function: Implement aws S3 module.
"""
from autolib.libcomm.log2 import Log2
from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI
import botocore
from copy import deepcopy

class AwsS3I:
    """
    AWS S3 Interface.

    """

    def __init__(self, session_ro=None, session_rw=None, session=None, **kwargs):
        """ Initalization.
        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, session_rw=session_rw, session=session, **kwargs)
        self.__s3_ro = self.__session_ro.client('s3')
        self.__s3_rw = self.__session_rw.client('s3')


    def get_buckets(self, dry_run=False):
        """
        {
            'Buckets': [
                {
                    'Name': 'string',
                    'CreationDate': datetime(2015, 1, 1)
                },
            ],
            'Owner': {
                'DisplayName': 'string',
                'ID': 'string'
            }
        }
        """
        return self.__s3_ro.list_buckets()


    def write_file(self, pi_bucket, pi_path_file, pi_content,  dry_run=False):
        """
        Write string content to S3 bucket new file (folder like based)
        """
        msg = "write_file, bucket:{} path_file:{}".format(pi_bucket, pi_path_file)
        if dry_run:
            Log2.debug("DRY RUN: {}".format(msg))
        else:
            Log2.debug(msg)
            content = CommFunc.to_bytes(pi_content)
            self.__s3_rw.put_object(Body=content,
                                   Bucket=pi_bucket,
                                   Key=pi_path_file)

    def write_new_file(self, pi_bucket, pi_path_file, pi_content,  dry_run=False):
        """
        Write string content to S3 bucket new file (folder like based)
        """
        if self.access(pi_bucket, pi_path_file):
            raise IOError("write_new_file {} failed - already exists".format(pi_path_file))
        self.write_file(pi_bucket, pi_path_file, pi_content,  dry_run)


    def read_file(self, pi_bucket, pi_path_file):
        """
        Read content from S3 bucket file (folder like based)
        """
        res = self.__s3_ro.get_object(Bucket=pi_bucket, Key=pi_path_file)
        #return res['Body'].read().decode('utf-8')
        return res['Body'].read().decode()


    def get_objects(self, pi_bucket, pi_object_prefix):
        """
        Get all objects start with <pi_folder_prefix>
        """
        res = self.__s3_ro.list_objects(Bucket=pi_bucket, Prefix=pi_object_prefix)
        folders = res.get('Contents')
        return folders

    def get_objects_v2(self, pi_bucket, pi_object_prefix):
        """
        Get all objects start with <pi_folder_prefix>
        """
        folders = []
        res = self.__s3_ro.list_objects_v2(Bucket=pi_bucket, Prefix=pi_object_prefix)
        folders += res.get('Contents')
        next_continuation_token = res.get('NextContinuationToken')
        while next_continuation_token:
            res = self.__s3_ro.list_objects_v2(Bucket=pi_bucket, Prefix=pi_object_prefix,  ContinuationToken=next_continuation_token)
            folders += res.get('Contents')
            next_continuation_token = res.get('NextContinuationToken')
        return folders

    def list_folders(self, pi_bucket, pi_folder_prefix):
        """
        Get all folders start with <pi_folder_prefix>
        but if <pi_folder_prefix> has sub-folders, will not show sub-folders
        """
        objects = self.get_objects(pi_bucket, pi_folder_prefix)
        if objects:
            l_objects = [x['Key'] for x in objects if x['Key'].find('/', len(pi_folder_prefix)) != -1 ]
            l_folders = [y[0:y.find('/',len(pi_folder_prefix))] for y in l_objects]
            return sorted(set(l_folders))

    def list_files(self, pi_bucket, pi_prefix):
        """
        Get all files start with <pi_folder_prefix>, not including sub-folders' files
        """
        objects = self.get_objects(pi_bucket, pi_prefix)
        if objects:
            l_objects = [x['Key'] for x in objects if x['Key'].find('/', len(pi_prefix)) == -1]
            return sorted(l_objects)

    def list_files_r(self, pi_bucket, pi_prefix):
        """
        Get all files start with <pi_folder_prefix>, including sub-folders' files
        """
        objects = self.get_objects(pi_bucket, pi_prefix)
        if objects:
            l_objects = [x['Key'] for x in objects if (x['Key'].find('/', len(pi_prefix)) == -1 or x['Key'][-1] != "/")]
            return sorted(l_objects)

    def get_last_folder(self, pi_bucket, pi_folder_prefix):
        """
        Get the last folder name that by ascending order,
        folder start with <pi_folder_prefix>, not including sub-folders
        """
        folders = self.list_folders(pi_bucket, pi_folder_prefix)
        if folders:
            return folders[-1]

    def list_last_folder_files(self, pi_bucket, pi_prefix):
        """
        list files exists in last folder. (not including sub-folders's file)
        file start with <pi_prefix>, not including sub-folders
        """
        last_folder = self.get_last_folder(pi_bucket, pi_prefix)
        Log2.debug("last_folder:{}".format(last_folder))
        if last_folder:
            return self.list_files(pi_bucket, last_folder+"/")
        else:
            return None



    def access(self, pi_bucket, pi_path_file):
        """
        check S3 bucket file if exists (folder like based)
        """
        try:
            self.__s3_ro.get_object(Bucket=pi_bucket, Key=pi_path_file)
            return True
        except botocore.exceptions.ClientError as ex:
            if ex.response['Error']['Code'] == 'NoSuchKey':
                return False
            else:
                raise ex
