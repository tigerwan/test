"""
This module implements AWS EC2 instance interface.
"""
from copy import deepcopy
from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI


class AwsEc2I:
    """ EC2 instance operation """
    def __init__(self, session_ro=None, session_rw=None, session=None, **kwargs):
        """
        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, session_rw=session_rw, session=session, **kwargs)
        self.__session = self.__session_ro
        self.__client = self.__session.client('ec2')
        self.__instances = None

    def describe_instances(self, **kwargs):

        params = deepcopy(kwargs)

        instances = self.__client.describe_instances(**params)
        all_instances = instances
        next_token = instances.get('NextToken')
        while next_token:
            params['NextToken'] = next_token
            instances = self.__client.describe_instances(**params)
            if len(instances['Reservations']) > 0:
                all_instances['Reservations'] += instances['Reservations']
            else:
                break
            next_token = instances.get('NextToken')
        self.__instances = all_instances
        return self.__instances

    def load_instances(self):
        """
        Get all instances describe information.

        Input:
        Output:

        Return:
            all_instances
        """

        return self.describe_instances()

    def lazy_load_instances(self):
        """
        Get all instances describe information.

        Input:
        Output:

        Return:
            all_instances
        """
        if not self.__instances:
            self.describe_instances()

        return self.__instances

    def get_instances(self):
        """Get all EC2 instances."""
        if self.__instances is None:
            self.lazy_load_instances()
        return self.__instances

    def describe_instances_by_id(self, pi_instance_id):
        """Retrive EC2 instances by instance id."""
        params = {}
        if (isinstance(pi_instance_id, (set, list, tuple))):
            params['InstanceIds'] = list(pi_instance_id)
        else:
            params['InstanceIds'] = [pi_instance_id]

        return self.describe_instances(**params)

    def pull_instances(self, pi_output_file):
        """
        Pull all instances describe information and save to given file.
        Input:
            pi_instances_file: file to save instance information.
        Output:
            save instance describe info to <pi_instances_file>
        """
        instances = self.get_instances()
        CommFunc.write_json_file(instances, pi_output_file)
