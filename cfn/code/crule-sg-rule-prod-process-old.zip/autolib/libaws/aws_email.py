
"""
Module: aws_email
Create Date: 2018-07-31
Function: Implement aws SES module.
"""
# import boto3
from autolib.libaws.aws_session import AwsSessionI

class AwsEmailI:
    """
    """

    def __init__(self, session_ro=None,  session_rw=None, session=None, **kwargs):
        """ Initalization.
        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, session_rw=session_rw, session=session, **kwargs)
        self.__session = self.__session_ro
        self.__instances = None

    def ses_send(self, pi_session, pi_subject, pi_from, pi_to,  message_text=None, message_html=None):
        self.c_ses_send(self.__session, pi_subject, pi_from, pi_to,  message_text=message_text, message_html=message_html)

    @classmethod
    def c_ses_send(cls, pi_session, pi_subject, pi_from, pi_to,  message_text=None, message_html=None):
       #ses = boto3.client('ses',region_name='us-west-2')
       ses = pi_session.client('ses',region_name='us-west-2')
       email_subject = pi_subject
       to_address = pi_to.split(',')

       if message_text is not None and message_html is not None:
           body_content = {'Text': {'Data': message_text},
                           'Html' : {'Data': message_html}
                          }
       elif message_text is not None:
           body_content = {'Text': {'Data': message_text}}
       elif message_html is not None:
           body_content = {'Html': {'Data': message_html}}
       else:
           body_content = {'Text': {'Data': ''},
                           'Html' : {'Data': ''}
                          }

       response = ses.send_email(
           Source = pi_from,
           Destination = {
               'ToAddresses': to_address
           },
           Message = {
               'Subject' : {
                   'Data' : email_subject,
                   'Charset' : 'utf-8'
               },
               'Body' : body_content
           }
       )
       if 'ErrorResponse' in response:
           return response
       else:
           return 'Email Sent Successfully!'