
"""
Module: aws_labmda
Create Date: 2018-07-31
Function: Implement aws lambda module.
"""
from copy import deepcopy
# from autolib.libcomm.commfunc import CommFunc
from autolib.libaws.aws_session import AwsSessionI


class AwsLambdaI:
    """
    AWS Lambda Function Interface
    """
    def __init__(self, session_ro=None, session_rw=None, session=None, **kwargs):
        """ Initalization.
        """
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, session_rw=session_rw, session=session, **kwargs)
        self.__session = self.__session_ro
        self.__functions = None

        self.__lambda = self.__session.client('lambda')
        self.__lastcall_result = None

    def invoke(self, **kwargs):
        """
        FunctionName:[Required]
        InvocationType:
        LogType:
        ClientContext:
        PayLoad:
        Qualifier:

        request example:
        ----------------
        response = yyy.invoke(
            FunctionName='string',
            InvocationType='Event'|'RequestResponse'|'DryRun',
            LogType='None'|'Tail',
            ClientContext='string',
            Payload=b'bytes'|file,
            Qualifier='string'
        )
        Error response example:
        ----------------------
        {
            'StatusCode': 123,
            'FunctionError': 'string',    Handled|Unhandled
            'LogResult': 'string',
            'Payload': StreamingBody(),
            'ExecutedVersion': 'string'
        }

        Success return empty response
        ---------------
        """
        self.__lastcall_result = self.__lambda.invoke(**kwargs)
        return self.__lastcall_result

    def list_functions(self, **kwargs):
        """
        Wrapper of list all lambda functions
        """
        response = {
            'Functions': []
        }
        response_function = response['Functions']

        params = {}
        if kwargs:
            params = deepcopy(kwargs)

        while True:
            result = self.__lambda.list_functions(**params)
            if 'Functions' in result:
                response_function.extend(result['Functions'])

            if 'NextMarker' in result:
                params['Marker'] = result['NextMarker']
            else:
                break

        return response

    def get_function_configuration(self, **kwargs):
        """
        Wrapper of list get lambda functions configuration
        """
        return self.__lambda.get_function_configuration(**kwargs)
