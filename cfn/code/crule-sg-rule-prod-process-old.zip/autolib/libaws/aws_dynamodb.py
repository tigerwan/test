"""
Implement Account module, orgnize all the account related functions.
Role
IAM
Usser
"""

from autolib.libaws.aws_session import AwsSessionI

class AwsDynamodbI:
    def __init__(self, session_ro=None, session_rw=None, session=None, pi_auto_cache=None):
        """ Initalization. """

        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro, 
                                                                    session_rw=session_rw, 
                                                                    session=session)
        self.__session = self.__session_ro
        self.__dbconn = self.__session.client('dynamodb')
        self.__auto_cache = pi_auto_cache

    def set_session(self, pi_session):
        self.__session = pi_session
        self.__dbconn = self.__session.client('dynamodb')

    def scan_table(self, **kwargs):
        """
        Scan whole table, return all results, support cache mode.
        if self.__auto_cache and kwargs including:
            cache_key and cache_expire_seconds,
            then will try to use cache function.

        {'Items':
            [
                {'accountId': {'S': '261912113761'},
                    'accountName': {'S': 'News DNA'},
                    'environment': {'S': 'PROD'}
                },
                {'accountId': {'S': '851914194101'},
                    'accountName': {'S': 'News DNA'},
                    'environment': {'S': 'UAT'}
                },
                {'accountId': {'S': '706225645189'},
                    'environment': {'S': 'DEV'},
                    'accountName': {'S': 'Data Services'}
                }
            ],
            'Count': 37,
            'ScannedCount': 37,
            'ResponseMetadata':
            {
                'RequestId': 'O9LVHTBQIR12H1G5L22KPRRV13VV4KQNSO5AEMVJF66Q9ASUAAJG',
                'HTTPStatusCode': 200,
                'HTTPHeaders':
                {'server': 'Server',
                 'date': 'Sun, 22 Jul 2018 23:46:04 GMT',
                 'content-type': 'application/x-amz-json-1.0',
                 'content-length': '3559',
                 'connection': 'keep-alive',
                 'x-amzn-requestid': 'O9LVHTBQIR12H1G5L22KPRRV13VV4KQNSO5AEMVJF66Q9ASUAAJG',
                 'x-amz-crc32': '1897051819'
                },
                'RetryAttempts': 0
            }
        }


        AWS dynamodb scan return format:
            {
                "Count": 7,
                "Items": [
                    {
                        "title": {
                            "S": "Monster on the Campus"
                        }
                    },
                    {
                        "title": {
                            "S": "+1"
                        }
                    },
                    ...
                ],
                "LastEvaluatedKey": {
                    "year": {
                        "N": "2013"
                    },
                    "title": {
                        "S": "Curse of Chucky"
                    }
                },
                "ScannedCount": 100
            }
        """
        if self.__auto_cache and kwargs['cache_key'] and int(kwargs['cache_expire_seconds']) > 0:
            cache_value = self.__auto_cache.get(kwargs['cache_key'])
            if cache_value:
                return cache_value

        table = self.__dbconn.scan(**kwargs)
        next_token = table.get('LastEvaluatedKey')
        while True: 
            if next_token is None:
                break
            else:
                result = self.__dbconn.scan(**kwargs, ExclusiveStartKey=next_token)
                table['Items'] += result['Items']
                table['ScannedCount'] += result['ScannedCount']
                table['Count'] += result['Count']
            next_token = None
            next_token = result.get('LastEvaluatedKey')

        if self.__auto_cache and kwargs['cache_key'] and int(kwargs['cache_expire_seconds']) > 0:
            self.__auto_cache.set(kwargs['cache_key'], table, kwargs['cache_expire_seconds'])
        return table


    def scan_query_str_in(self, pi_table_name, pi_column_name, pi_value_list):
        """
        Scan table and query the column that value with in a list
        """
        scan_result = self.scan_table(TableName=pi_table_name)
        scan_items = scan_result['Items']
        result = {}
        if scan_items:
            items = [x for x in scan_items if x[pi_column_name]['S'] in pi_value_list]
            if items:
                result['Items'] = items
                result['Count'] = len(items)
                result['ScannedCount'] = len(scan_items)
        return result


    #
    # following is for simple result
    #
    def simple_scan(self, **kwargs):
        table = self.scan_table(**kwargs)
        #
        # remove value type, convert
        #    {'accountId': {'S': '261912113761'} 
        # to {'accountId': '261912113761'}
        #
        rows = [dict(zip(row.keys(), [list(column_value.values())[0] for column_value in row.values()]))  for row in table['Items']]
        result = {'Items': rows,
                  'Count': table['Count'],
                  'ScannedCount': table['ScannedCount']}
        return result

    @classmethod
    def extract_rows(cls, pi_query_result, column_value_with_type=True):
        """
        Extract rows from table scan or query result

        pi_query_result: the table scan or query result. format as:
         {'Items':
            [
                {'accountId': {'S': '261912113761'},
                    'accountName': {'S': 'News DNA'},
                    'environment': {'S': 'PROD'}
                },
            ],
            'Count': 37,
            'ScannedCount': 37,
        }

        Return:
        if column_value_with_type == True (default), Return:
            [
                {'accountId': {'S': '261912113761'},
                    'accountName': {'S': 'News DNA'},
                    'environment': {'S': 'PROD'}
                },
            ]
        if column_value_with_type == False, Return
            [
                {'accountId': '261912113761',
                    'accountName': 'News DNA',
                    'environment': 'PROD'
                },
            ]
        """
        if column_value_with_type:
            rows = pi_query_result.get('Items') or []
        else:
            rows = [dict(zip(row.keys(), [list(column_value.values())[0] for column_value in row.values()]))  for row in (pi_query_result.get('Items') or [])]
        return rows

    @classmethod
    def extract_rows_without_type(cls, pi_query_result):
        return cls.extract_rows(pi_query_result, column_value_with_type=False)

    #
    #
    # following is not used currently
    #
    #


    def query(self, **kwargs):
        """
        Transparent of call Dynamodb query
        """
        return self.__dbconn.query(**kwargs)


    def query_by_policy(self, 
                  query_policy={"max_query": None, 
                                "max_limit_retry": 10, 
                                "retry_interval_seconds":10}, 
                  **kwargs):
        """
        Query  and return all results

        dynamodb query return format like following:
        {
            'ConsumedCapacity': {
            },
            'Count': 2,
            'Items': [
                {
                    'SongTitle': {
                        'S': 'Call Me Today',
                    },
                },
            ],
            'ScannedCount': 2,
            'LastEvaluatedKey':
            'ResponseMetadata': {
                '...': '...',
            },
        }
        """
        results = self.query(**kwargs)
        next_token = results.get('LastEvaluatedKey')
        while True:
            if next_token is None:
                break
            else:
                kwargs['ExclusiveStartKey'] = next_token
                result = self.query(**kwargs)
                results['Items'] += result['Items']
                results['ScannedCount'] += result['ScannedCount']
                results['Count'] += result['Count']
            next_token = None
            next_token = result.get('LastEvaluatedKey')
        return results




    def query_by_expression(self, 
                            pi_table_name,
                            pi_KeyConditionExpression,
                            pi_ExpressionAttributeValues):
        """
        Query by key, dict type value.
        value like {'S': 'xxxxx'} or {'N': '123.45'}
        pi_ExpressionAttributeValues = {':v1': {'S': 'hello world'},}
        pi_KeyConditionExpression = {'key =  :v1',}

        """
        result = self.query_by_policy(
                        TableName=pi_table_name, 
                        KeyConditionExpression = pi_KeyConditionExpression,
                        ExpressionAttributeValues = pi_ExpressionAttributeValues
                        )
        return result

    def query_by_key(self, pi_table_name, pi_key_name, pi_dict_val):
        """
        Query by key, value is dict type, 
        like {'S': 'hello'}, means key value equal string 'hello'
        like {'N': '123.45'}, means key value equal number 123.45
        """
        return self.query_by_expression(pi_table_name, 
                                        "{} = :v1".format(pi_key_name),
                                        {":v1": pi_dict_val,})

    def query_by_key_in(self, pi_table_name, pi_key_name, pi_list_value):
        """
        Query by key in value list.
        """
        return self.query_by_expression(pi_table_name, 
                                       "{} IN :v1".format(pi_key_name),
                                        {":v1": pi_list_value})

    def query_by_key_strvalue(self, pi_table_name, pi_key_name, pi_str_val):
        """
        Query by key, value type is string
        """
        return self.query_by_key(pi_table_name, pi_key_name, {'S': pi_str_val})

    @classmethod
    def generate_filter_expression(cls, pi_dict, pi_operator='AND'):
        """
        Generate FilterExpression baed on the input pi_dict
        Input:
            pi_dict: a dictionary containing key-value pair, e.g
                {
                    'abc': {
                        'S': '123'
                    }
                }
        Return:
            a dictory containg the generated FilterExpression, ExpressionAttributeNames and ExpressionAttributeValues,e.g.
            {
                'FilterExpression': '#key1 = :val1',
                'ExpressionAttributeNames': {
                    '#key1': 'abc'
                }
                'ExpressionAttributeValues': {
                    ':val1': { 'S': '123' }
                }
            }
        """

        # if input dictionary is None or empty, return a empty dictionary
        if not pi_dict:
            return {}

        response = {
            'FilterExpression': '',
            'ExpressionAttributeNames': {},
            'ExpressionAttributeValues': {}
        }

        # loop dictionary, generate FilterExpression, ExpressionAttributeNames and ExpressionAttributeValues
        index = 0
        for key in pi_dict:

            # add AND/OR operator to FilterExpression
            if response['FilterExpression']:
                response['FilterExpression'] += ' {} '.format(pi_operator)

            # generate key name
            index += 1
            filter_key_name = '#key' + str(index)

            # set ExpressionAttributeNames
            response['ExpressionAttributeNames'][filter_key_name] = key

            # for the dictionary, use "key IN (:val1, :val2)"
            if isinstance(pi_dict[key], (list,tuple,set)):
                val_dict = {}
                val_index =0 
                for item in pi_dict[key]:
                    val_index += 1

                    filter_value_name = ':val{}_{}'.format(str(index),str(val_index))
                    val_dict[filter_value_name] = item

                response['ExpressionAttributeValues'].update(val_dict)

                response['FilterExpression'] += ' {} IN ({}) '.format(filter_key_name, ','.join(val_dict.keys()))

            # for string, use "key = :val"
            else:
                filter_value_name = ':val' + str(index)
                response['FilterExpression'] += ' {} = {} '.format(filter_key_name, filter_value_name)
                response['ExpressionAttributeValues'][filter_value_name] = pi_dict[key]

        return response
