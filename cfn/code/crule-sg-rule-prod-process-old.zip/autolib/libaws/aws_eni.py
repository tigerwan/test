"""
Wrapper of  AWS CloudTrail API
"""
# import botocore
from copy import deepcopy
# from time import sleep
from autolib.libcomm.log2 import Log2
from autolib.libaws.aws_session import AwsSessionI

class AwsNetworkInterfaceI:
    def __init__(self, pi_max_retry=3, pi_retry_interval=1, session_ro=None, session_rw=None, session=None, pi_auto_cache=None):
        """Initalization."""
        (self.__session_ro, self.__session_rw) = AwsSessionI.c_init(session_ro=session_ro,
                                                                    session_rw=session_rw,
                                                                    session=session)
        self.__session = self.__session_ro
        self.__client = self.__session.client('ec2')
        self.__auto_cache = pi_auto_cache
        self.__max_retry = pi_max_retry
        self.__retry_interval = pi_retry_interval

    def describe_network_interfaces(self, **kwargs):
        """Desribe the network interfaces."""
        response = {
            'NetworkInterfaces': []
        }
        response_eni = response['NetworkInterfaces']

        params = {}
        if kwargs:
            params = deepcopy(kwargs)

        while True:
            result = self.__client.describe_network_interfaces(**params)
            if 'NetworkInterfaces' in result:
                response_eni.extend(result['NetworkInterfaces'])

            if 'NextToken' in result:
                params['NextToken'] = result['NextToken']
            else:
                break

        self.__network_interfaces = response
        return response
